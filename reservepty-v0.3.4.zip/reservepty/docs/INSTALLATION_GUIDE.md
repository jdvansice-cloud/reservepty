# ReservePTY — Step-by-Step Installation Guide

This guide walks you through setting up ReservePTY using **Supabase Dashboard** (web UI) and **GitHub Desktop** (no command line required for Git).

---

## Prerequisites

Before starting, make sure you have:

- [ ] **Node.js 20+** installed → [Download here](https://nodejs.org/)
- [ ] **GitHub account** → [Sign up free](https://github.com/)
- [ ] **GitHub Desktop** installed → [Download here](https://desktop.github.com/)
- [ ] **Supabase account** → [Sign up free](https://supabase.com/)
- [ ] **Code editor** (VS Code recommended) → [Download here](https://code.visualstudio.com/)
- [ ] **ReservePTY project zip** (downloaded from our conversation)

---

## Part 1: GitHub Repository Setup

### Step 1.1 — Create a New Repository on GitHub

1. Go to [github.com](https://github.com) and sign in
2. Click the **+** icon in the top-right corner
3. Select **"New repository"**
4. Fill in the details:
   - **Repository name:** `reservepty`
   - **Description:** `Luxury Asset Booking Platform`
   - **Visibility:** Private (recommended)
   - **DO NOT** check "Add a README file" (we have one)
5. Click **"Create repository"**
6. Keep this page open — you'll need the repository URL

### Step 1.2 — Extract the Project Files

1. Find the downloaded `reservepty-v0.1.0.zip` file
2. Right-click → **Extract All** (Windows) or double-click (Mac)
3. Extract to a location you'll remember, e.g.:
   - Windows: `C:\Projects\reservepty`
   - Mac: `~/Projects/reservepty`

### Step 1.3 — Add Project to GitHub Desktop

1. Open **GitHub Desktop**
2. Go to **File → Add Local Repository**
3. Click **"Choose..."** and navigate to your extracted `reservepty` folder
4. You'll see a message: "This directory does not appear to be a Git repository"
5. Click **"create a repository"** link
6. Fill in:
   - **Name:** reservepty
   - **Local Path:** (should be pre-filled)
   - **Initialize with README:** UNCHECK this
   - **Git Ignore:** None
7. Click **"Create Repository"**

### Step 1.4 — Push to GitHub

1. In GitHub Desktop, click **"Publish repository"** (top bar)
2. Uncheck **"Keep this code private"** if you want it public (or leave checked for private)
3. Click **"Publish Repository"**
4. Wait for upload to complete

✅ **Your code is now on GitHub!**

---

## Part 2: Supabase Project Setup

### Step 2.1 — Create a New Supabase Project

1. Go to [supabase.com/dashboard](https://supabase.com/dashboard)
2. Click **"New Project"**
3. Select your organization (or create one)
4. Fill in:
   - **Project name:** `reservepty`
   - **Database Password:** Create a strong password → **SAVE THIS PASSWORD!**
   - **Region:** Choose closest to Panama (e.g., `us-east-1` or `sa-east-1`)
   - **Pricing Plan:** Free tier is fine for development
5. Click **"Create new project"**
6. Wait 2-3 minutes for project to be ready

### Step 2.2 — Get Your API Keys

1. Once project is ready, go to **Project Settings** (gear icon in sidebar)
2. Click **"API"** in the left menu
3. You'll see two important values — **copy and save both:**

```
Project URL:        https://xxxxxxxxxxxxx.supabase.co
anon public key:    eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
service_role key:   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (keep secret!)
```

⚠️ **Important:** The `service_role` key is secret — never expose it in frontend code!

### Step 2.3 — Run Database Migrations

Now we need to create all the database tables.

1. In Supabase Dashboard, click **"SQL Editor"** in the left sidebar
2. Click **"New query"** (top right)
3. Open the file `supabase/migrations/00001_initial_schema.sql` from your project folder
4. **Copy the ENTIRE contents** of the file
5. **Paste** into the SQL Editor
6. Click **"Run"** (or press Ctrl/Cmd + Enter)
7. Wait for it to complete — you should see "Success. No rows returned"

### Step 2.4 — Verify Tables Were Created

1. Click **"Table Editor"** in the left sidebar
2. You should see all these tables:
   - ✅ organizations
   - ✅ subscriptions
   - ✅ entitlements
   - ✅ seat_limits
   - ✅ profiles
   - ✅ organization_members
   - ✅ tiers
   - ✅ tier_rules
   - ✅ user_tiers
   - ✅ blackout_windows
   - ✅ assets
   - ✅ aircraft_details
   - ✅ boat_details
   - ✅ residence_details
   - ✅ asset_photos
   - ✅ asset_permissions
   - ✅ airports
   - ✅ ports
   - ✅ reservations
   - ✅ reservation_aviation_meta
   - ✅ reservation_boat_meta
   - ✅ reservation_residence_meta
   - ✅ reservation_status_history
   - ✅ maintenance_tasks
   - ✅ usage_logs

✅ **Database is ready!**

### Step 2.5 — Configure Authentication

1. In Supabase, click **"Authentication"** in the left sidebar
2. Click **"Providers"** tab
3. Make sure **Email** is enabled (it should be by default)
4. Optional: Configure additional providers (Google, etc.) later

### Step 2.6 — Configure Storage (for logos/photos)

1. Click **"Storage"** in the left sidebar
2. Click **"New bucket"**
3. Create these buckets:
   
   **Bucket 1: Organization Logos**
   - Name: `org-logos`
   - Public: ✅ ON
   - Click "Create bucket"
   
   **Bucket 2: Asset Photos**
   - Name: `asset-photos`
   - Public: ✅ ON
   - Click "Create bucket"

4. For each bucket, click on it → **Policies** → **New Policy**
5. Select **"For full customization"**
6. Add these policies:

**Policy for org-logos (allow authenticated uploads):**
```sql
-- Policy name: Allow authenticated uploads
CREATE POLICY "Allow authenticated uploads" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'org-logos');

-- Policy name: Allow public reads
CREATE POLICY "Allow public reads" ON storage.objects
FOR SELECT TO public
USING (bucket_id = 'org-logos');
```

Repeat similar for `asset-photos` bucket.

✅ **Supabase is fully configured!**

---

## Part 3: Local Development Setup

### Step 3.1 — Open Project in VS Code

1. Open **VS Code**
2. Go to **File → Open Folder**
3. Navigate to your `reservepty` folder and click **"Select Folder"**

### Step 3.2 — Create Environment File

1. In VS Code, find the file `apps/web/.env.example`
2. Right-click → **Copy**
3. Right-click in the same folder → **Paste**
4. Rename the copy to `.env.local`
5. Open `.env.local` and fill in your values:

```env
# Supabase (from Step 2.2)
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here

# Tilopay (use test credentials for now)
TILOPAY_API_KEY=6609-5850-8330-8034-3464
TILOPAY_API_USER=lSrT45
TILOPAY_API_PASSWORD=Zlb8H9
TILOPAY_ENVIRONMENT=sandbox

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME=ReservePTY
```

6. **Save the file** (Ctrl/Cmd + S)

### Step 3.3 — Install Dependencies

1. In VS Code, open the **Terminal**:
   - Windows: `View → Terminal` or press `` Ctrl + ` ``
   - Mac: `View → Terminal` or press `` Cmd + ` ``

2. Make sure you're in the project root folder:
   ```bash
   cd /path/to/reservepty
   ```

3. Install all packages:
   ```bash
   npm install
   ```

4. Wait for installation (this may take 2-3 minutes)

### Step 3.4 — Start Development Server

1. In the terminal, run:
   ```bash
   npm run dev
   ```

2. Wait until you see:
   ```
   ▲ Next.js 14.x.x
   - Local:        http://localhost:3000
   - Ready in Xs
   ```

3. Open your browser and go to: **http://localhost:3000**

🎉 **You should see the ReservePTY landing page!**

---

## Part 4: Netlify Deployment

### Step 4.1 — Create Netlify Account

1. Go to [netlify.com](https://www.netlify.com/)
2. Click **"Sign up"**
3. Choose **"Sign up with GitHub"** (easiest)
4. Authorize Netlify to access your GitHub

### Step 4.2 — Import Your Repository

1. In Netlify dashboard, click **"Add new site"**
2. Select **"Import an existing project"**
3. Click **"Deploy with GitHub"**
4. Find and select your `reservepty` repository
5. Configure build settings:
   - **Branch to deploy:** `main`
   - **Base directory:** `apps/web`
   - **Build command:** `npm run build`
   - **Publish directory:** `apps/web/.next`

### Step 4.3 — Add Environment Variables

1. Before deploying, click **"Show advanced"**
2. Click **"New variable"** and add each one:

| Key | Value |
|-----|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Your service role key |
| `TILOPAY_API_KEY` | Test: `6609-5850-8330-8034-3464` |
| `TILOPAY_API_USER` | Test: `lSrT45` |
| `TILOPAY_API_PASSWORD` | Test: `Zlb8H9` |
| `TILOPAY_ENVIRONMENT` | `sandbox` |

### Step 4.4 — Deploy

1. Click **"Deploy site"**
2. Wait for build (3-5 minutes first time)
3. Once complete, Netlify will give you a URL like: `https://random-name-123.netlify.app`

### Step 4.5 — Set Custom Domain (Optional)

1. Go to **Site settings → Domain management**
2. Click **"Add custom domain"**
3. Enter your domain (e.g., `reservepty.com`)
4. Follow DNS configuration instructions

✅ **Your site is live!**

---

## Part 5: Keeping Code in Sync

### Making Changes Locally

1. Edit files in VS Code
2. Save your changes
3. Test locally at `http://localhost:3000`

### Pushing Changes to GitHub

1. Open **GitHub Desktop**
2. You'll see changed files listed on the left
3. Write a summary of your changes (bottom left), e.g.:
   - "Add login page"
   - "Fix calendar styling"
4. Click **"Commit to main"**
5. Click **"Push origin"** (top bar)

### Automatic Deployment

- Netlify automatically detects new pushes to GitHub
- Your site will rebuild and deploy within 2-3 minutes
- No manual action needed!

---

## Troubleshooting

### "Module not found" errors
```bash
# Delete node_modules and reinstall
rm -rf node_modules
rm package-lock.json
npm install
```

### Database tables not showing
1. Go to Supabase SQL Editor
2. Re-run the migration file
3. Check for any error messages

### Site not loading locally
1. Make sure terminal shows "Ready"
2. Check you're at `http://localhost:3000` (not https)
3. Try a different browser or incognito mode

### Netlify build failing
1. Check build logs in Netlify dashboard
2. Make sure all environment variables are set
3. Verify the build command and directory are correct

---

## Quick Reference

| Service | URL |
|---------|-----|
| GitHub Repository | `github.com/your-username/reservepty` |
| Supabase Dashboard | `supabase.com/dashboard/project/your-project-id` |
| Netlify Dashboard | `app.netlify.com/sites/your-site-name` |
| Local Development | `http://localhost:3000` |
| Production Site | `https://your-site.netlify.app` |

---

## Next Steps

Once everything is running:

1. ✅ Explore the landing page
2. 🔜 We'll add authentication (Sign Up / Login)
3. 🔜 We'll add the organization onboarding flow
4. 🔜 We'll build the dashboard and calendar

Just let me know when you're ready to continue to **v0.2.0: Authentication & Onboarding**!

---

*Guide created: December 24, 2024*
*ReservePTY v0.1.0*
