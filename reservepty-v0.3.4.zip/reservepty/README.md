# ReservePTY

> Luxury Asset Booking Platform — Planes, Helicopters, Residences & Boats

![Version](https://img.shields.io/badge/version-0.1.0-gold)
![License](https://img.shields.io/badge/license-Private-navy)
![Next.js](https://img.shields.io/badge/Next.js-14-black)
![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green)

ReservePTY is a self-service SaaS platform for managing luxury assets. Organizations subscribe to enable modules (Planes, Helicopters, Residences, Boats) and manage bookings through a unified calendar.

---

## ✨ Features

- **Multi-Tenant Architecture** — Complete data isolation per organization
- **Modular Subscriptions** — Pay only for the asset types you need
- **Unified Calendar** — All assets, one view, with powerful filters
- **Aviation Intelligence** — Auto-calculate ETAs, enforce turnarounds
- **Tier-Based Booking** — Priority rules for family members or teams
- **Panama-Ready** — RUC/DV support, Tilopay payments (Yappy, SINPE)

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | Next.js 14 (App Router) |
| Database | Supabase (PostgreSQL) |
| Auth | Supabase Auth |
| Storage | Supabase Storage |
| Styling | Tailwind CSS |
| Animations | Framer Motion |
| State | TanStack Query + Zustand |
| Payments | Tilopay |
| Hosting | Netlify |

---

## 📁 Project Structure

```
reservepty/
├── apps/
│   └── web/                    # Next.js frontend
│       ├── app/                # App router pages
│       ├── components/         # React components
│       ├── hooks/              # Custom hooks
│       ├── lib/                # Utilities, clients
│       └── styles/             # Global CSS
├── packages/
│   ├── database/               # Shared DB types
│   ├── shared/                 # Shared utilities
│   └── config/                 # Shared configs
├── supabase/
│   ├── migrations/             # SQL migrations
│   └── functions/              # Edge functions
└── docs/                       # Documentation
```

---

## 🚀 Getting Started

### Prerequisites

- Node.js 20+
- npm 10+
- Supabase CLI
- Supabase account
- Tilopay merchant account

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-org/reservepty.git
   cd reservepty
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment**
   ```bash
   cp apps/web/.env.example apps/web/.env.local
   # Fill in your Supabase and Tilopay credentials
   ```

4. **Set up Supabase**
   ```bash
   # Link to your Supabase project
   supabase link --project-ref your-project-ref
   
   # Run migrations
   supabase db push
   ```

5. **Start development server**
   ```bash
   npm run dev
   ```

6. **Open browser**
   ```
   http://localhost:3000
   ```

---

## 🎨 Design System

### Colors

| Token | Hex | Usage |
|-------|-----|-------|
| `navy-950` | `#050a14` | Darkest background |
| `navy-900` | `#0a1628` | Primary background |
| `gold-400` | `#d4af37` | Primary accent |
| `stone-100` | `#fafaf9` | Primary text |

### Typography

- **Display:** Cormorant Garamond (headings)
- **Body:** DM Sans (content)
- **Mono:** JetBrains Mono (code/data)

### Components

```jsx
// Buttons
<button className="btn-primary">Primary</button>
<button className="btn-secondary">Secondary</button>
<button className="btn-ghost">Ghost</button>
<button className="btn-outline">Outline</button>

// Cards
<div className="card">Static card</div>
<div className="card-hover">Interactive card</div>
<div className="card-glass">Glass morphism</div>

// Inputs
<input className="input" placeholder="Enter text" />

// Badges
<span className="badge-gold">Premium</span>
<span className="badge-navy">Standard</span>
```

---

## 📊 Database Schema

### Core Tables

- `organizations` — Tenant accounts
- `subscriptions` — Billing & entitlements
- `organization_members` — User membership
- `tiers` — Booking priority levels
- `assets` — All asset types
- `reservations` — Bookings

### Section-Specific

- `aircraft_details` — Aviation specs
- `boat_details` — Marine specs
- `residence_details` — Property specs

See `supabase/migrations/00001_initial_schema.sql` for complete schema.

---

## 🔐 Security

- Row Level Security (RLS) enabled on all tables
- Tenant isolation via `organization_id` scoping
- RBAC with owner/admin/manager/member/viewer roles
- Supabase Auth for authentication
- Service role key server-side only

---

## 📦 Deployment

### Netlify

1. Connect GitHub repository
2. Set build command: `npm run build`
3. Set publish directory: `apps/web/.next`
4. Add environment variables
5. Deploy

### Environment Variables

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
TILOPAY_API_KEY=
TILOPAY_API_USER=
TILOPAY_API_PASSWORD=
```

---

## 📝 Version History

See [VERSION_HISTORY.md](./VERSION_HISTORY.md) for detailed changelog.

| Version | Date | Status |
|---------|------|--------|
| 0.1.0 | Dec 2024 | ✅ Foundation |
| 0.2.0 | TBD | 🔲 Auth & Onboarding |
| 0.3.0 | TBD | 🔲 Billing |
| 0.4.0 | TBD | 🔲 Assets |
| 0.5.0 | TBD | 🔲 Bookings |
| 1.0.0 | TBD | 🔲 MVP Launch |

---

## 🤝 Contributing

This is a private project. Contact the project owner for contribution guidelines.

---

## 📄 License

Private and Confidential. All rights reserved.

---

<p align="center">
  <strong>ReservePTY</strong> — Built with ❤️ in Panama
</p>
