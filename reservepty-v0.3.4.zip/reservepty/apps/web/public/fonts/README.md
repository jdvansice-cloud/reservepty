# Fonts Directory

## Didot LT Pro Setup

Didot LT Pro is a commercial font. To use it:

1. Purchase/obtain the font from a licensed source
2. Convert to web formats if needed (woff2, woff)
3. Add the following files to this directory:

```
/public/fonts/
├── DidotLTPro-Roman.woff2
├── DidotLTPro-Roman.woff
├── DidotLTPro-Italic.woff2
├── DidotLTPro-Italic.woff
├── DidotLTPro-Bold.woff2
└── DidotLTPro-Bold.woff
```

## Fallback Fonts

If Didot LT Pro is not available, the site will automatically fall back to:
1. **Bodoni Moda** (Google Fonts - similar Didone style)
2. **Georgia** (System font)

The fallback fonts are already configured and will work without any additional setup.

## Font Conversion

If you have TTF/OTF files, you can convert them to web fonts using:
- [Transfonter](https://transfonter.org/)
- [Font Squirrel Generator](https://www.fontsquirrel.com/tools/webfont-generator)
