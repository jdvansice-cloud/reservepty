import Link from 'next/link'
import { Sparkles } from 'lucide-react'

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-navy-950 flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-navy-600/30 rounded-full blur-3xl" />
        
        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-gold-glow">
              <Sparkles className="w-6 h-6 text-navy-950" />
            </div>
            <span className="font-display text-3xl font-semibold tracking-tight text-stone-50">
              Reserve<span className="text-gold-400">PTY</span>
            </span>
          </Link>
          
          {/* Tagline */}
          <div className="max-w-md">
            <h1 className="font-display text-4xl font-medium text-stone-50 mb-4">
              Manage Your Luxury Assets with Elegance
            </h1>
            <p className="text-lg text-stone-400">
              One platform for all your planes, helicopters, residences, and boats. 
              Unified booking, complete control.
            </p>
          </div>
          
          {/* Footer */}
          <p className="text-sm text-stone-600">
            © {new Date().getFullYear()} ReservePTY. Panama.
          </p>
        </div>
      </div>
      
      {/* Right side - Auth forms */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden mb-8 text-center">
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-navy-950" />
              </div>
              <span className="font-display text-2xl font-semibold tracking-tight text-stone-50">
                Reserve<span className="text-gold-400">PTY</span>
              </span>
            </Link>
          </div>
          
          {children}
        </div>
      </div>
    </div>
  )
}
