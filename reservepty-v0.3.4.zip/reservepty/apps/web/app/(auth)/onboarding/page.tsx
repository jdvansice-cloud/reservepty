'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { 
  ArrowRight, 
  ArrowLeft, 
  Loader2, 
  Building2, 
  Upload,
  Plane,
  Ship,
  Home,
  Check
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

type Step = 'company' | 'sections' | 'complete'

const SECTIONS = [
  { 
    id: 'planes', 
    name: 'Aviation — Planes', 
    icon: Plane, 
    description: 'Manage aircraft bookings, flight logs, and maintenance',
    price: 99 
  },
  { 
    id: 'helicopters', 
    name: 'Aviation — Helicopters', 
    icon: Plane, 
    description: 'Helicopter scheduling with helipad directories',
    price: 99 
  },
  { 
    id: 'residences', 
    name: 'Residences & Spaces', 
    icon: Home, 
    description: 'Villas, apartments, meeting rooms with check-in/out',
    price: 79 
  },
  { 
    id: 'boats', 
    name: 'Boats & Yachts', 
    icon: Ship, 
    description: 'Marine assets with port directories and captain scheduling',
    price: 79 
  },
]

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('company')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  // Company form data
  const [company, setCompany] = useState({
    legalName: '',
    commercialName: '',
    ruc: '',
    dv: '',
    billingEmail: '',
    phone: '',
    country: 'Panama',
  })
  
  // Selected sections
  const [selectedSections, setSelectedSections] = useState<string[]>([])
  
  // Logo file
  const [logoFile, setLogoFile] = useState<File | null>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)

  const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setCompany(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
    setError(null)
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setLogoFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setLogoPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const toggleSection = (sectionId: string) => {
    setSelectedSections(prev => 
      prev.includes(sectionId)
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    )
  }

  const handleCompanySubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate RUC format (basic validation)
    if (company.ruc && !/^\d{1,2}-\d{3,4}-\d{4,6}$/.test(company.ruc)) {
      setError('Invalid RUC format. Expected format: XX-XXXX-XXXXX')
      return
    }
    
    // Validate DV format
    if (company.dv && !/^\d{2}$/.test(company.dv)) {
      setError('Invalid DV format. Expected 2 digits.')
      return
    }
    
    setStep('sections')
  }

  const handleSectionsSubmit = async () => {
    if (selectedSections.length === 0) {
      setError('Please select at least one section')
      return
    }
    
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()
      
      // Get current user
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        router.push('/login')
        return
      }

      // Upload logo if provided
      let logoUrl = null
      if (logoFile) {
        const fileExt = logoFile.name.split('.').pop()
        const fileName = `${user.id}-${Date.now()}.${fileExt}`
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('org-logos')
          .upload(fileName, logoFile)
        
        if (uploadError) {
          console.error('Logo upload error:', uploadError)
        } else {
          const { data: { publicUrl } } = supabase.storage
            .from('org-logos')
            .getPublicUrl(fileName)
          logoUrl = publicUrl
        }
      }

      // Create organization
      const { data: org, error: orgError } = await supabase
        .from('organizations')
        .insert({
          legal_name: company.legalName,
          commercial_name: company.commercialName || null,
          ruc: company.ruc || null,
          dv: company.dv || null,
          billing_email: company.billingEmail,
          phone: company.phone || null,
          country: company.country,
          logo_url: logoUrl,
        })
        .select()
        .single()

      if (orgError) {
        setError(orgError.message)
        return
      }

      // Create user profile if it doesn't exist
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          full_name: user.user_metadata?.full_name || '',
        })

      if (profileError) {
        console.error('Profile error:', profileError)
      }

      // Add user as org owner
      const { error: memberError } = await supabase
        .from('organization_members')
        .insert({
          organization_id: org.id,
          user_id: user.id,
          role: 'owner',
          joined_at: new Date().toISOString(),
        })

      if (memberError) {
        setError(memberError.message)
        return
      }

      // Create subscription (trial)
      const { data: subscription, error: subError } = await supabase
        .from('subscriptions')
        .insert({
          organization_id: org.id,
          status: 'trialing',
          billing_interval: 'monthly',
          trial_end: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 days
        })
        .select()
        .single()

      if (subError) {
        setError(subError.message)
        return
      }

      // Create entitlements for selected sections
      const entitlements = selectedSections.map(section => ({
        subscription_id: subscription.id,
        section: section,
        enabled: true,
      }))

      const { error: entError } = await supabase
        .from('entitlements')
        .insert(entitlements)

      if (entError) {
        setError(entError.message)
        return
      }

      // Create seat limit
      const { error: seatError } = await supabase
        .from('seat_limits')
        .insert({
          subscription_id: subscription.id,
          max_seats: 5,
          used_seats: 1,
        })

      if (seatError) {
        console.error('Seat error:', seatError)
      }

      // Create default tiers
      const defaultTiers = [
        { name: 'Tier 1', priority: 1, color: '#c8b273' },
        { name: 'Tier 2', priority: 2, color: '#78716c' },
      ]

      for (const tier of defaultTiers) {
        await supabase
          .from('tiers')
          .insert({
            organization_id: org.id,
            ...tier,
          })
      }

      setStep('complete')
      
      // Redirect to dashboard after a moment
      setTimeout(() => {
        router.push('/dashboard')
        router.refresh()
      }, 2000)

    } catch (err) {
      console.error('Onboarding error:', err)
      setError('An unexpected error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const totalPrice = selectedSections.reduce((sum, id) => {
    const section = SECTIONS.find(s => s.id === id)
    return sum + (section?.price || 0)
  }, 0)

  // Step indicators
  const steps = [
    { id: 'company', label: 'Organization' },
    { id: 'sections', label: 'Sections' },
    { id: 'complete', label: 'Complete' },
  ]

  return (
    <div className="min-h-screen bg-navy-950 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Progress indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-center gap-4">
            {steps.map((s, i) => (
              <div key={s.id} className="flex items-center">
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center font-medium text-sm
                  ${step === s.id 
                    ? 'bg-gold-400 text-navy-950' 
                    : steps.indexOf(steps.find(st => st.id === step)!) > i
                    ? 'bg-green-500 text-white'
                    : 'bg-navy-800 text-stone-500'
                  }
                `}>
                  {steps.indexOf(steps.find(st => st.id === step)!) > i ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    i + 1
                  )}
                </div>
                {i < steps.length - 1 && (
                  <div className={`w-16 h-0.5 mx-2 ${
                    steps.indexOf(steps.find(st => st.id === step)!) > i
                      ? 'bg-green-500'
                      : 'bg-navy-800'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-4">
            <span className="text-sm text-stone-400">
              {steps.find(s => s.id === step)?.label}
            </span>
          </div>
        </div>

        {/* Step: Company Info */}
        {step === 'company' && (
          <div className="card p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 rounded-2xl bg-gold-400/10 border border-gold-400/20 flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-gold-400" />
              </div>
              <h1 className="font-display text-2xl font-medium text-stone-50 mb-2">
                Set Up Your Organization
              </h1>
              <p className="text-stone-400">
                Tell us about your company or family group
              </p>
            </div>

            <form onSubmit={handleCompanySubmit} className="space-y-5">
              {/* Legal Name */}
              <div>
                <label htmlFor="legalName" className="input-label">
                  Legal Name *
                </label>
                <input
                  id="legalName"
                  name="legalName"
                  type="text"
                  required
                  value={company.legalName}
                  onChange={handleCompanyChange}
                  className="input"
                  placeholder="Company S.A."
                />
              </div>

              {/* Commercial Name */}
              <div>
                <label htmlFor="commercialName" className="input-label">
                  Commercial Name (optional)
                </label>
                <input
                  id="commercialName"
                  name="commercialName"
                  type="text"
                  value={company.commercialName}
                  onChange={handleCompanyChange}
                  className="input"
                  placeholder="Brand name if different"
                />
              </div>

              {/* RUC and DV */}
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                  <label htmlFor="ruc" className="input-label">
                    RUC (Panama Tax ID)
                  </label>
                  <input
                    id="ruc"
                    name="ruc"
                    type="text"
                    value={company.ruc}
                    onChange={handleCompanyChange}
                    className="input"
                    placeholder="XX-XXXX-XXXXX"
                  />
                </div>
                <div>
                  <label htmlFor="dv" className="input-label">
                    DV
                  </label>
                  <input
                    id="dv"
                    name="dv"
                    type="text"
                    maxLength={2}
                    value={company.dv}
                    onChange={handleCompanyChange}
                    className="input"
                    placeholder="00"
                  />
                </div>
              </div>

              {/* Billing Email */}
              <div>
                <label htmlFor="billingEmail" className="input-label">
                  Billing Email *
                </label>
                <input
                  id="billingEmail"
                  name="billingEmail"
                  type="email"
                  required
                  value={company.billingEmail}
                  onChange={handleCompanyChange}
                  className="input"
                  placeholder="billing@company.com"
                />
              </div>

              {/* Phone */}
              <div>
                <label htmlFor="phone" className="input-label">
                  Phone Number
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={company.phone}
                  onChange={handleCompanyChange}
                  className="input"
                  placeholder="+507 6000-0000"
                />
              </div>

              {/* Logo Upload */}
              <div>
                <label className="input-label">
                  Company Logo (optional)
                </label>
                <div className="flex items-center gap-4">
                  {logoPreview ? (
                    <div className="w-20 h-20 rounded-xl overflow-hidden bg-navy-800 border border-navy-700">
                      <img src={logoPreview} alt="Logo preview" className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <div className="w-20 h-20 rounded-xl bg-navy-800 border border-navy-700 border-dashed flex items-center justify-center">
                      <Upload className="w-6 h-6 text-stone-500" />
                    </div>
                  )}
                  <label className="btn-secondary cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoChange}
                      className="hidden"
                    />
                    {logoPreview ? 'Change Logo' : 'Upload Logo'}
                  </label>
                </div>
              </div>

              {/* Error message */}
              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                  <p className="text-sm text-red-400">{error}</p>
                </div>
              )}

              {/* Submit */}
              <button type="submit" className="btn-primary w-full">
                Continue
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>
        )}

        {/* Step: Select Sections */}
        {step === 'sections' && (
          <div className="card p-8">
            <div className="text-center mb-8">
              <h1 className="font-display text-2xl font-medium text-stone-50 mb-2">
                Choose Your Sections
              </h1>
              <p className="text-stone-400">
                Select the asset types you want to manage
              </p>
            </div>

            <div className="space-y-4 mb-8">
              {SECTIONS.map((section) => {
                const isSelected = selectedSections.includes(section.id)
                const Icon = section.icon
                
                return (
                  <button
                    key={section.id}
                    type="button"
                    onClick={() => toggleSection(section.id)}
                    className={`
                      w-full p-4 rounded-xl border text-left transition-all duration-200
                      ${isSelected 
                        ? 'bg-gold-400/10 border-gold-400/50' 
                        : 'bg-navy-800/50 border-navy-700/50 hover:border-navy-600'
                      }
                    `}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`
                        w-12 h-12 rounded-xl flex items-center justify-center shrink-0
                        ${isSelected ? 'bg-gold-400/20' : 'bg-navy-700/50'}
                      `}>
                        <Icon className={`w-6 h-6 ${isSelected ? 'text-gold-400' : 'text-stone-400'}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className={`font-medium ${isSelected ? 'text-stone-50' : 'text-stone-200'}`}>
                            {section.name}
                          </span>
                          <span className={`text-sm font-medium ${isSelected ? 'text-gold-400' : 'text-stone-400'}`}>
                            ${section.price}/mo
                          </span>
                        </div>
                        <p className="text-sm text-stone-500">
                          {section.description}
                        </p>
                      </div>
                      <div className={`
                        w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0
                        ${isSelected 
                          ? 'bg-gold-400 border-gold-400' 
                          : 'border-stone-600'
                        }
                      `}>
                        {isSelected && <Check className="w-4 h-4 text-navy-950" />}
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Price summary */}
            <div className="p-4 bg-navy-800/50 rounded-xl mb-6">
              <div className="flex items-center justify-between">
                <span className="text-stone-400">Monthly total</span>
                <span className="text-2xl font-display text-gold-400">
                  ${totalPrice}<span className="text-sm text-stone-500">/mo</span>
                </span>
              </div>
              <p className="text-xs text-stone-500 mt-1">
                14-day free trial • No credit card required
              </p>
            </div>

            {/* Error message */}
            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg mb-6">
                <p className="text-sm text-red-400">{error}</p>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => setStep('company')}
                className="btn-ghost"
              >
                <ArrowLeft className="w-5 h-5" />
                Back
              </button>
              <button
                type="button"
                onClick={handleSectionsSubmit}
                disabled={isLoading || selectedSections.length === 0}
                className="btn-primary flex-1"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    Start Free Trial
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Step: Complete */}
        {step === 'complete' && (
          <div className="card p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-500" />
            </div>
            <h1 className="font-display text-2xl font-medium text-stone-50 mb-2">
              Welcome to ReservePTY!
            </h1>
            <p className="text-stone-400 mb-2">
              Your organization is ready. Redirecting to your dashboard...
            </p>
            <div className="flex justify-center">
              <Loader2 className="w-6 h-6 text-gold-400 animate-spin" />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
