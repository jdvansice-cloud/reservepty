'use client'

import { useState, useEffect } from 'react'
import {
  DollarSign,
  TrendingUp,
  CreditCard,
  Calendar,
  Users,
  Plane,
  Ship,
  Home,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function RevenuePage() {
  const [stats, setStats] = useState({
    mrr: 0,
    arr: 0,
    activeSubscriptions: 0,
    trialConversions: 0,
    avgRevenuePerUser: 0,
    sectionRevenue: {
      planes: 0,
      helicopters: 0,
      residences: 0,
      boats: 0,
    }
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadRevenueData()
  }, [])

  const loadRevenueData = async () => {
    const supabase = createClient()

    try {
      // Get entitlements for revenue calculation
      const { data: entitlements } = await supabase
        .from('entitlements')
        .select('section')
        .eq('enabled', true)

      const pricing = { planes: 99, helicopters: 99, residences: 79, boats: 79 }
      
      const sectionRevenue = {
        planes: (entitlements?.filter(e => e.section === 'planes').length || 0) * pricing.planes,
        helicopters: (entitlements?.filter(e => e.section === 'helicopters').length || 0) * pricing.helicopters,
        residences: (entitlements?.filter(e => e.section === 'residences').length || 0) * pricing.residences,
        boats: (entitlements?.filter(e => e.section === 'boats').length || 0) * pricing.boats,
      }

      const mrr = Object.values(sectionRevenue).reduce((a, b) => a + b, 0)

      const { count: activeSubscriptions } = await supabase
        .from('subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active')

      setStats({
        mrr,
        arr: mrr * 12,
        activeSubscriptions: activeSubscriptions || 0,
        trialConversions: 0,
        avgRevenuePerUser: activeSubscriptions ? mrr / activeSubscriptions : 0,
        sectionRevenue,
      })
    } catch (err) {
      console.error('Error loading revenue data:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-stone-900 border border-stone-800 rounded-xl p-6 animate-pulse">
              <div className="h-4 bg-stone-800 rounded w-1/2 mb-4" />
              <div className="h-8 bg-stone-800 rounded w-1/3" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
          Revenue Dashboard
        </h1>
        <p className="text-stone-400">
          Track platform revenue and subscription metrics
        </p>
      </div>

      {/* Main stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-stone-400">Monthly Revenue (MRR)</span>
            <div className="p-2 rounded-lg bg-green-500/10">
              <DollarSign className="w-5 h-5 text-green-400" />
            </div>
          </div>
          <p className="text-3xl font-display font-medium text-stone-50">
            {formatCurrency(stats.mrr)}
          </p>
          <div className="flex items-center gap-1 mt-2 text-green-400 text-sm">
            <ArrowUpRight className="w-4 h-4" />
            <span>+12% from last month</span>
          </div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-stone-400">Annual Revenue (ARR)</span>
            <div className="p-2 rounded-lg bg-blue-500/10">
              <TrendingUp className="w-5 h-5 text-blue-400" />
            </div>
          </div>
          <p className="text-3xl font-display font-medium text-stone-50">
            {formatCurrency(stats.arr)}
          </p>
          <p className="text-sm text-stone-500 mt-2">Projected annual</p>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-stone-400">Active Subscriptions</span>
            <div className="p-2 rounded-lg bg-purple-500/10">
              <CreditCard className="w-5 h-5 text-purple-400" />
            </div>
          </div>
          <p className="text-3xl font-display font-medium text-stone-50">
            {stats.activeSubscriptions}
          </p>
          <p className="text-sm text-stone-500 mt-2">Paying customers</p>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-stone-400">Avg Revenue/Customer</span>
            <div className="p-2 rounded-lg bg-yellow-500/10">
              <Users className="w-5 h-5 text-yellow-400" />
            </div>
          </div>
          <p className="text-3xl font-display font-medium text-stone-50">
            {formatCurrency(stats.avgRevenuePerUser)}
          </p>
          <p className="text-sm text-stone-500 mt-2">ARPU per month</p>
        </div>
      </div>

      {/* Revenue by section */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Revenue by Section
          </h2>
          <div className="space-y-4">
            {[
              { name: 'Planes', value: stats.sectionRevenue.planes, icon: Plane, color: 'text-blue-400', bg: 'bg-blue-400' },
              { name: 'Helicopters', value: stats.sectionRevenue.helicopters, icon: Plane, color: 'text-purple-400', bg: 'bg-purple-400' },
              { name: 'Residences', value: stats.sectionRevenue.residences, icon: Home, color: 'text-green-400', bg: 'bg-green-400' },
              { name: 'Boats', value: stats.sectionRevenue.boats, icon: Ship, color: 'text-cyan-400', bg: 'bg-cyan-400' },
            ].map((section) => {
              const percentage = stats.mrr > 0 ? (section.value / stats.mrr) * 100 : 0
              return (
                <div key={section.name}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <section.icon className={`w-4 h-4 ${section.color}`} />
                      <span className="text-stone-300">{section.name}</span>
                    </div>
                    <span className="text-stone-50 font-medium">{formatCurrency(section.value)}</span>
                  </div>
                  <div className="h-2 bg-stone-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${section.bg} rounded-full`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Pricing Overview
          </h2>
          <div className="space-y-4">
            <div className="p-4 bg-stone-800/50 rounded-xl">
              <p className="text-sm text-stone-400 mb-1">Aviation Sections</p>
              <p className="text-2xl font-display text-stone-50">$99<span className="text-sm text-stone-500">/mo each</span></p>
              <p className="text-xs text-stone-500 mt-1">Planes, Helicopters</p>
            </div>
            <div className="p-4 bg-stone-800/50 rounded-xl">
              <p className="text-sm text-stone-400 mb-1">Property & Marine</p>
              <p className="text-2xl font-display text-stone-50">$79<span className="text-sm text-stone-500">/mo each</span></p>
              <p className="text-xs text-stone-500 mt-1">Residences, Boats</p>
            </div>
            <div className="p-4 bg-stone-800/50 rounded-xl">
              <p className="text-sm text-stone-400 mb-1">Seat Pricing</p>
              <p className="text-stone-300 text-sm">5 seats free, then tiered pricing at 10/25/50/100</p>
            </div>
          </div>
        </div>
      </div>

      {/* Note */}
      <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
        <p className="text-sm text-yellow-400">
          <strong>Note:</strong> Revenue figures are calculated from active entitlements. 
          Actual payment processing will be integrated with Tilopay in a future update.
        </p>
      </div>
    </div>
  )
}
