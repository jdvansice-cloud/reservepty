'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  Search,
  Building2,
  Users,
  Calendar,
  MoreVertical,
  Eye,
  Gift,
  Ban,
  CheckCircle,
  X,
  Filter,
  Download
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface Organization {
  id: string
  legal_name: string
  commercial_name: string | null
  ruc: string | null
  billing_email: string
  country: string
  created_at: string
  deleted_at: string | null
  subscriptions: {
    status: string
    billing_interval: string
  }[]
  organization_members: { count: number }[]
  assets: { count: number }[]
}

export default function OrganizationsPage() {
  const [organizations, setOrganizations] = useState<Organization[]>([])
  const [filteredOrgs, setFilteredOrgs] = useState<Organization[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [openMenu, setOpenMenu] = useState<string | null>(null)

  useEffect(() => {
    loadOrganizations()
  }, [])

  useEffect(() => {
    filterOrganizations()
  }, [organizations, searchQuery, statusFilter])

  const loadOrganizations = async () => {
    const supabase = createClient()

    const { data, error } = await supabase
      .from('organizations')
      .select(`
        *,
        subscriptions (
          status,
          billing_interval
        ),
        organization_members (count),
        assets (count)
      `)
      .order('created_at', { ascending: false })

    if (!error && data) {
      setOrganizations(data)
    }
    setIsLoading(false)
  }

  const filterOrganizations = () => {
    let filtered = [...organizations]

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(org =>
        org.legal_name.toLowerCase().includes(query) ||
        org.commercial_name?.toLowerCase().includes(query) ||
        org.billing_email.toLowerCase().includes(query) ||
        org.ruc?.toLowerCase().includes(query)
      )
    }

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(org => {
        const status = org.subscriptions?.[0]?.status
        if (statusFilter === 'active') return status === 'active'
        if (statusFilter === 'trial') return status === 'trialing'
        if (statusFilter === 'inactive') return !status || status === 'canceled'
        return true
      })
    }

    setFilteredOrgs(filtered)
  }

  const getStatusBadge = (org: Organization) => {
    const status = org.subscriptions?.[0]?.status
    if (org.deleted_at) {
      return <span className="px-2 py-0.5 text-xs rounded bg-red-500/10 text-red-400 border border-red-500/20">Deleted</span>
    }
    switch (status) {
      case 'active':
        return <span className="px-2 py-0.5 text-xs rounded bg-green-500/10 text-green-400 border border-green-500/20">Active</span>
      case 'trialing':
        return <span className="px-2 py-0.5 text-xs rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">Trial</span>
      default:
        return <span className="px-2 py-0.5 text-xs rounded bg-stone-500/10 text-stone-400 border border-stone-500/20">Inactive</span>
    }
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="bg-stone-900 border border-stone-800 rounded-xl">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="p-4 border-b border-stone-800 animate-pulse">
              <div className="h-5 bg-stone-800 rounded w-1/3 mb-2" />
              <div className="h-4 bg-stone-800 rounded w-1/4" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Organizations
          </h1>
          <p className="text-stone-400">
            Manage all registered organizations
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-ghost flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
          <Link 
            href="/admin/organizations/new"
            className="flex items-center gap-2 px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white font-medium rounded-xl transition-colors"
          >
            <Building2 className="w-4 h-4" />
            Create Organization
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-500" />
          <input
            type="text"
            placeholder="Search organizations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2.5 pl-12 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-red-500/50"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Status filter */}
        <div className="flex gap-2">
          {['all', 'active', 'trial', 'inactive'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
                statusFilter === status
                  ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                  : 'bg-stone-800 text-stone-400 border border-stone-700 hover:border-stone-600'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Total</p>
          <p className="text-2xl font-display text-stone-50">{organizations.length}</p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Active</p>
          <p className="text-2xl font-display text-green-400">
            {organizations.filter(o => o.subscriptions?.[0]?.status === 'active').length}
          </p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Trial</p>
          <p className="text-2xl font-display text-yellow-400">
            {organizations.filter(o => o.subscriptions?.[0]?.status === 'trialing').length}
          </p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Inactive</p>
          <p className="text-2xl font-display text-stone-400">
            {organizations.filter(o => !o.subscriptions?.[0]?.status || o.subscriptions?.[0]?.status === 'canceled').length}
          </p>
        </div>
      </div>

      {/* Organizations table */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone-800">
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Organization</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Status</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Members</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Assets</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Created</th>
                <th className="text-right px-6 py-4 text-sm font-medium text-stone-400">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrgs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-stone-500">
                    No organizations found
                  </td>
                </tr>
              ) : (
                filteredOrgs.map((org) => (
                  <tr key={org.id} className="border-b border-stone-800 hover:bg-stone-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-stone-100">
                          {org.commercial_name || org.legal_name}
                        </p>
                        <p className="text-sm text-stone-500">{org.billing_email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {getStatusBadge(org)}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-stone-300">
                        <Users className="w-4 h-4 text-stone-500" />
                        {org.organization_members?.[0]?.count || 0}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-stone-300">
                        <Building2 className="w-4 h-4 text-stone-500" />
                        {org.assets?.[0]?.count || 0}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-stone-400">
                      {formatDate(org.created_at)}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end relative">
                        <button
                          onClick={() => setOpenMenu(openMenu === org.id ? null : org.id)}
                          className="p-2 rounded-lg text-stone-500 hover:text-stone-300 hover:bg-stone-700 transition-colors"
                        >
                          <MoreVertical className="w-5 h-5" />
                        </button>

                        {openMenu === org.id && (
                          <>
                            <div 
                              className="fixed inset-0 z-10" 
                              onClick={() => setOpenMenu(null)}
                            />
                            <div className="absolute right-0 top-full mt-1 w-48 bg-stone-800 border border-stone-700 rounded-xl shadow-lg z-20 py-1">
                              <Link
                                href={`/admin/organizations/${org.id}`}
                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-stone-700 transition-colors"
                                onClick={() => setOpenMenu(null)}
                              >
                                <Eye className="w-4 h-4" />
                                View Details
                              </Link>
                              <Link
                                href={`/admin/complimentary/new?org=${org.id}`}
                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-stone-700 transition-colors"
                                onClick={() => setOpenMenu(null)}
                              >
                                <Gift className="w-4 h-4" />
                                Grant Complimentary
                              </Link>
                              <button
                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-stone-700 transition-colors w-full"
                                onClick={() => setOpenMenu(null)}
                              >
                                <Ban className="w-4 h-4" />
                                Suspend
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
