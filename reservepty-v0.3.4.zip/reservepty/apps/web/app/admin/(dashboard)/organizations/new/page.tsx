'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { 
  ArrowLeft, 
  Building2, 
  Loader2, 
  Check,
  Plane,
  Ship,
  Home,
  CircleDot,
  User,
  Mail,
  Lock,
  Gift
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const sections = [
  { id: 'planes', name: 'Aviation — Planes', icon: Plane, price: 299 },
  { id: 'helicopters', name: 'Aviation — Helicopters', icon: CircleDot, price: 299 },
  { id: 'residences', name: 'Residences / Spaces', icon: Home, price: 199 },
  { id: 'boats', name: 'Boats / Yachts', icon: Ship, price: 249 },
]

const seatTiers = [5, 10, 25, 50, 100]

export default function NewOrganizationPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  
  const [formData, setFormData] = useState({
    // Organization
    legalName: '',
    commercialName: '',
    ruc: '',
    dv: '',
    billingEmail: '',
    phone: '',
    country: 'Panama',
    
    // Owner user
    ownerEmail: '',
    ownerPassword: '',
    ownerName: '',
    
    // Subscription
    selectedSections: [] as string[],
    seatTier: 5,
    isComplimentary: true,
    trialDays: 14,
    notes: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
    setError(null)
  }

  const toggleSection = (sectionId: string) => {
    setFormData(prev => ({
      ...prev,
      selectedSections: prev.selectedSections.includes(sectionId)
        ? prev.selectedSections.filter(s => s !== sectionId)
        : [...prev.selectedSections, sectionId]
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Validate
      if (formData.selectedSections.length === 0) {
        setError('Please select at least one section')
        setIsLoading(false)
        return
      }

      // Step 1: Create the user in Supabase Auth
      // Note: This requires the service role key on the server side
      // For now, we'll create the user via the admin API
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.ownerEmail,
        password: formData.ownerPassword,
        options: {
          data: {
            full_name: formData.ownerName,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        }
      })

      if (authError) {
        // Check if user already exists
        if (authError.message.includes('already registered')) {
          setError('A user with this email already exists. Use a different email or add them to an existing organization.')
        } else {
          setError(authError.message)
        }
        setIsLoading(false)
        return
      }

      if (!authData.user) {
        setError('Failed to create user')
        setIsLoading(false)
        return
      }

      // Step 2: Create the organization
      const { data: org, error: orgError } = await supabase
        .from('organizations')
        .insert({
          legal_name: formData.legalName,
          commercial_name: formData.commercialName || null,
          ruc: formData.ruc || null,
          dv: formData.dv || null,
          billing_email: formData.billingEmail || formData.ownerEmail,
          phone: formData.phone || null,
          country: formData.country,
        })
        .select()
        .single()

      if (orgError) {
        setError(`Failed to create organization: ${orgError.message}`)
        setIsLoading(false)
        return
      }

      // Step 3: Add user as organization owner
      const { error: memberError } = await supabase
        .from('organization_members')
        .insert({
          organization_id: org.id,
          user_id: authData.user.id,
          role: 'owner',
        })

      if (memberError) {
        setError(`Failed to add member: ${memberError.message}`)
        setIsLoading(false)
        return
      }

      // Step 4: Create subscription
      const trialEnd = new Date()
      trialEnd.setDate(trialEnd.getDate() + (formData.isComplimentary ? 365 : formData.trialDays))
      
      const { data: subscription, error: subError } = await supabase
        .from('subscriptions')
        .insert({
          organization_id: org.id,
          status: formData.isComplimentary ? 'active' : 'trialing',
          billing_cycle: 'yearly',
          current_period_start: new Date().toISOString(),
          current_period_end: trialEnd.toISOString(),
          trial_end: formData.isComplimentary ? null : trialEnd.toISOString(),
          seat_limit: formData.seatTier,
        })
        .select()
        .single()

      if (subError) {
        setError(`Failed to create subscription: ${subError.message}`)
        setIsLoading(false)
        return
      }

      // Step 5: Create entitlements for selected sections
      const entitlements = formData.selectedSections.map(section => ({
        subscription_id: subscription.id,
        section: section,
        is_active: true,
      }))

      const { error: entError } = await supabase
        .from('entitlements')
        .insert(entitlements)

      if (entError) {
        setError(`Failed to create entitlements: ${entError.message}`)
        setIsLoading(false)
        return
      }

      // Step 6: If complimentary, create a record
      if (formData.isComplimentary) {
        const { data: { user: currentAdmin } } = await supabase.auth.getUser()
        
        if (currentAdmin) {
          const { data: adminData } = await supabase
            .from('platform_admins')
            .select('id')
            .eq('user_id', currentAdmin.id)
            .single()

          if (adminData) {
            await supabase
              .from('complimentary_memberships')
              .insert({
                organization_id: org.id,
                granted_by: adminData.id,
                sections: formData.selectedSections,
                seat_limit: formData.seatTier,
                reason: formData.notes || 'Created via admin portal',
                expires_at: trialEnd.toISOString(),
              })
          }
        }
      }

      // Step 7: Log activity
      const { data: { user: currentAdmin } } = await supabase.auth.getUser()
      if (currentAdmin) {
        const { data: adminData } = await supabase
          .from('platform_admins')
          .select('id')
          .eq('user_id', currentAdmin.id)
          .single()

        if (adminData) {
          await supabase
            .from('platform_activity_logs')
            .insert({
              admin_id: adminData.id,
              action: 'create_organization',
              target_type: 'organization',
              target_id: org.id,
              details: {
                organization_name: formData.legalName,
                owner_email: formData.ownerEmail,
                sections: formData.selectedSections,
                is_complimentary: formData.isComplimentary,
              }
            })
        }
      }

      setSuccess(true)
      
      // Redirect after 2 seconds
      setTimeout(() => {
        router.push('/admin/organizations')
      }, 2000)

    } catch (err) {
      console.error('Error creating organization:', err)
      setError('An unexpected error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  if (success) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-400" />
          </div>
          <h2 className="text-xl font-semibold text-stone-50 mb-2">Organization Created!</h2>
          <p className="text-stone-400 mb-4">
            The organization has been created and the owner has been notified via email.
          </p>
          <p className="text-sm text-stone-500">
            Redirecting to organizations list...
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link 
          href="/admin/organizations"
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Organizations
        </Link>
        <h1 className="text-2xl font-display font-semibold text-stone-50">
          Create New Organization
        </h1>
        <p className="text-stone-400 mt-1">
          Create an organization with an owner account and subscription
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Organization Details */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-stone-50">Organization Details</h2>
              <p className="text-sm text-stone-500">Company information</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Legal Name *
              </label>
              <input
                type="text"
                name="legalName"
                required
                value={formData.legalName}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="Company Legal Name S.A."
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Commercial Name
              </label>
              <input
                type="text"
                name="commercialName"
                value={formData.commercialName}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="Brand Name (optional)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                RUC
              </label>
              <input
                type="text"
                name="ruc"
                value={formData.ruc}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="12345-678-901234"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                DV
              </label>
              <input
                type="text"
                name="dv"
                value={formData.dv}
                onChange={handleChange}
                maxLength={2}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="12"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Billing Email
              </label>
              <input
                type="email"
                name="billingEmail"
                value={formData.billingEmail}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="billing@company.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Phone
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="+507 6000-0000"
              />
            </div>
          </div>
        </div>

        {/* Owner Account */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <User className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-stone-50">Owner Account</h2>
              <p className="text-sm text-stone-500">Login credentials for the organization owner</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-stone-300 mb-2">
                <User className="w-4 h-4 inline mr-2" />
                Full Name *
              </label>
              <input
                type="text"
                name="ownerName"
                required
                value={formData.ownerName}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="John Smith"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                <Mail className="w-4 h-4 inline mr-2" />
                Email Address *
              </label>
              <input
                type="email"
                name="ownerEmail"
                required
                value={formData.ownerEmail}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="owner@company.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                Password *
              </label>
              <input
                type="password"
                name="ownerPassword"
                required
                minLength={8}
                value={formData.ownerPassword}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="Min 8 characters"
              />
            </div>
          </div>
        </div>

        {/* Subscription */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
              <Gift className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-stone-50">Subscription</h2>
              <p className="text-sm text-stone-500">Select sections and seat tier</p>
            </div>
          </div>

          {/* Complimentary toggle */}
          <div className="flex items-center gap-3 mb-6 p-4 bg-stone-800/50 rounded-xl">
            <input
              type="checkbox"
              id="isComplimentary"
              checked={formData.isComplimentary}
              onChange={(e) => setFormData(prev => ({ ...prev, isComplimentary: e.target.checked }))}
              className="w-5 h-5 rounded border-stone-600 bg-stone-700 text-green-500 focus:ring-green-500/50"
            />
            <label htmlFor="isComplimentary" className="text-stone-200">
              Complimentary Account (no payment required)
            </label>
          </div>

          {/* Sections */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-stone-300 mb-3">
              Select Sections *
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {sections.map((section) => {
                const isSelected = formData.selectedSections.includes(section.id)
                return (
                  <button
                    key={section.id}
                    type="button"
                    onClick={() => toggleSection(section.id)}
                    className={`
                      flex items-center gap-3 p-4 rounded-xl border transition-all text-left
                      ${isSelected 
                        ? 'border-green-500/50 bg-green-500/10' 
                        : 'border-stone-700 bg-stone-800/50 hover:border-stone-600'
                      }
                    `}
                  >
                    <div className={`
                      w-10 h-10 rounded-lg flex items-center justify-center
                      ${isSelected ? 'bg-green-500/20' : 'bg-stone-700'}
                    `}>
                      <section.icon className={`w-5 h-5 ${isSelected ? 'text-green-400' : 'text-stone-400'}`} />
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${isSelected ? 'text-green-400' : 'text-stone-200'}`}>
                        {section.name}
                      </p>
                      <p className="text-sm text-stone-500">${section.price}/mo</p>
                    </div>
                    {isSelected && (
                      <Check className="w-5 h-5 text-green-400" />
                    )}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Seat Tier */}
          <div>
            <label className="block text-sm font-medium text-stone-300 mb-3">
              Seat Tier
            </label>
            <div className="flex flex-wrap gap-2">
              {seatTiers.map((tier) => (
                <button
                  key={tier}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, seatTier: tier }))}
                  className={`
                    px-4 py-2 rounded-lg border transition-all
                    ${formData.seatTier === tier
                      ? 'border-green-500/50 bg-green-500/10 text-green-400'
                      : 'border-stone-700 bg-stone-800 text-stone-300 hover:border-stone-600'
                    }
                  `}
                >
                  {tier} users
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-stone-300 mb-2">
              Notes (internal)
            </label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-3 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 resize-none"
              placeholder="Reason for complimentary access, special notes, etc."
            />
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
            <p className="text-red-400">{error}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-end gap-4">
          <Link
            href="/admin/organizations"
            className="px-6 py-3 text-stone-400 hover:text-stone-200 transition-colors"
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={isLoading}
            className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 text-white font-medium rounded-xl transition-colors disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Building2 className="w-5 h-5" />
                Create Organization
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
