'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  Gift,
  Plus,
  Building2,
  Calendar,
  MoreVertical,
  Edit,
  Trash2,
  Check,
  X,
  Plane,
  Ship,
  Home,
  Users
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface CompMembership {
  id: string
  organization_id: string
  reason: string | null
  sections: string[]
  max_seats: number
  expires_at: string | null
  is_active: boolean
  created_at: string
  notes: string | null
  organizations: {
    legal_name: string
    commercial_name: string | null
  }
  platform_admins: {
    full_name: string
  } | null
}

export default function ComplimentaryPage() {
  const [memberships, setMemberships] = useState<CompMembership[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [openMenu, setOpenMenu] = useState<string | null>(null)
  const [deleteModal, setDeleteModal] = useState<string | null>(null)

  useEffect(() => {
    loadMemberships()
  }, [])

  const loadMemberships = async () => {
    const supabase = createClient()

    const { data, error } = await supabase
      .from('complimentary_memberships')
      .select(`
        *,
        organizations (
          legal_name,
          commercial_name
        ),
        platform_admins:granted_by (
          full_name
        )
      `)
      .order('created_at', { ascending: false })

    if (!error && data) {
      setMemberships(data)
    }
    setIsLoading(false)
  }

  const handleRevoke = async (id: string) => {
    const supabase = createClient()

    const { error } = await supabase
      .from('complimentary_memberships')
      .update({ is_active: false })
      .eq('id', id)

    if (!error) {
      setMemberships(memberships.map(m => 
        m.id === id ? { ...m, is_active: false } : m
      ))
    }
    setDeleteModal(null)
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  const getSectionIcon = (section: string) => {
    switch (section) {
      case 'planes':
      case 'helicopters': return Plane
      case 'boats': return Ship
      case 'residences': return Home
      default: return Gift
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-stone-900 border border-stone-800 rounded-xl p-6 animate-pulse">
              <div className="h-5 bg-stone-800 rounded w-1/3 mb-2" />
              <div className="h-4 bg-stone-800 rounded w-1/4" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Complimentary Memberships
          </h1>
          <p className="text-stone-400">
            Manage free accounts not tied to payment
          </p>
        </div>
        <Link
          href="/admin/complimentary/new"
          className="px-4 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Grant Complimentary
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Total Granted</p>
          <p className="text-2xl font-display text-stone-50">{memberships.length}</p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Active</p>
          <p className="text-2xl font-display text-green-400">
            {memberships.filter(m => m.is_active).length}
          </p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Revoked/Expired</p>
          <p className="text-2xl font-display text-stone-400">
            {memberships.filter(m => !m.is_active).length}
          </p>
        </div>
      </div>

      {/* Memberships list */}
      {memberships.length === 0 ? (
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-12 text-center">
          <Gift className="w-12 h-12 text-stone-600 mx-auto mb-4" />
          <h2 className="font-display text-xl font-medium text-stone-200 mb-2">
            No Complimentary Memberships
          </h2>
          <p className="text-stone-400 mb-6">
            Grant complimentary access to organizations that don't require payment.
          </p>
          <Link
            href="/admin/complimentary/new"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors"
          >
            <Plus className="w-5 h-5" />
            Grant First Complimentary
          </Link>
        </div>
      ) : (
        <div className="grid gap-4">
          {memberships.map((membership) => (
            <div 
              key={membership.id}
              className={`bg-stone-900 border rounded-xl p-6 ${
                membership.is_active ? 'border-stone-800' : 'border-stone-800/50 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-xl bg-pink-500/10 flex items-center justify-center">
                      <Gift className="w-5 h-5 text-pink-400" />
                    </div>
                    <div>
                      <h3 className="font-medium text-stone-100">
                        {membership.organizations?.commercial_name || membership.organizations?.legal_name}
                      </h3>
                      <p className="text-sm text-stone-500">
                        Granted by {membership.platform_admins?.full_name || 'Unknown'} on {formatDate(membership.created_at)}
                      </p>
                    </div>
                  </div>

                  {membership.reason && (
                    <p className="text-stone-400 text-sm mb-3 ml-13">
                      <span className="text-stone-500">Reason:</span> {membership.reason}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-3 ml-13">
                    {/* Sections */}
                    <div className="flex items-center gap-1.5">
                      {membership.sections.map((section) => {
                        const Icon = getSectionIcon(section)
                        return (
                          <div
                            key={section}
                            className="px-2 py-1 rounded-lg bg-stone-800 text-stone-300 text-xs flex items-center gap-1.5"
                          >
                            <Icon className="w-3.5 h-3.5" />
                            {section}
                          </div>
                        )
                      })}
                    </div>

                    {/* Seats */}
                    <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-stone-800 text-stone-300 text-xs">
                      <Users className="w-3.5 h-3.5" />
                      {membership.max_seats} seats
                    </div>

                    {/* Expiry */}
                    {membership.expires_at && (
                      <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-stone-800 text-stone-300 text-xs">
                        <Calendar className="w-3.5 h-3.5" />
                        Expires {formatDate(membership.expires_at)}
                      </div>
                    )}

                    {/* Status */}
                    {membership.is_active ? (
                      <span className="px-2 py-1 text-xs rounded-lg bg-green-500/10 text-green-400 border border-green-500/20 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-1 text-xs rounded-lg bg-red-500/10 text-red-400 border border-red-500/20 flex items-center gap-1">
                        <X className="w-3.5 h-3.5" />
                        Revoked
                      </span>
                    )}
                  </div>

                  {membership.notes && (
                    <p className="text-xs text-stone-500 mt-3 ml-13">
                      Notes: {membership.notes}
                    </p>
                  )}
                </div>

                {/* Actions */}
                {membership.is_active && (
                  <div className="relative">
                    <button
                      onClick={() => setOpenMenu(openMenu === membership.id ? null : membership.id)}
                      className="p-2 rounded-lg text-stone-500 hover:text-stone-300 hover:bg-stone-700 transition-colors"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>

                    {openMenu === membership.id && (
                      <>
                        <div 
                          className="fixed inset-0 z-10" 
                          onClick={() => setOpenMenu(null)}
                        />
                        <div className="absolute right-0 top-full mt-1 w-40 bg-stone-800 border border-stone-700 rounded-xl shadow-lg z-20 py-1">
                          <button
                            className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-stone-700 transition-colors w-full"
                            onClick={() => setOpenMenu(null)}
                          >
                            <Edit className="w-4 h-4" />
                            Edit
                          </button>
                          <button
                            className="flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-stone-700 transition-colors w-full"
                            onClick={() => {
                              setDeleteModal(membership.id)
                              setOpenMenu(null)
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                            Revoke
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Revoke confirmation modal */}
      {deleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-stone-900 border border-stone-800 rounded-xl p-6 max-w-md w-full">
            <h3 className="font-display text-xl font-medium text-stone-50 mb-2">
              Revoke Complimentary Access
            </h3>
            <p className="text-stone-400 mb-6">
              Are you sure you want to revoke this complimentary membership? The organization will lose access to complimentary features.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteModal(null)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-stone-800 text-stone-300 border border-stone-700 hover:border-stone-600 transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => handleRevoke(deleteModal)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors font-medium"
              >
                Revoke Access
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
