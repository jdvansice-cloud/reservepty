'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  Gift,
  Loader2,
  Check,
  Plane,
  Ship,
  Home,
  Building2,
  Search
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const SECTIONS = [
  { id: 'planes', name: 'Planes', icon: Plane },
  { id: 'helicopters', name: 'Helicopters', icon: Plane },
  { id: 'residences', name: 'Residences', icon: Home },
  { id: 'boats', name: 'Boats', icon: Ship },
]

function NewComplimentaryForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const preselectedOrg = searchParams.get('org')

  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [organizations, setOrganizations] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [adminId, setAdminId] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    organizationId: preselectedOrg || '',
    reason: '',
    sections: [] as string[],
    maxSeats: '5',
    expiresAt: '',
    notes: '',
  })

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setIsLoading(true)
    const supabase = createClient()

    // Get current admin
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: admin } = await supabase
        .from('platform_admins')
        .select('id')
        .eq('user_id', user.id)
        .single()
      if (admin) setAdminId(admin.id)
    }

    // Load organizations
    const { data: orgs } = await supabase
      .from('organizations')
      .select('id, legal_name, commercial_name')
      .is('deleted_at', null)
      .order('legal_name')

    setOrganizations(orgs || [])
    setIsLoading(false)
  }

  const toggleSection = (sectionId: string) => {
    setFormData(prev => ({
      ...prev,
      sections: prev.sections.includes(sectionId)
        ? prev.sections.filter(s => s !== sectionId)
        : [...prev.sections, sectionId]
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.organizationId) {
      setError('Please select an organization')
      return
    }
    if (formData.sections.length === 0) {
      setError('Please select at least one section')
      return
    }

    setIsSaving(true)
    setError(null)

    try {
      const supabase = createClient()

      const { error: insertError } = await supabase
        .from('complimentary_memberships')
        .insert({
          organization_id: formData.organizationId,
          granted_by: adminId,
          reason: formData.reason || null,
          sections: formData.sections,
          max_seats: parseInt(formData.maxSeats) || 5,
          expires_at: formData.expiresAt || null,
          notes: formData.notes || null,
          is_active: true,
        })

      if (insertError) throw insertError

      // Log activity
      await supabase
        .from('platform_activity_logs')
        .insert({
          admin_id: adminId,
          action: 'granted_complimentary',
          entity_type: 'organization',
          entity_id: formData.organizationId,
          details: {
            sections: formData.sections,
            max_seats: formData.maxSeats,
            reason: formData.reason,
          }
        })

      router.push('/admin/complimentary')
    } catch (err: any) {
      console.error('Error:', err)
      setError(err.message || 'Failed to grant complimentary access')
    } finally {
      setIsSaving(false)
    }
  }

  const filteredOrgs = organizations.filter(org =>
    org.legal_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    org.commercial_name?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-red-400 animate-spin" />
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          href="/admin/complimentary"
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Complimentary
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center">
            <Gift className="w-6 h-6 text-pink-400" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-medium text-stone-50">
              Grant Complimentary Access
            </h1>
            <p className="text-stone-400">Create a free membership for an organization</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Select Organization */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Select Organization
          </h2>
          
          <div className="relative mb-4">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-500" />
            <input
              type="text"
              placeholder="Search organizations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2.5 pl-12 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
            />
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2">
            {filteredOrgs.map((org) => (
              <button
                key={org.id}
                type="button"
                onClick={() => setFormData({ ...formData, organizationId: org.id })}
                className={`w-full p-3 rounded-xl border text-left transition-colors flex items-center gap-3 ${
                  formData.organizationId === org.id
                    ? 'bg-red-500/10 border-red-500/50'
                    : 'bg-stone-800/50 border-stone-700/50 hover:border-stone-600'
                }`}
              >
                <Building2 className={`w-5 h-5 ${
                  formData.organizationId === org.id ? 'text-red-400' : 'text-stone-500'
                }`} />
                <div className="flex-1">
                  <p className={formData.organizationId === org.id ? 'text-stone-50' : 'text-stone-200'}>
                    {org.commercial_name || org.legal_name}
                  </p>
                  {org.commercial_name && (
                    <p className="text-xs text-stone-500">{org.legal_name}</p>
                  )}
                </div>
                {formData.organizationId === org.id && (
                  <Check className="w-5 h-5 text-red-400" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Select Sections */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Grant Access To
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {SECTIONS.map((section) => {
              const isSelected = formData.sections.includes(section.id)
              const Icon = section.icon
              return (
                <button
                  key={section.id}
                  type="button"
                  onClick={() => toggleSection(section.id)}
                  className={`p-4 rounded-xl border text-left transition-colors flex items-center gap-3 ${
                    isSelected
                      ? 'bg-red-500/10 border-red-500/50'
                      : 'bg-stone-800/50 border-stone-700/50 hover:border-stone-600'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isSelected ? 'text-red-400' : 'text-stone-500'}`} />
                  <span className={isSelected ? 'text-stone-50' : 'text-stone-300'}>
                    {section.name}
                  </span>
                  {isSelected && <Check className="w-4 h-4 text-red-400 ml-auto" />}
                </button>
              )
            })}
          </div>
        </div>

        {/* Details */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Details
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Reason for Complimentary Access
              </label>
              <input
                type="text"
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="e.g., Beta tester, Partner, Staff"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-stone-300 mb-2">
                  Max Seats
                </label>
                <input
                  type="number"
                  min="1"
                  value={formData.maxSeats}
                  onChange={(e) => setFormData({ ...formData, maxSeats: e.target.value })}
                  className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-300 mb-2">
                  Expires On (optional)
                </label>
                <input
                  type="date"
                  value={formData.expiresAt}
                  onChange={(e) => setFormData({ ...formData, expiresAt: e.target.value })}
                  className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Internal Notes (optional)
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 min-h-[80px]"
                placeholder="Any internal notes about this complimentary access..."
              />
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-between">
          <Link href="/admin/complimentary" className="px-4 py-2.5 rounded-xl bg-stone-800 text-stone-300 border border-stone-700 hover:border-stone-600 transition-colors font-medium">
            Cancel
          </Link>
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Granting...
              </>
            ) : (
              <>
                <Gift className="w-5 h-5" />
                Grant Complimentary
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}

export default function NewComplimentaryPage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-red-400 animate-spin" />
      </div>
    }>
      <NewComplimentaryForm />
    </Suspense>
  )
}
