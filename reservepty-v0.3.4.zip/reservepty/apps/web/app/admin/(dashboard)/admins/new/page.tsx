'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  UserCog,
  Loader2,
  Shield,
  Mail
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const ROLES = [
  { 
    id: 'super_admin', 
    name: 'Super Admin', 
    description: 'Full access including admin management',
    icon: Shield,
    color: 'text-red-400',
    bg: 'bg-red-500/10'
  },
  { 
    id: 'admin', 
    name: 'Admin', 
    description: 'Full access except admin management',
    icon: UserCog,
    color: 'text-orange-400',
    bg: 'bg-orange-500/10'
  },
  { 
    id: 'support', 
    name: 'Support', 
    description: 'Read-only access to view data',
    icon: Mail,
    color: 'text-blue-400',
    bg: 'bg-blue-500/10'
  },
]

export default function NewAdminPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [currentAdminId, setCurrentAdminId] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    password: '',
    role: 'admin',
  })

  useEffect(() => {
    loadCurrentAdmin()
  }, [])

  const loadCurrentAdmin = async () => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: admin } = await supabase
        .from('platform_admins')
        .select('id, role')
        .eq('user_id', user.id)
        .single()
      
      if (admin?.role !== 'super_admin') {
        router.push('/admin/admins')
        return
      }
      setCurrentAdminId(admin.id)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.email || !formData.fullName || !formData.password) {
      setError('Please fill in all required fields')
      return
    }

    if (formData.password.length < 8) {
      setError('Password must be at least 8 characters')
      return
    }

    setIsSaving(true)
    setError(null)

    try {
      const supabase = createClient()

      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
          }
        }
      })

      if (authError) throw authError
      if (!authData.user) throw new Error('Failed to create user')

      // Create platform admin record
      const { error: adminError } = await supabase
        .from('platform_admins')
        .insert({
          user_id: authData.user.id,
          email: formData.email,
          full_name: formData.fullName,
          role: formData.role,
          created_by: currentAdminId,
          is_active: true,
        })

      if (adminError) throw adminError

      // Log activity
      await supabase
        .from('platform_activity_logs')
        .insert({
          admin_id: currentAdminId,
          action: 'created_admin',
          entity_type: 'platform_admin',
          entity_id: authData.user.id,
          details: {
            email: formData.email,
            role: formData.role,
          }
        })

      router.push('/admin/admins')
    } catch (err: any) {
      console.error('Error:', err)
      setError(err.message || 'Failed to create admin')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          href="/admin/admins"
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Admins
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
            <UserCog className="w-6 h-6 text-red-400" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-medium text-stone-50">
              Add Platform Admin
            </h1>
            <p className="text-stone-400">Create a new administrator account</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Account Details
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Full Name *
              </label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="John Doe"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Email Address *
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="admin@reservepty.com"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-stone-300 mb-2">
                Password *
              </label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
                placeholder="Minimum 8 characters"
                minLength={8}
                required
              />
            </div>
          </div>
        </div>

        {/* Role Selection */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Select Role
          </h2>
          <div className="space-y-3">
            {ROLES.map((role) => {
              const isSelected = formData.role === role.id
              const Icon = role.icon
              return (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => setFormData({ ...formData, role: role.id })}
                  className={`w-full p-4 rounded-xl border text-left transition-colors flex items-center gap-4 ${
                    isSelected
                      ? 'bg-red-500/10 border-red-500/50'
                      : 'bg-stone-800/50 border-stone-700/50 hover:border-stone-600'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-xl ${role.bg} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${role.color}`} />
                  </div>
                  <div className="flex-1">
                    <p className={isSelected ? 'text-stone-50 font-medium' : 'text-stone-200'}>
                      {role.name}
                    </p>
                    <p className="text-sm text-stone-500">{role.description}</p>
                  </div>
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    isSelected ? 'bg-red-500 border-red-500' : 'border-stone-600'
                  }`}>
                    {isSelected && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-between">
          <Link href="/admin/admins" className="px-4 py-2.5 rounded-xl bg-stone-800 text-stone-300 border border-stone-700 hover:border-stone-600 transition-colors font-medium">
            Cancel
          </Link>
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <UserCog className="w-5 h-5" />
                Create Admin
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
