'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  Shield,
  Plus,
  MoreVertical,
  Edit,
  Trash2,
  UserCog,
  Clock,
  Mail
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface PlatformAdmin {
  id: string
  user_id: string
  email: string
  full_name: string
  role: string
  is_active: boolean
  created_at: string
  last_login_at: string | null
  created_by_admin: {
    full_name: string
  } | null
}

export default function AdminsPage() {
  const [admins, setAdmins] = useState<PlatformAdmin[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentAdmin, setCurrentAdmin] = useState<any>(null)
  const [openMenu, setOpenMenu] = useState<string | null>(null)
  const [deleteModal, setDeleteModal] = useState<string | null>(null)

  useEffect(() => {
    loadAdmins()
  }, [])

  const loadAdmins = async () => {
    const supabase = createClient()

    // Get current admin
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: admin } = await supabase
        .from('platform_admins')
        .select('*')
        .eq('user_id', user.id)
        .single()
      setCurrentAdmin(admin)
    }

    // Load all admins
    const { data, error } = await supabase
      .from('platform_admins')
      .select(`
        *,
        created_by_admin:created_by (
          full_name
        )
      `)
      .order('created_at', { ascending: true })

    if (!error && data) {
      setAdmins(data)
    }
    setIsLoading(false)
  }

  const handleDeactivate = async (id: string) => {
    const supabase = createClient()

    const { error } = await supabase
      .from('platform_admins')
      .update({ is_active: false })
      .eq('id', id)

    if (!error) {
      setAdmins(admins.map(a => 
        a.id === id ? { ...a, is_active: false } : a
      ))

      // Log activity
      await supabase
        .from('platform_activity_logs')
        .insert({
          admin_id: currentAdmin?.id,
          action: 'deactivated_admin',
          entity_type: 'platform_admin',
          entity_id: id,
        })
    }
    setDeleteModal(null)
  }

  const formatDate = (date: string | null) => {
    if (!date) return 'Never'
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'super_admin':
        return <span className="px-2 py-0.5 text-xs rounded bg-red-500/10 text-red-400 border border-red-500/20">Super Admin</span>
      case 'admin':
        return <span className="px-2 py-0.5 text-xs rounded bg-orange-500/10 text-orange-400 border border-orange-500/20">Admin</span>
      case 'support':
        return <span className="px-2 py-0.5 text-xs rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">Support</span>
      default:
        return <span className="px-2 py-0.5 text-xs rounded bg-stone-500/10 text-stone-400 border border-stone-500/20">{role}</span>
    }
  }

  const canManageAdmins = currentAdmin?.role === 'super_admin'

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-stone-900 border border-stone-800 rounded-xl p-6 animate-pulse">
              <div className="h-5 bg-stone-800 rounded w-1/3 mb-2" />
              <div className="h-4 bg-stone-800 rounded w-1/4" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Platform Admins
          </h1>
          <p className="text-stone-400">
            Manage administrators with access to this control panel
          </p>
        </div>
        {canManageAdmins && (
          <Link
            href="/admin/admins/new"
            className="px-4 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Admin
          </Link>
        )}
      </div>

      {/* Role legend */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
        <h3 className="text-sm font-medium text-stone-300 mb-3">Role Permissions</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center shrink-0">
              <Shield className="w-4 h-4 text-red-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-stone-200">Super Admin</p>
              <p className="text-xs text-stone-500">Full access, can manage other admins</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center shrink-0">
              <UserCog className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-stone-200">Admin</p>
              <p className="text-xs text-stone-500">Full access except admin management</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-stone-200">Support</p>
              <p className="text-xs text-stone-500">Read-only access, can view data</p>
            </div>
          </div>
        </div>
      </div>

      {/* Admins list */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone-800">
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Admin</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Role</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Status</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Last Login</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Added</th>
                {canManageAdmins && (
                  <th className="text-right px-6 py-4 text-sm font-medium text-stone-400">Actions</th>
                )}
              </tr>
            </thead>
            <tbody>
              {admins.map((admin) => (
                <tr key={admin.id} className="border-b border-stone-800 hover:bg-stone-800/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        admin.role === 'super_admin' ? 'bg-red-500/10' :
                        admin.role === 'admin' ? 'bg-orange-500/10' : 'bg-blue-500/10'
                      }`}>
                        <span className={`text-sm font-medium ${
                          admin.role === 'super_admin' ? 'text-red-400' :
                          admin.role === 'admin' ? 'text-orange-400' : 'text-blue-400'
                        }`}>
                          {admin.full_name?.charAt(0) || 'A'}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-stone-100">
                          {admin.full_name}
                          {admin.id === currentAdmin?.id && (
                            <span className="ml-2 text-xs text-stone-500">(you)</span>
                          )}
                        </p>
                        <p className="text-sm text-stone-500">{admin.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getRoleBadge(admin.role)}
                  </td>
                  <td className="px-6 py-4">
                    {admin.is_active ? (
                      <span className="px-2 py-0.5 text-xs rounded bg-green-500/10 text-green-400 border border-green-500/20">Active</span>
                    ) : (
                      <span className="px-2 py-0.5 text-xs rounded bg-red-500/10 text-red-400 border border-red-500/20">Inactive</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-stone-400">
                      <Clock className="w-4 h-4 text-stone-500" />
                      <span className="text-sm">{formatDate(admin.last_login_at)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-stone-400 text-sm">
                    {formatDate(admin.created_at).split(',')[0]}
                    {admin.created_by_admin && (
                      <p className="text-xs text-stone-500">
                        by {admin.created_by_admin.full_name}
                      </p>
                    )}
                  </td>
                  {canManageAdmins && (
                    <td className="px-6 py-4">
                      <div className="flex justify-end relative">
                        {admin.id !== currentAdmin?.id && admin.is_active && (
                          <>
                            <button
                              onClick={() => setOpenMenu(openMenu === admin.id ? null : admin.id)}
                              className="p-2 rounded-lg text-stone-500 hover:text-stone-300 hover:bg-stone-700 transition-colors"
                            >
                              <MoreVertical className="w-5 h-5" />
                            </button>

                            {openMenu === admin.id && (
                              <>
                                <div 
                                  className="fixed inset-0 z-10" 
                                  onClick={() => setOpenMenu(null)}
                                />
                                <div className="absolute right-0 top-full mt-1 w-40 bg-stone-800 border border-stone-700 rounded-xl shadow-lg z-20 py-1">
                                  <button
                                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-stone-700 transition-colors w-full"
                                    onClick={() => setOpenMenu(null)}
                                  >
                                    <Edit className="w-4 h-4" />
                                    Edit
                                  </button>
                                  <button
                                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-stone-700 transition-colors w-full"
                                    onClick={() => {
                                      setDeleteModal(admin.id)
                                      setOpenMenu(null)
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                    Deactivate
                                  </button>
                                </div>
                              </>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deactivate confirmation modal */}
      {deleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-stone-900 border border-stone-800 rounded-xl p-6 max-w-md w-full">
            <h3 className="font-display text-xl font-medium text-stone-50 mb-2">
              Deactivate Admin
            </h3>
            <p className="text-stone-400 mb-6">
              Are you sure you want to deactivate this administrator? They will no longer be able to access the platform admin panel.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteModal(null)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-stone-800 text-stone-300 border border-stone-700 hover:border-stone-600 transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeactivate(deleteModal)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors font-medium"
              >
                Deactivate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
