'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  Building2,
  Users,
  CreditCard,
  TrendingUp,
  TrendingDown,
  Plane,
  Ship,
  Home,
  Calendar,
  ArrowUpRight,
  Activity,
  DollarSign,
  Gift,
  Clock
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface DashboardStats {
  totalOrganizations: number
  activeOrganizations: number
  totalUsers: number
  activeSubscriptions: number
  trialSubscriptions: number
  monthlyRevenue: number
  totalAssets: number
  totalReservations: number
  complimentaryAccounts: number
  recentSignups: any[]
  sectionBreakdown: {
    planes: number
    helicopters: number
    residences: number
    boats: number
  }
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<DashboardStats>({
    totalOrganizations: 0,
    activeOrganizations: 0,
    totalUsers: 0,
    activeSubscriptions: 0,
    trialSubscriptions: 0,
    monthlyRevenue: 0,
    totalAssets: 0,
    totalReservations: 0,
    complimentaryAccounts: 0,
    recentSignups: [],
    sectionBreakdown: { planes: 0, helicopters: 0, residences: 0, boats: 0 }
  })
  const [isLoading, setIsLoading] = useState(true)
  const [recentActivity, setRecentActivity] = useState<any[]>([])

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    const supabase = createClient()

    try {
      // Get organization counts
      const { count: totalOrgs } = await supabase
        .from('organizations')
        .select('*', { count: 'exact', head: true })

      const { count: activeOrgs } = await supabase
        .from('organizations')
        .select('*', { count: 'exact', head: true })
        .is('deleted_at', null)

      // Get user counts
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })

      // Get subscription counts
      const { count: activeSubscriptions } = await supabase
        .from('subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active')

      const { count: trialSubscriptions } = await supabase
        .from('subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'trialing')

      // Get asset counts
      const { count: totalAssets } = await supabase
        .from('assets')
        .select('*', { count: 'exact', head: true })
        .is('deleted_at', null)

      // Get reservation counts
      const { count: totalReservations } = await supabase
        .from('reservations')
        .select('*', { count: 'exact', head: true })
        .is('deleted_at', null)

      // Get complimentary accounts
      const { count: complimentaryAccounts } = await supabase
        .from('complimentary_memberships')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true)

      // Get section breakdown from entitlements
      const { data: entitlements } = await supabase
        .from('entitlements')
        .select('section')
        .eq('enabled', true)

      const sectionBreakdown = {
        planes: entitlements?.filter(e => e.section === 'planes').length || 0,
        helicopters: entitlements?.filter(e => e.section === 'helicopters').length || 0,
        residences: entitlements?.filter(e => e.section === 'residences').length || 0,
        boats: entitlements?.filter(e => e.section === 'boats').length || 0,
      }

      // Calculate monthly revenue (simplified - based on active subscriptions)
      const pricing = { planes: 99, helicopters: 99, residences: 79, boats: 79 }
      const monthlyRevenue = 
        (sectionBreakdown.planes * pricing.planes) +
        (sectionBreakdown.helicopters * pricing.helicopters) +
        (sectionBreakdown.residences * pricing.residences) +
        (sectionBreakdown.boats * pricing.boats)

      // Get recent signups
      const { data: recentSignups } = await supabase
        .from('organizations')
        .select(`
          id,
          legal_name,
          commercial_name,
          created_at,
          subscriptions (
            status
          )
        `)
        .order('created_at', { ascending: false })
        .limit(5)

      // Get recent activity logs
      const { data: activityLogs } = await supabase
        .from('platform_activity_logs')
        .select(`
          *,
          platform_admins (
            full_name
          )
        `)
        .order('created_at', { ascending: false })
        .limit(10)

      setStats({
        totalOrganizations: totalOrgs || 0,
        activeOrganizations: activeOrgs || 0,
        totalUsers: totalUsers || 0,
        activeSubscriptions: activeSubscriptions || 0,
        trialSubscriptions: trialSubscriptions || 0,
        monthlyRevenue,
        totalAssets: totalAssets || 0,
        totalReservations: totalReservations || 0,
        complimentaryAccounts: complimentaryAccounts || 0,
        recentSignups: recentSignups || [],
        sectionBreakdown,
      })

      setRecentActivity(activityLogs || [])
    } catch (err) {
      console.error('Error loading dashboard data:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const statCards = [
    { 
      label: 'Total Organizations', 
      value: stats.totalOrganizations, 
      icon: Building2, 
      color: 'text-blue-400',
      bg: 'bg-blue-400/10',
      href: '/admin/organizations'
    },
    { 
      label: 'Total Users', 
      value: stats.totalUsers, 
      icon: Users, 
      color: 'text-purple-400',
      bg: 'bg-purple-400/10',
      href: '/admin/users'
    },
    { 
      label: 'Active Subscriptions', 
      value: stats.activeSubscriptions, 
      icon: CreditCard, 
      color: 'text-green-400',
      bg: 'bg-green-400/10',
      href: '/admin/organizations'
    },
    { 
      label: 'Monthly Revenue', 
      value: formatCurrency(stats.monthlyRevenue), 
      icon: DollarSign, 
      color: 'text-yellow-400',
      bg: 'bg-yellow-400/10',
      href: '/admin/revenue'
    },
    { 
      label: 'Trial Accounts', 
      value: stats.trialSubscriptions, 
      icon: Clock, 
      color: 'text-orange-400',
      bg: 'bg-orange-400/10',
      href: '/admin/organizations'
    },
    { 
      label: 'Complimentary', 
      value: stats.complimentaryAccounts, 
      icon: Gift, 
      color: 'text-pink-400',
      bg: 'bg-pink-400/10',
      href: '/admin/complimentary'
    },
    { 
      label: 'Total Assets', 
      value: stats.totalAssets, 
      icon: Plane, 
      color: 'text-cyan-400',
      bg: 'bg-cyan-400/10',
      href: '/admin/organizations'
    },
    { 
      label: 'Total Reservations', 
      value: stats.totalReservations, 
      icon: Calendar, 
      color: 'text-indigo-400',
      bg: 'bg-indigo-400/10',
      href: '/admin/organizations'
    },
  ]

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <div key={i} className="bg-stone-900 border border-stone-800 rounded-xl p-6 animate-pulse">
              <div className="h-4 bg-stone-800 rounded w-1/2 mb-4" />
              <div className="h-8 bg-stone-800 rounded w-1/3" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
          Platform Dashboard
        </h1>
        <p className="text-stone-400">
          Overview of ReservePTY platform metrics and activity
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Link
            key={stat.label}
            href={stat.href}
            className="bg-stone-900 border border-stone-800 rounded-xl p-6 hover:border-stone-700 transition-colors group"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-stone-400">{stat.label}</span>
              <div className={`p-2 rounded-lg ${stat.bg}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
            <div className="flex items-end justify-between">
              <p className="text-2xl font-display font-medium text-stone-50">
                {stat.value}
              </p>
              <ArrowUpRight className="w-4 h-4 text-stone-600 group-hover:text-stone-400 transition-colors" />
            </div>
          </Link>
        ))}
      </div>

      {/* Section breakdown and Recent activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Section Breakdown */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Active Sections
          </h2>
          <div className="space-y-4">
            {[
              { name: 'Planes', value: stats.sectionBreakdown.planes, icon: Plane, color: 'text-blue-400' },
              { name: 'Helicopters', value: stats.sectionBreakdown.helicopters, icon: Plane, color: 'text-purple-400' },
              { name: 'Residences', value: stats.sectionBreakdown.residences, icon: Home, color: 'text-green-400' },
              { name: 'Boats', value: stats.sectionBreakdown.boats, icon: Ship, color: 'text-cyan-400' },
            ].map((section) => (
              <div key={section.name} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <section.icon className={`w-5 h-5 ${section.color}`} />
                  <span className="text-stone-300">{section.name}</span>
                </div>
                <span className="text-stone-50 font-medium">{section.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Signups */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-medium text-stone-50">
              Recent Signups
            </h2>
            <Link href="/admin/organizations" className="text-sm text-red-400 hover:text-red-300">
              View all
            </Link>
          </div>
          {stats.recentSignups.length === 0 ? (
            <p className="text-stone-500 text-sm">No organizations yet</p>
          ) : (
            <div className="space-y-3">
              {stats.recentSignups.map((org) => (
                <div key={org.id} className="flex items-center justify-between py-2 border-b border-stone-800 last:border-0">
                  <div className="min-w-0">
                    <p className="text-stone-200 font-medium truncate">
                      {org.commercial_name || org.legal_name}
                    </p>
                    <p className="text-xs text-stone-500">{formatDate(org.created_at)}</p>
                  </div>
                  <span className={`px-2 py-0.5 text-xs rounded ${
                    org.subscriptions?.[0]?.status === 'active' 
                      ? 'bg-green-500/10 text-green-400'
                      : 'bg-yellow-500/10 text-yellow-400'
                  }`}>
                    {org.subscriptions?.[0]?.status || 'trial'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Activity */}
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-medium text-stone-50">
              Admin Activity
            </h2>
            <Link href="/admin/activity" className="text-sm text-red-400 hover:text-red-300">
              View all
            </Link>
          </div>
          {recentActivity.length === 0 ? (
            <p className="text-stone-500 text-sm">No recent activity</p>
          ) : (
            <div className="space-y-3">
              {recentActivity.slice(0, 5).map((log) => (
                <div key={log.id} className="py-2 border-b border-stone-800 last:border-0">
                  <p className="text-stone-200 text-sm">
                    <span className="text-stone-400">{log.platform_admins?.full_name || 'Admin'}</span>
                    {' '}{log.action}
                  </p>
                  <p className="text-xs text-stone-500">{formatDate(log.created_at)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
        <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link
            href="/admin/complimentary/new"
            className="flex flex-col items-center gap-2 p-4 bg-stone-800/50 rounded-xl hover:bg-stone-800 transition-colors"
          >
            <Gift className="w-6 h-6 text-pink-400" />
            <span className="text-sm text-stone-300">Grant Complimentary</span>
          </Link>
          <Link
            href="/admin/admins/new"
            className="flex flex-col items-center gap-2 p-4 bg-stone-800/50 rounded-xl hover:bg-stone-800 transition-colors"
          >
            <Users className="w-6 h-6 text-purple-400" />
            <span className="text-sm text-stone-300">Add Admin</span>
          </Link>
          <Link
            href="/admin/organizations"
            className="flex flex-col items-center gap-2 p-4 bg-stone-800/50 rounded-xl hover:bg-stone-800 transition-colors"
          >
            <Building2 className="w-6 h-6 text-blue-400" />
            <span className="text-sm text-stone-300">View Organizations</span>
          </Link>
          <Link
            href="/admin/settings"
            className="flex flex-col items-center gap-2 p-4 bg-stone-800/50 rounded-xl hover:bg-stone-800 transition-colors"
          >
            <Activity className="w-6 h-6 text-green-400" />
            <span className="text-sm text-stone-300">Platform Settings</span>
          </Link>
        </div>
      </div>
    </div>
  )
}
