'use client'

import { useState, useEffect } from 'react'
import {
  Search,
  Users,
  Building2,
  MoreVertical,
  Eye,
  Mail,
  Ban,
  X,
  Download,
  UserPlus
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface User {
  id: string
  full_name: string | null
  email: string
  created_at: string
  organization_members: {
    role: string
    organizations: {
      id: string
      legal_name: string
      commercial_name: string | null
    } | null
  }[]
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [roleFilter, setRoleFilter] = useState<string>('all')
  const [openMenu, setOpenMenu] = useState<string | null>(null)

  useEffect(() => {
    loadUsers()
  }, [])

  useEffect(() => {
    filterUsers()
  }, [users, searchQuery, roleFilter])

  const loadUsers = async () => {
    const supabase = createClient()

    const { data, error } = await supabase
      .from('profiles')
      .select(`
        id,
        full_name,
        created_at,
        organization_members (
          role,
          organizations (
            id,
            legal_name,
            commercial_name
          )
        )
      `)
      .order('created_at', { ascending: false })

    if (!error && data) {
      // Map data with placeholder emails
      const usersWithEmail = data.map((user: any) => ({
        ...user,
        email: `user-${user.id.slice(0, 8)}@example.com`
      }))
      setUsers(usersWithEmail)
    }
    setIsLoading(false)
  }

  const filterUsers = () => {
    let filtered = [...users]

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(user =>
        user.full_name?.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query)
      )
    }

    // Filter by role
    if (roleFilter !== 'all') {
      filtered = filtered.filter(user =>
        user.organization_members?.some(m => m.role === roleFilter)
      )
    }

    setFilteredUsers(filtered)
  }

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'owner':
        return <span className="px-2 py-0.5 text-xs rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">Owner</span>
      case 'admin':
        return <span className="px-2 py-0.5 text-xs rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">Admin</span>
      case 'member':
        return <span className="px-2 py-0.5 text-xs rounded bg-green-500/10 text-green-400 border border-green-500/20">Member</span>
      default:
        return <span className="px-2 py-0.5 text-xs rounded bg-stone-500/10 text-stone-400 border border-stone-500/20">{role}</span>
    }
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="bg-stone-900 border border-stone-800 rounded-xl">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="p-4 border-b border-stone-800 animate-pulse">
              <div className="h-5 bg-stone-800 rounded w-1/3 mb-2" />
              <div className="h-4 bg-stone-800 rounded w-1/4" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Users
          </h1>
          <p className="text-stone-400">
            Manage all platform users
          </p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 rounded-xl bg-stone-800 text-stone-300 border border-stone-700 hover:border-stone-600 transition-colors flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-500" />
          <input
            type="text"
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2.5 pl-12 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-red-500/50"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Role filter */}
        <div className="flex gap-2">
          {['all', 'owner', 'admin', 'member'].map((role) => (
            <button
              key={role}
              onClick={() => setRoleFilter(role)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
                roleFilter === role
                  ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                  : 'bg-stone-800 text-stone-400 border border-stone-700 hover:border-stone-600'
              }`}
            >
              {role}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Total Users</p>
          <p className="text-2xl font-display text-stone-50">{users.length}</p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Owners</p>
          <p className="text-2xl font-display text-purple-400">
            {users.filter(u => u.organization_members?.some(m => m.role === 'owner')).length}
          </p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Admins</p>
          <p className="text-2xl font-display text-blue-400">
            {users.filter(u => u.organization_members?.some(m => m.role === 'admin')).length}
          </p>
        </div>
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <p className="text-sm text-stone-400">Members</p>
          <p className="text-2xl font-display text-green-400">
            {users.filter(u => u.organization_members?.some(m => m.role === 'member')).length}
          </p>
        </div>
      </div>

      {/* Users table */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone-800">
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">User</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Organization</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Role</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-stone-400">Joined</th>
                <th className="text-right px-6 py-4 text-sm font-medium text-stone-400">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-stone-500">
                    No users found
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-stone-800 hover:bg-stone-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-stone-700 flex items-center justify-center">
                          <span className="text-sm font-medium text-stone-300">
                            {user.full_name?.charAt(0) || 'U'}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-stone-100">
                            {user.full_name || 'Unnamed User'}
                          </p>
                          <p className="text-sm text-stone-500">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {user.organization_members?.[0]?.organizations ? (
                        <div className="flex items-center gap-2 text-stone-300">
                          <Building2 className="w-4 h-4 text-stone-500" />
                          {user.organization_members[0].organizations.commercial_name || 
                           user.organization_members[0].organizations.legal_name}
                        </div>
                      ) : (
                        <span className="text-stone-500">No organization</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {user.organization_members?.[0]?.role ? (
                        getRoleBadge(user.organization_members[0].role)
                      ) : (
                        <span className="text-stone-500">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-stone-400">
                      {formatDate(user.created_at)}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end relative">
                        <button
                          onClick={() => setOpenMenu(openMenu === user.id ? null : user.id)}
                          className="p-2 rounded-lg text-stone-500 hover:text-stone-300 hover:bg-stone-700 transition-colors"
                        >
                          <MoreVertical className="w-5 h-5" />
                        </button>

                        {openMenu === user.id && (
                          <>
                            <div 
                              className="fixed inset-0 z-10" 
                              onClick={() => setOpenMenu(null)}
                            />
                            <div className="absolute right-0 top-full mt-1 w-48 bg-stone-800 border border-stone-700 rounded-xl shadow-lg z-20 py-1">
                              <button
                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-stone-700 transition-colors w-full"
                                onClick={() => setOpenMenu(null)}
                              >
                                <Eye className="w-4 h-4" />
                                View Profile
                              </button>
                              <button
                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-stone-700 transition-colors w-full"
                                onClick={() => setOpenMenu(null)}
                              >
                                <Mail className="w-4 h-4" />
                                Send Email
                              </button>
                              <button
                                className="flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-stone-700 transition-colors w-full"
                                onClick={() => setOpenMenu(null)}
                              >
                                <Ban className="w-4 h-4" />
                                Suspend
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
