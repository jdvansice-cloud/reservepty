'use client'

import { useState, useEffect } from 'react'
import {
  Activity,
  Search,
  Filter,
  Clock,
  User,
  Building2,
  Gift,
  Shield,
  LogIn,
  Settings,
  X
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface ActivityLog {
  id: string
  admin_id: string
  action: string
  entity_type: string | null
  entity_id: string | null
  details: any
  ip_address: string | null
  created_at: string
  platform_admins: {
    full_name: string
    email: string
  } | null
}

const ACTION_ICONS: Record<string, any> = {
  login: LogIn,
  granted_complimentary: Gift,
  created_admin: Shield,
  deactivated_admin: Shield,
  updated_settings: Settings,
  default: Activity,
}

const ACTION_COLORS: Record<string, string> = {
  login: 'text-blue-400 bg-blue-500/10',
  granted_complimentary: 'text-pink-400 bg-pink-500/10',
  created_admin: 'text-green-400 bg-green-500/10',
  deactivated_admin: 'text-red-400 bg-red-500/10',
  updated_settings: 'text-yellow-400 bg-yellow-500/10',
  default: 'text-stone-400 bg-stone-500/10',
}

export default function ActivityPage() {
  const [logs, setLogs] = useState<ActivityLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [actionFilter, setActionFilter] = useState<string>('all')

  useEffect(() => {
    loadLogs()
  }, [])

  const loadLogs = async () => {
    const supabase = createClient()

    const { data, error } = await supabase
      .from('platform_activity_logs')
      .select(`
        *,
        platform_admins (
          full_name,
          email
        )
      `)
      .order('created_at', { ascending: false })
      .limit(100)

    if (!error && data) {
      setLogs(data)
    }
    setIsLoading(false)
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getActionLabel = (action: string) => {
    return action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
  }

  const filteredLogs = logs.filter(log => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      const matchesAdmin = log.platform_admins?.full_name.toLowerCase().includes(query)
      const matchesAction = log.action.toLowerCase().includes(query)
      if (!matchesAdmin && !matchesAction) return false
    }
    if (actionFilter !== 'all' && log.action !== actionFilter) return false
    return true
  })

  const uniqueActions = Array.from(new Set(logs.map(log => log.action)))

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="bg-stone-900 border border-stone-800 rounded-xl">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="p-4 border-b border-stone-800 animate-pulse">
              <div className="h-5 bg-stone-800 rounded w-1/3 mb-2" />
              <div className="h-4 bg-stone-800 rounded w-1/4" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
          Activity Logs
        </h1>
        <p className="text-stone-400">
          Track all admin actions on the platform
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-500" />
          <input
            type="text"
            placeholder="Search by admin or action..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2.5 pl-12 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Action filter */}
        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 focus:outline-none focus:ring-2 focus:ring-red-500/50"
        >
          <option value="all">All Actions</option>
          {uniqueActions.map(action => (
            <option key={action} value={action}>
              {getActionLabel(action)}
            </option>
          ))}
        </select>
      </div>

      {/* Logs list */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="p-12 text-center">
            <Activity className="w-12 h-12 text-stone-600 mx-auto mb-4" />
            <p className="text-stone-400">No activity logs found</p>
          </div>
        ) : (
          <div className="divide-y divide-stone-800">
            {filteredLogs.map((log) => {
              const Icon = ACTION_ICONS[log.action] || ACTION_ICONS.default
              const colorClass = ACTION_COLORS[log.action] || ACTION_COLORS.default

              return (
                <div key={log.id} className="p-4 hover:bg-stone-800/50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-xl ${colorClass.split(' ')[1]} flex items-center justify-center shrink-0`}>
                      <Icon className={`w-5 h-5 ${colorClass.split(' ')[0]}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-stone-100">
                          {log.platform_admins?.full_name || 'Unknown Admin'}
                        </span>
                        <span className="text-stone-500">•</span>
                        <span className="text-stone-400">
                          {getActionLabel(log.action)}
                        </span>
                      </div>
                      {log.details && (
                        <p className="text-sm text-stone-500 mb-1">
                          {log.entity_type && (
                            <span className="capitalize">{log.entity_type}: </span>
                          )}
                          {log.details.email || log.details.reason || JSON.stringify(log.details)}
                        </p>
                      )}
                      <div className="flex items-center gap-4 text-xs text-stone-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {formatDate(log.created_at)}
                        </span>
                        {log.ip_address && (
                          <span>IP: {log.ip_address}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {filteredLogs.length > 0 && (
        <p className="text-sm text-stone-500 text-center">
          Showing {filteredLogs.length} of {logs.length} logs
        </p>
      )}
    </div>
  )
}
