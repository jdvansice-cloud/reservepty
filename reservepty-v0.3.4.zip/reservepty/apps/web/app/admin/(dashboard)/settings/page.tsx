'use client'

import { useState, useEffect } from 'react'
import {
  Settings,
  DollarSign,
  Users,
  Clock,
  AlertTriangle,
  Save,
  Loader2,
  Check
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface PlatformSettings {
  pricing: {
    planes: number
    helicopters: number
    residences: number
    boats: number
  }
  seat_tiers: number[]
  trial_days: number
  maintenance_mode: boolean
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<PlatformSettings>({
    pricing: { planes: 99, helicopters: 99, residences: 79, boats: 79 },
    seat_tiers: [5, 10, 25, 50, 100],
    trial_days: 14,
    maintenance_mode: false,
  })
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [isSuperAdmin, setIsSuperAdmin] = useState(false)

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    const supabase = createClient()

    // Check if super admin
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: admin } = await supabase
        .from('platform_admins')
        .select('role')
        .eq('user_id', user.id)
        .single()
      setIsSuperAdmin(admin?.role === 'super_admin')
    }

    // Load settings
    const { data, error } = await supabase
      .from('platform_settings')
      .select('*')

    if (!error && data) {
      const settingsMap: any = {}
      data.forEach((item: any) => {
        settingsMap[item.key] = item.value
      })
      
      setSettings({
        pricing: settingsMap.pricing || settings.pricing,
        seat_tiers: settingsMap.seat_tiers || settings.seat_tiers,
        trial_days: parseInt(settingsMap.trial_days) || settings.trial_days,
        maintenance_mode: settingsMap.maintenance_mode === 'true',
      })
    }
    setIsLoading(false)
  }

  const handleSave = async () => {
    if (!isSuperAdmin) return

    setIsSaving(true)
    setSaved(false)

    const supabase = createClient()

    try {
      const updates = [
        { key: 'pricing', value: settings.pricing },
        { key: 'seat_tiers', value: settings.seat_tiers },
        { key: 'trial_days', value: String(settings.trial_days) },
        { key: 'maintenance_mode', value: String(settings.maintenance_mode) },
      ]

      for (const update of updates) {
        await supabase
          .from('platform_settings')
          .upsert({ key: update.key, value: update.value, updated_at: new Date().toISOString() })
      }

      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (err) {
      console.error('Error saving settings:', err)
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-stone-800 rounded animate-pulse" />
        <div className="grid gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-stone-900 border border-stone-800 rounded-xl p-6 animate-pulse">
              <div className="h-5 bg-stone-800 rounded w-1/4 mb-4" />
              <div className="h-20 bg-stone-800 rounded" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Platform Settings
          </h1>
          <p className="text-stone-400">
            Configure global platform settings
          </p>
        </div>
        {isSuperAdmin && (
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="px-4 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Saving...
              </>
            ) : saved ? (
              <>
                <Check className="w-5 h-5" />
                Saved!
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                Save Changes
              </>
            )}
          </button>
        )}
      </div>

      {!isSuperAdmin && (
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
          <p className="text-sm text-yellow-400">
            <strong>Note:</strong> Only Super Admins can modify platform settings. 
            You have read-only access.
          </p>
        </div>
      )}

      {/* Pricing */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
            <DollarSign className="w-5 h-5 text-green-400" />
          </div>
          <div>
            <h2 className="font-display text-lg font-medium text-stone-50">
              Section Pricing
            </h2>
            <p className="text-sm text-stone-500">Monthly subscription price per section</p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(settings.pricing).map(([section, price]) => (
            <div key={section}>
              <label className="block text-sm font-medium text-stone-300 mb-2 capitalize">
                {section}
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-500">$</span>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setSettings({
                    ...settings,
                    pricing: { ...settings.pricing, [section]: parseInt(e.target.value) || 0 }
                  })}
                  disabled={!isSuperAdmin}
                  className="w-full px-4 py-2.5 pl-8 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 focus:outline-none focus:ring-2 focus:ring-red-500/50 disabled:opacity-50"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Seat Tiers */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h2 className="font-display text-lg font-medium text-stone-50">
              Seat Tiers
            </h2>
            <p className="text-sm text-stone-500">Available seat quantity options for subscriptions</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          {settings.seat_tiers.map((tier, index) => (
            <div key={index} className="flex items-center gap-2">
              <input
                type="number"
                value={tier}
                onChange={(e) => {
                  const newTiers = [...settings.seat_tiers]
                  newTiers[index] = parseInt(e.target.value) || 0
                  setSettings({ ...settings, seat_tiers: newTiers })
                }}
                disabled={!isSuperAdmin}
                className="w-20 px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 text-center focus:outline-none focus:ring-2 focus:ring-red-500/50 disabled:opacity-50"
              />
              <span className="text-stone-500">seats</span>
            </div>
          ))}
        </div>
      </div>

      {/* Trial Period */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <Clock className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h2 className="font-display text-lg font-medium text-stone-50">
              Trial Period
            </h2>
            <p className="text-sm text-stone-500">Default trial duration for new subscriptions</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="number"
            value={settings.trial_days}
            onChange={(e) => setSettings({ ...settings, trial_days: parseInt(e.target.value) || 0 })}
            disabled={!isSuperAdmin}
            className="w-24 px-4 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-stone-100 text-center focus:outline-none focus:ring-2 focus:ring-red-500/50 disabled:opacity-50"
          />
          <span className="text-stone-400">days</span>
        </div>
      </div>

      {/* Maintenance Mode */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <h2 className="font-display text-lg font-medium text-stone-50">
                Maintenance Mode
              </h2>
              <p className="text-sm text-stone-500">Temporarily disable the platform for all users</p>
            </div>
          </div>

          <button
            onClick={() => setSettings({ ...settings, maintenance_mode: !settings.maintenance_mode })}
            disabled={!isSuperAdmin}
            className={`relative w-14 h-8 rounded-full transition-colors ${
              settings.maintenance_mode ? 'bg-red-500' : 'bg-stone-700'
            } ${!isSuperAdmin ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
              settings.maintenance_mode ? 'left-7' : 'left-1'
            }`} />
          </button>
        </div>

        {settings.maintenance_mode && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-sm text-red-400">
              <strong>Warning:</strong> Maintenance mode is enabled. All users will see a maintenance page.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
