import type { Metadata, Viewport } from 'next'
import '@/styles/globals.css'

export const metadata: Metadata = {
  title: {
    default: 'ReservePTY | Luxury Asset Booking Platform',
    template: '%s | ReservePTY',
  },
  description:
    'Manage your fleet of planes, helicopters, residences, and boats with a unified booking calendar. Premium asset management for discerning families and organizations.',
  keywords: [
    'luxury asset management',
    'private aviation booking',
    'yacht reservation',
    'vacation home booking',
    'helicopter charter',
    'Panama',
    'family office',
  ],
  authors: [{ name: 'ReservePTY' }],
  creator: 'ReservePTY',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://reservepty.com',
    title: 'ReservePTY | Luxury Asset Booking Platform',
    description:
      'Manage your fleet of planes, helicopters, residences, and boats with a unified booking calendar.',
    siteName: 'ReservePTY',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ReservePTY | Luxury Asset Booking Platform',
    description:
      'Premium asset management for planes, helicopters, residences, and boats.',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: '#0a1628',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen bg-navy-950 text-stone-100 antialiased">
        {/* Noise texture overlay for luxury feel */}
        <div className="noise-overlay" aria-hidden="true" />
        
        {/* Main content */}
        {children}
      </body>
    </html>
  )
}
