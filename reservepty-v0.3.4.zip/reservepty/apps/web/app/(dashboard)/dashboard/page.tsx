'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  Calendar,
  Plane,
  Ship,
  Home,
  Users,
  ArrowRight,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalAssets: 0,
    activeReservations: 0,
    pendingApprovals: 0,
    teamMembers: 0,
  })
  const [recentReservations, setRecentReservations] = useState<any[]>([])
  const [entitlements, setEntitlements] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadDashboardData = async () => {
      const supabase = createClient()
      
      // Get current user and organization
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: membership } = await supabase
        .from('organization_members')
        .select('organization_id')
        .eq('user_id', user.id)
        .single()

      if (!membership) return

      const orgId = membership.organization_id

      // Get entitlements
      const { data: subData } = await supabase
        .from('subscriptions')
        .select(`
          id,
          entitlements (
            section,
            enabled
          )
        `)
        .eq('organization_id', orgId)
        .single()

      if (subData?.entitlements) {
        const enabledSections = subData.entitlements
          .filter((e: any) => e.enabled)
          .map((e: any) => e.section)
        setEntitlements(enabledSections)
      }

      // Get stats
      const [assetsRes, reservationsRes, pendingRes, membersRes] = await Promise.all([
        supabase
          .from('assets')
          .select('id', { count: 'exact' })
          .eq('organization_id', orgId)
          .is('deleted_at', null),
        supabase
          .from('reservations')
          .select('id', { count: 'exact' })
          .eq('organization_id', orgId)
          .in('status', ['approved', 'pending'])
          .gte('end_time', new Date().toISOString())
          .is('deleted_at', null),
        supabase
          .from('reservations')
          .select('id', { count: 'exact' })
          .eq('organization_id', orgId)
          .eq('status', 'pending')
          .is('deleted_at', null),
        supabase
          .from('organization_members')
          .select('id', { count: 'exact' })
          .eq('organization_id', orgId),
      ])

      setStats({
        totalAssets: assetsRes.count || 0,
        activeReservations: reservationsRes.count || 0,
        pendingApprovals: pendingRes.count || 0,
        teamMembers: membersRes.count || 0,
      })

      // Get recent reservations
      const { data: reservations } = await supabase
        .from('reservations')
        .select(`
          id,
          title,
          status,
          start_time,
          end_time,
          assets (
            name,
            section
          ),
          profiles:user_id (
            full_name
          )
        `)
        .eq('organization_id', orgId)
        .is('deleted_at', null)
        .order('created_at', { ascending: false })
        .limit(5)

      setRecentReservations(reservations || [])
      setIsLoading(false)
    }

    loadDashboardData()
  }, [])

  const statCards = [
    { label: 'Total Assets', value: stats.totalAssets, icon: Plane, color: 'text-blue-400' },
    { label: 'Active Reservations', value: stats.activeReservations, icon: Calendar, color: 'text-green-400' },
    { label: 'Pending Approvals', value: stats.pendingApprovals, icon: Clock, color: 'text-yellow-400' },
    { label: 'Team Members', value: stats.teamMembers, icon: Users, color: 'text-purple-400' },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'pending': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'rejected': return 'bg-red-500/10 text-red-400 border-red-500/20'
      case 'canceled': return 'bg-stone-500/10 text-stone-400 border-stone-500/20'
      default: return 'bg-stone-500/10 text-stone-400 border-stone-500/20'
    }
  }

  const getSectionIcon = (section: string) => {
    switch (section) {
      case 'planes':
      case 'helicopters': return Plane
      case 'boats': return Ship
      case 'residences': return Home
      default: return Calendar
    }
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        {/* Loading skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="h-4 bg-navy-700 rounded w-1/2 mb-4" />
              <div className="h-8 bg-navy-700 rounded w-1/3" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
          Dashboard
        </h1>
        <p className="text-stone-400">
          Overview of your assets and reservations
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <div key={stat.label} className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-stone-400">{stat.label}</span>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            <p className="text-3xl font-display font-medium text-stone-50">
              {stat.value}
            </p>
          </div>
        ))}
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <div className="lg:col-span-1">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Quick Actions
          </h2>
          <div className="space-y-3">
            <Link 
              href="/dashboard/calendar" 
              className="card-hover p-4 flex items-center gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-gold-400/10 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-gold-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-stone-200">View Calendar</p>
                <p className="text-sm text-stone-500">See all bookings</p>
              </div>
              <ArrowRight className="w-5 h-5 text-stone-500" />
            </Link>

            <Link 
              href="/dashboard/assets" 
              className="card-hover p-4 flex items-center gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-400/10 flex items-center justify-center">
                <Plane className="w-5 h-5 text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-stone-200">Manage Assets</p>
                <p className="text-sm text-stone-500">Add or edit assets</p>
              </div>
              <ArrowRight className="w-5 h-5 text-stone-500" />
            </Link>

            <Link 
              href="/dashboard/members" 
              className="card-hover p-4 flex items-center gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-400/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-purple-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-stone-200">Invite Members</p>
                <p className="text-sm text-stone-500">Grow your team</p>
              </div>
              <ArrowRight className="w-5 h-5 text-stone-500" />
            </Link>
          </div>
        </div>

        {/* Recent Reservations */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-medium text-stone-50">
              Recent Reservations
            </h2>
            <Link 
              href="/dashboard/calendar" 
              className="text-sm text-gold-400 hover:text-gold-300"
            >
              View all
            </Link>
          </div>

          {recentReservations.length === 0 ? (
            <div className="card p-8 text-center">
              <Calendar className="w-12 h-12 text-stone-600 mx-auto mb-4" />
              <p className="text-stone-400 mb-4">No reservations yet</p>
              <Link href="/dashboard/calendar" className="btn-primary">
                Create First Booking
              </Link>
            </div>
          ) : (
            <div className="card divide-y divide-navy-800">
              {recentReservations.map((reservation) => {
                const Icon = getSectionIcon(reservation.assets?.section)
                return (
                  <div key={reservation.id} className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-navy-800 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-stone-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-stone-200 truncate">
                        {reservation.title || reservation.assets?.name || 'Reservation'}
                      </p>
                      <p className="text-sm text-stone-500">
                        {formatDate(reservation.start_time)}
                      </p>
                    </div>
                    <span className={`badge border ${getStatusColor(reservation.status)}`}>
                      {reservation.status}
                    </span>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* Active Sections */}
      <div>
        <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
          Active Sections
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { id: 'planes', name: 'Planes', icon: Plane },
            { id: 'helicopters', name: 'Helicopters', icon: Plane },
            { id: 'residences', name: 'Residences', icon: Home },
            { id: 'boats', name: 'Boats', icon: Ship },
          ].map((section) => {
            const isEnabled = entitlements.includes(section.id)
            return (
              <div 
                key={section.id}
                className={`card p-4 flex items-center gap-3 ${
                  isEnabled ? '' : 'opacity-50'
                }`}
              >
                <div className={`
                  w-10 h-10 rounded-xl flex items-center justify-center
                  ${isEnabled ? 'bg-gold-400/10' : 'bg-navy-800'}
                `}>
                  <section.icon className={`w-5 h-5 ${isEnabled ? 'text-gold-400' : 'text-stone-600'}`} />
                </div>
                <div className="flex-1">
                  <p className={`font-medium ${isEnabled ? 'text-stone-200' : 'text-stone-500'}`}>
                    {section.name}
                  </p>
                  <p className="text-xs text-stone-500">
                    {isEnabled ? 'Active' : 'Not enabled'}
                  </p>
                </div>
                {isEnabled ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-stone-600" />
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
