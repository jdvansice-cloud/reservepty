'use client'

import { Settings, Building2, CreditCard, Bell, Shield } from 'lucide-react'

export default function SettingsPage() {
  const settingsSections = [
    {
      name: 'Organization',
      description: 'Update company details and branding',
      icon: Building2,
      href: '/dashboard/settings/organization',
    },
    {
      name: 'Billing',
      description: 'Manage subscription and payment methods',
      icon: CreditCard,
      href: '/dashboard/settings/billing',
    },
    {
      name: 'Notifications',
      description: 'Configure email and push notifications',
      icon: Bell,
      href: '/dashboard/settings/notifications',
    },
    {
      name: 'Security',
      description: 'Password, two-factor authentication',
      icon: Shield,
      href: '/dashboard/settings/security',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
          Settings
        </h1>
        <p className="text-stone-400">
          Manage your account and organization settings
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {settingsSections.map((section) => (
          <div 
            key={section.name}
            className="card-hover p-6 cursor-pointer"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gold-400/10 flex items-center justify-center">
                <section.icon className="w-6 h-6 text-gold-400" />
              </div>
              <div>
                <h3 className="font-medium text-stone-200 mb-1">{section.name}</h3>
                <p className="text-sm text-stone-500">{section.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="card p-8 text-center">
        <Settings className="w-12 h-12 text-stone-600 mx-auto mb-4" />
        <p className="text-stone-400">
          Full settings functionality coming in the next update.
        </p>
      </div>
    </div>
  )
}
