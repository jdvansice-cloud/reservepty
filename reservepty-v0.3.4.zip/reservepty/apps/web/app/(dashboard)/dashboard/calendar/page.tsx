'use client'

import { Calendar, Plus } from 'lucide-react'

export default function CalendarPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Calendar
          </h1>
          <p className="text-stone-400">
            View and manage all reservations
          </p>
        </div>
        <button className="btn-primary">
          <Plus className="w-5 h-5" />
          New Booking
        </button>
      </div>

      <div className="card p-12 text-center">
        <Calendar className="w-16 h-16 text-stone-600 mx-auto mb-4" />
        <h2 className="font-display text-xl font-medium text-stone-200 mb-2">
          Calendar Coming Soon
        </h2>
        <p className="text-stone-400 max-w-md mx-auto">
          The unified calendar with booking management will be available in the next update.
        </p>
      </div>
    </div>
  )
}
