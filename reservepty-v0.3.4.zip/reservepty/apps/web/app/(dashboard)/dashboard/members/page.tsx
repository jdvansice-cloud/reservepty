'use client'

import { Users, Plus } from 'lucide-react'

export default function MembersPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Team Members
          </h1>
          <p className="text-stone-400">
            Manage users, roles, and tiers
          </p>
        </div>
        <button className="btn-primary">
          <Plus className="w-5 h-5" />
          Invite Member
        </button>
      </div>

      <div className="card p-12 text-center">
        <Users className="w-16 h-16 text-stone-600 mx-auto mb-4" />
        <h2 className="font-display text-xl font-medium text-stone-200 mb-2">
          Member Management Coming Soon
        </h2>
        <p className="text-stone-400 max-w-md mx-auto">
          Invite team members, assign roles, and configure booking tiers with priority rules.
        </p>
      </div>
    </div>
  )
}
