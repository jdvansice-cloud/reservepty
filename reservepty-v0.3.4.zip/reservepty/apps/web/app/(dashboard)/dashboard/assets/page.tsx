'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  Plus,
  Search,
  Plane,
  Ship,
  Home,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  X,
  AlertCircle
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

type AssetSection = 'all' | 'planes' | 'helicopters' | 'residences' | 'boats'

interface Asset {
  id: string
  name: string
  section: string
  description: string | null
  is_active: boolean
  created_at: string
  metadata: any
  asset_photos?: { url: string; is_primary: boolean }[]
}

const SECTION_CONFIG: Record<string, { label: string; icon: any; color: string; bg: string }> = {
  planes: { label: 'Planes', icon: Plane, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  helicopters: { label: 'Helicopters', icon: Plane, color: 'text-purple-400', bg: 'bg-purple-400/10' },
  residences: { label: 'Residences', icon: Home, color: 'text-green-400', bg: 'bg-green-400/10' },
  boats: { label: 'Boats', icon: Ship, color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
}

export default function AssetsPage() {
  const [assets, setAssets] = useState<Asset[]>([])
  const [filteredAssets, setFilteredAssets] = useState<Asset[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedSection, setSelectedSection] = useState<AssetSection>('all')
  const [entitlements, setEntitlements] = useState<string[]>([])
  const [deleteModal, setDeleteModal] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const [openMenu, setOpenMenu] = useState<string | null>(null)

  useEffect(() => {
    loadAssets()
  }, [])

  useEffect(() => {
    filterAssets()
  }, [assets, searchQuery, selectedSection])

  const loadAssets = async () => {
    const supabase = createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { data: membership } = await supabase
      .from('organization_members')
      .select('organization_id')
      .eq('user_id', user.id)
      .single()

    if (!membership) return

    // Get entitlements
    const { data: subData } = await supabase
      .from('subscriptions')
      .select(`
        entitlements (
          section,
          enabled
        )
      `)
      .eq('organization_id', membership.organization_id)
      .single()

    if (subData?.entitlements) {
      const enabled = subData.entitlements
        .filter((e: any) => e.enabled)
        .map((e: any) => e.section)
      setEntitlements(enabled)
    }

    // Get assets with photos
    const { data: assetsData } = await supabase
      .from('assets')
      .select(`
        *,
        asset_photos (
          url,
          is_primary
        )
      `)
      .eq('organization_id', membership.organization_id)
      .is('deleted_at', null)
      .order('created_at', { ascending: false })

    setAssets(assetsData || [])
    setIsLoading(false)
  }

  const filterAssets = () => {
    let filtered = [...assets]

    if (selectedSection !== 'all') {
      filtered = filtered.filter(a => a.section === selectedSection)
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(a => 
        a.name.toLowerCase().includes(query) ||
        a.description?.toLowerCase().includes(query)
      )
    }

    setFilteredAssets(filtered)
  }

  const handleDelete = async (assetId: string) => {
    setIsDeleting(true)
    const supabase = createClient()

    const { error } = await supabase
      .from('assets')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', assetId)

    if (!error) {
      setAssets(assets.filter(a => a.id !== assetId))
    }

    setIsDeleting(false)
    setDeleteModal(null)
  }

  const getAssetImage = (asset: Asset) => {
    const primaryPhoto = asset.asset_photos?.find(p => p.is_primary)
    return primaryPhoto?.url || asset.asset_photos?.[0]?.url
  }

  const availableSections = Object.entries(SECTION_CONFIG).filter(([key]) => 
    entitlements.includes(key)
  )

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="h-8 w-32 bg-navy-800 rounded animate-pulse" />
          <div className="h-10 w-32 bg-navy-800 rounded animate-pulse" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="card p-4 animate-pulse">
              <div className="h-40 bg-navy-800 rounded-lg mb-4" />
              <div className="h-5 bg-navy-800 rounded w-2/3 mb-2" />
              <div className="h-4 bg-navy-800 rounded w-1/2" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-medium text-stone-50 mb-1">
            Assets
          </h1>
          <p className="text-stone-400">
            Manage your planes, helicopters, residences, and boats
          </p>
        </div>
        {availableSections.length > 0 && (
          <Link href="/dashboard/assets/new" className="btn-primary">
            <Plus className="w-5 h-5" />
            Add Asset
          </Link>
        )}
      </div>

      {/* No entitlements warning */}
      {availableSections.length === 0 && (
        <div className="card p-8 text-center">
          <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="font-display text-xl font-medium text-stone-200 mb-2">
            No Sections Enabled
          </h2>
          <p className="text-stone-400 mb-4">
            You need to enable at least one section to manage assets.
          </p>
          <Link href="/dashboard/settings" className="btn-primary">
            Go to Settings
          </Link>
        </div>
      )}

      {/* Filters */}
      {availableSections.length > 0 && (
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-500" />
            <input
              type="text"
              placeholder="Search assets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input pl-12 w-full"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Section filter */}
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setSelectedSection('all')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedSection === 'all'
                  ? 'bg-gold-400/10 text-gold-400 border border-gold-400/30'
                  : 'bg-navy-800 text-stone-400 border border-navy-700 hover:border-navy-600'
              }`}
            >
              All
            </button>
            {availableSections.map(([key, config]) => {
              const Icon = config.icon
              return (
                <button
                  key={key}
                  onClick={() => setSelectedSection(key as AssetSection)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                    selectedSection === key
                      ? `${config.bg} ${config.color} border border-current/30`
                      : 'bg-navy-800 text-stone-400 border border-navy-700 hover:border-navy-600'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {config.label}
                </button>
              )
            })}
          </div>
        </div>
      )}

      {/* Assets grid */}
      {availableSections.length > 0 && (
        <>
          {filteredAssets.length === 0 ? (
            <div className="card p-12 text-center">
              {assets.length === 0 ? (
                <>
                  <div className="w-16 h-16 rounded-2xl bg-gold-400/10 flex items-center justify-center mx-auto mb-4">
                    <Plus className="w-8 h-8 text-gold-400" />
                  </div>
                  <h2 className="font-display text-xl font-medium text-stone-200 mb-2">
                    No Assets Yet
                  </h2>
                  <p className="text-stone-400 mb-6">
                    Add your first asset to start managing bookings.
                  </p>
                  <Link href="/dashboard/assets/new" className="btn-primary">
                    <Plus className="w-5 h-5" />
                    Add Your First Asset
                  </Link>
                </>
              ) : (
                <>
                  <Search className="w-12 h-12 text-stone-600 mx-auto mb-4" />
                  <h2 className="font-display text-xl font-medium text-stone-200 mb-2">
                    No Results Found
                  </h2>
                  <p className="text-stone-400">
                    Try adjusting your search or filter criteria.
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAssets.map((asset) => {
                const config = SECTION_CONFIG[asset.section]
                const Icon = config?.icon || Plane
                const imageUrl = getAssetImage(asset)

                return (
                  <div key={asset.id} className="card group relative">
                    {/* Image */}
                    <div className="relative h-44 bg-navy-800 rounded-t-xl overflow-hidden">
                      {imageUrl ? (
                        <img
                          src={imageUrl}
                          alt={asset.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Icon className={`w-16 h-16 ${config?.color || 'text-stone-600'} opacity-30`} />
                        </div>
                      )}
                      
                      {/* Section badge */}
                      <div className={`absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-medium ${config?.bg} ${config?.color} backdrop-blur-sm`}>
                        {config?.label}
                      </div>

                      {/* Status badge */}
                      {!asset.is_active && (
                        <div className="absolute top-3 right-3 px-2.5 py-1 rounded-lg text-xs font-medium bg-stone-500/20 text-stone-400 backdrop-blur-sm">
                          Inactive
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <h3 className="font-medium text-stone-100 truncate">
                            {asset.name}
                          </h3>
                          {asset.description && (
                            <p className="text-sm text-stone-500 truncate mt-1">
                              {asset.description}
                            </p>
                          )}
                        </div>

                        {/* Actions menu */}
                        <div className="relative">
                          <button
                            onClick={() => setOpenMenu(openMenu === asset.id ? null : asset.id)}
                            className="p-2 rounded-lg text-stone-500 hover:text-stone-300 hover:bg-navy-700 transition-colors"
                          >
                            <MoreVertical className="w-5 h-5" />
                          </button>

                          {openMenu === asset.id && (
                            <>
                              <div 
                                className="fixed inset-0 z-10" 
                                onClick={() => setOpenMenu(null)}
                              />
                              <div className="absolute right-0 top-full mt-1 w-48 bg-navy-800 border border-navy-700 rounded-xl shadow-luxury z-20 py-1">
                                <Link
                                  href={`/dashboard/assets/${asset.id}`}
                                  className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-navy-700 transition-colors"
                                  onClick={() => setOpenMenu(null)}
                                >
                                  <Eye className="w-4 h-4" />
                                  View Details
                                </Link>
                                <Link
                                  href={`/dashboard/assets/${asset.id}/edit`}
                                  className="flex items-center gap-3 px-4 py-2.5 text-sm text-stone-300 hover:bg-navy-700 transition-colors"
                                  onClick={() => setOpenMenu(null)}
                                >
                                  <Edit className="w-4 h-4" />
                                  Edit
                                </Link>
                                <button
                                  onClick={() => {
                                    setDeleteModal(asset.id)
                                    setOpenMenu(null)
                                  }}
                                  className="flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-navy-700 transition-colors w-full"
                                >
                                  <Trash2 className="w-4 h-4" />
                                  Delete
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </>
      )}

      {/* Delete confirmation modal */}
      {deleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card p-6 max-w-md w-full">
            <h3 className="font-display text-xl font-medium text-stone-50 mb-2">
              Delete Asset
            </h3>
            <p className="text-stone-400 mb-6">
              Are you sure you want to delete this asset? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteModal(null)}
                className="btn-ghost flex-1"
                disabled={isDeleting}
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteModal)}
                disabled={isDeleting}
                className="flex-1 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors font-medium"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
