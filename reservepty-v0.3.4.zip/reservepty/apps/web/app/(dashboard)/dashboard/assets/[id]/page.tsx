import AssetDetailClient from '../_components/AssetDetailClient'

export default function AssetDetailPage() {
  return <AssetDetailClient />
}
