'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  Loader2,
  Upload,
  X,
  Plane,
  Ship,
  Home,
  Check,
  Trash2
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const SECTION_CONFIG: Record<string, { label: string; icon: any }> = {
  planes: { label: 'Plane', icon: Plane },
  helicopters: { label: 'Helicopter', icon: Plane },
  residences: { label: 'Residence', icon: Home },
  boats: { label: 'Boat', icon: Ship },
}

export default function EditAssetClient() {
  const params = useParams()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [asset, setAsset] = useState<any>(null)

  // Form state
  const [basicInfo, setBasicInfo] = useState({
    name: '',
    description: '',
    is_active: true,
  })
  
  const [aircraftDetails, setAircraftDetails] = useState({
    registration: '',
    manufacturer: '',
    model: '',
    year: '',
    cruise_speed_kts: '',
    turnaround_minutes: '60',
    adjustment_factor: '1.15',
    current_location: '',
  })

  const [boatDetails, setBoatDetails] = useState({
    registration: '',
    manufacturer: '',
    model: '',
    year: '',
    length_ft: '',
    turnaround_minutes: '120',
    current_port: '',
    captain_required: false,
  })

  const [residenceDetails, setResidenceDetails] = useState({
    address: '',
    city: '',
    country: 'Panama',
    bedrooms: '',
    bathrooms: '',
    max_guests: '',
    cleaning_buffer_hours: '4',
    check_in_time: '15:00',
    check_out_time: '11:00',
  })

  // Photos
  const [existingPhotos, setExistingPhotos] = useState<any[]>([])
  const [newPhotos, setNewPhotos] = useState<File[]>([])
  const [newPhotoPreviews, setNewPhotoPreviews] = useState<string[]>([])
  const [photosToDelete, setPhotosToDelete] = useState<string[]>([])
  const [primaryPhotoId, setPrimaryPhotoId] = useState<string | null>(null)

  useEffect(() => {
    loadAsset()
  }, [params.id])

  const loadAsset = async () => {
    const supabase = createClient()
    
    const { data, error } = await supabase
      .from('assets')
      .select(`
        *,
        asset_photos (
          id,
          url,
          is_primary
        ),
        aircraft_details (*),
        boat_details (*),
        residence_details (*)
      `)
      .eq('id', params.id)
      .single()

    if (error || !data) {
      router.push('/dashboard/assets')
      return
    }

    setAsset(data)
    setBasicInfo({
      name: data.name || '',
      description: data.description || '',
      is_active: data.is_active,
    })

    // Load section-specific details
    const details = data.aircraft_details?.[0] || data.boat_details?.[0] || data.residence_details?.[0]
    
    if (data.section === 'planes' || data.section === 'helicopters') {
      setAircraftDetails({
        registration: details?.registration || '',
        manufacturer: details?.manufacturer || '',
        model: details?.model || '',
        year: details?.year?.toString() || '',
        cruise_speed_kts: details?.cruise_speed_kts?.toString() || '',
        turnaround_minutes: details?.turnaround_minutes?.toString() || '60',
        adjustment_factor: details?.adjustment_factor?.toString() || '1.15',
        current_location: details?.current_location || '',
      })
    }

    if (data.section === 'boats') {
      setBoatDetails({
        registration: details?.registration || '',
        manufacturer: details?.manufacturer || '',
        model: details?.model || '',
        year: details?.year?.toString() || '',
        length_ft: details?.length_ft?.toString() || '',
        turnaround_minutes: details?.turnaround_minutes?.toString() || '120',
        current_port: details?.current_port || '',
        captain_required: details?.captain_required || false,
      })
    }

    if (data.section === 'residences') {
      setResidenceDetails({
        address: details?.address || '',
        city: details?.city || '',
        country: details?.country || 'Panama',
        bedrooms: details?.bedrooms?.toString() || '',
        bathrooms: details?.bathrooms?.toString() || '',
        max_guests: details?.max_guests?.toString() || '',
        cleaning_buffer_hours: details?.cleaning_buffer_hours?.toString() || '4',
        check_in_time: details?.check_in_time || '15:00',
        check_out_time: details?.check_out_time || '11:00',
      })
    }

    // Load photos
    setExistingPhotos(data.asset_photos || [])
    const primary = data.asset_photos?.find((p: any) => p.is_primary)
    setPrimaryPhotoId(primary?.id || data.asset_photos?.[0]?.id || null)

    setIsLoading(false)
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    const totalPhotos = existingPhotos.length - photosToDelete.length + newPhotos.length + files.length
    const allowedFiles = files.slice(0, Math.max(0, 10 - (existingPhotos.length - photosToDelete.length + newPhotos.length)))
    
    setNewPhotos([...newPhotos, ...allowedFiles])

    allowedFiles.forEach((file) => {
      const reader = new FileReader()
      reader.onloadend = () => {
        setNewPhotoPreviews(prev => [...prev, reader.result as string])
      }
      reader.readAsDataURL(file)
    })
  }

  const removeExistingPhoto = (photoId: string) => {
    setPhotosToDelete([...photosToDelete, photoId])
    if (primaryPhotoId === photoId) {
      const remaining = existingPhotos.filter(p => !photosToDelete.includes(p.id) && p.id !== photoId)
      setPrimaryPhotoId(remaining[0]?.id || null)
    }
  }

  const removeNewPhoto = (index: number) => {
    setNewPhotos(newPhotos.filter((_, i) => i !== index))
    setNewPhotoPreviews(newPhotoPreviews.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    if (!asset) return
    
    setIsSaving(true)
    setError(null)

    try {
      const supabase = createClient()

      // Update asset
      const { error: assetError } = await supabase
        .from('assets')
        .update({
          name: basicInfo.name,
          description: basicInfo.description || null,
          is_active: basicInfo.is_active,
        })
        .eq('id', asset.id)

      if (assetError) throw assetError

      // Update section-specific details
      if (asset.section === 'planes' || asset.section === 'helicopters') {
        const { error: detailsError } = await supabase
          .from('aircraft_details')
          .upsert({
            asset_id: asset.id,
            registration: aircraftDetails.registration || null,
            manufacturer: aircraftDetails.manufacturer || null,
            model: aircraftDetails.model || null,
            year: aircraftDetails.year ? parseInt(aircraftDetails.year) : null,
            cruise_speed_kts: aircraftDetails.cruise_speed_kts ? parseFloat(aircraftDetails.cruise_speed_kts) : null,
            turnaround_minutes: parseInt(aircraftDetails.turnaround_minutes) || 60,
            adjustment_factor: parseFloat(aircraftDetails.adjustment_factor) || 1.15,
            current_location: aircraftDetails.current_location || null,
          }, { onConflict: 'asset_id' })

        if (detailsError) console.error('Aircraft details error:', detailsError)
      }

      if (asset.section === 'boats') {
        const { error: detailsError } = await supabase
          .from('boat_details')
          .upsert({
            asset_id: asset.id,
            registration: boatDetails.registration || null,
            manufacturer: boatDetails.manufacturer || null,
            model: boatDetails.model || null,
            year: boatDetails.year ? parseInt(boatDetails.year) : null,
            length_ft: boatDetails.length_ft ? parseFloat(boatDetails.length_ft) : null,
            turnaround_minutes: parseInt(boatDetails.turnaround_minutes) || 120,
            current_port: boatDetails.current_port || null,
            captain_required: boatDetails.captain_required,
          }, { onConflict: 'asset_id' })

        if (detailsError) console.error('Boat details error:', detailsError)
      }

      if (asset.section === 'residences') {
        const { error: detailsError } = await supabase
          .from('residence_details')
          .upsert({
            asset_id: asset.id,
            address: residenceDetails.address || null,
            city: residenceDetails.city || null,
            country: residenceDetails.country || 'Panama',
            bedrooms: residenceDetails.bedrooms ? parseInt(residenceDetails.bedrooms) : null,
            bathrooms: residenceDetails.bathrooms ? parseFloat(residenceDetails.bathrooms) : null,
            max_guests: residenceDetails.max_guests ? parseInt(residenceDetails.max_guests) : null,
            cleaning_buffer_hours: parseInt(residenceDetails.cleaning_buffer_hours) || 4,
            check_in_time: residenceDetails.check_in_time || '15:00',
            check_out_time: residenceDetails.check_out_time || '11:00',
          }, { onConflict: 'asset_id' })

        if (detailsError) console.error('Residence details error:', detailsError)
      }

      // Delete marked photos
      for (const photoId of photosToDelete) {
        await supabase
          .from('asset_photos')
          .delete()
          .eq('id', photoId)
      }

      // Upload new photos
      for (let i = 0; i < newPhotos.length; i++) {
        const photo = newPhotos[i]
        const fileExt = photo.name.split('.').pop()
        const fileName = `${asset.id}/${Date.now()}-${i}.${fileExt}`

        const { error: uploadError } = await supabase.storage
          .from('asset-photos')
          .upload(fileName, photo)

        if (uploadError) {
          console.error('Photo upload error:', uploadError)
          continue
        }

        const { data: { publicUrl } } = supabase.storage
          .from('asset-photos')
          .getPublicUrl(fileName)

        await supabase
          .from('asset_photos')
          .insert({
            asset_id: asset.id,
            url: publicUrl,
            is_primary: false,
          })
      }

      // Update primary photo
      if (primaryPhotoId) {
        // First set all to non-primary
        await supabase
          .from('asset_photos')
          .update({ is_primary: false })
          .eq('asset_id', asset.id)
        
        // Then set the selected one as primary
        await supabase
          .from('asset_photos')
          .update({ is_primary: true })
          .eq('id', primaryPhotoId)
      }

      router.push(`/dashboard/assets/${asset.id}`)
    } catch (err: any) {
      console.error('Save error:', err)
      setError(err.message || 'Failed to save asset')
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-gold-400 animate-spin" />
      </div>
    )
  }

  if (!asset) return null

  const config = SECTION_CONFIG[asset.section]
  const Icon = config?.icon || Plane
  const visibleExistingPhotos = existingPhotos.filter(p => !photosToDelete.includes(p.id))

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          href={`/dashboard/assets/${params.id}`}
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Asset
        </Link>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl bg-navy-800 flex items-center justify-center`}>
            <Icon className="w-6 h-6 text-stone-400" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-medium text-stone-50">
              Edit {config?.label}
            </h1>
            <p className="text-stone-400">{asset.name}</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Basic Info */}
        <div className="card p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-6">
            Basic Information
          </h2>
          <div className="space-y-4">
            <div>
              <label className="input-label">Asset Name *</label>
              <input
                type="text"
                value={basicInfo.name}
                onChange={(e) => setBasicInfo({ ...basicInfo, name: e.target.value })}
                className="input"
              />
            </div>

            <div>
              <label className="input-label">Description</label>
              <textarea
                value={basicInfo.description}
                onChange={(e) => setBasicInfo({ ...basicInfo, description: e.target.value })}
                className="input min-h-[100px]"
              />
            </div>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={basicInfo.is_active}
                onChange={(e) => setBasicInfo({ ...basicInfo, is_active: e.target.checked })}
                className="w-5 h-5 rounded border-navy-600 bg-navy-800 text-gold-400 focus:ring-gold-400"
              />
              <span className="text-stone-300">Asset is active and available for booking</span>
            </label>
          </div>
        </div>

        {/* Section-specific details */}
        {(asset.section === 'planes' || asset.section === 'helicopters') && (
          <div className="card p-6">
            <h2 className="font-display text-lg font-medium text-stone-50 mb-6">
              Aircraft Details
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="input-label">Registration / Tail #</label>
                <input
                  type="text"
                  value={aircraftDetails.registration}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, registration: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Current Location</label>
                <input
                  type="text"
                  value={aircraftDetails.current_location}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, current_location: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Manufacturer</label>
                <input
                  type="text"
                  value={aircraftDetails.manufacturer}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, manufacturer: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Model</label>
                <input
                  type="text"
                  value={aircraftDetails.model}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, model: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Year</label>
                <input
                  type="number"
                  value={aircraftDetails.year}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, year: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Cruise Speed (kts)</label>
                <input
                  type="number"
                  value={aircraftDetails.cruise_speed_kts}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, cruise_speed_kts: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Turnaround (minutes)</label>
                <input
                  type="number"
                  value={aircraftDetails.turnaround_minutes}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, turnaround_minutes: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Adjustment Factor</label>
                <input
                  type="number"
                  step="0.01"
                  value={aircraftDetails.adjustment_factor}
                  onChange={(e) => setAircraftDetails({ ...aircraftDetails, adjustment_factor: e.target.value })}
                  className="input"
                />
              </div>
            </div>
          </div>
        )}

        {asset.section === 'boats' && (
          <div className="card p-6">
            <h2 className="font-display text-lg font-medium text-stone-50 mb-6">
              Boat Details
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="input-label">Registration</label>
                <input
                  type="text"
                  value={boatDetails.registration}
                  onChange={(e) => setBoatDetails({ ...boatDetails, registration: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Current Port</label>
                <input
                  type="text"
                  value={boatDetails.current_port}
                  onChange={(e) => setBoatDetails({ ...boatDetails, current_port: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Manufacturer</label>
                <input
                  type="text"
                  value={boatDetails.manufacturer}
                  onChange={(e) => setBoatDetails({ ...boatDetails, manufacturer: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Model</label>
                <input
                  type="text"
                  value={boatDetails.model}
                  onChange={(e) => setBoatDetails({ ...boatDetails, model: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Year</label>
                <input
                  type="number"
                  value={boatDetails.year}
                  onChange={(e) => setBoatDetails({ ...boatDetails, year: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Length (ft)</label>
                <input
                  type="number"
                  value={boatDetails.length_ft}
                  onChange={(e) => setBoatDetails({ ...boatDetails, length_ft: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Turnaround (minutes)</label>
                <input
                  type="number"
                  value={boatDetails.turnaround_minutes}
                  onChange={(e) => setBoatDetails({ ...boatDetails, turnaround_minutes: e.target.value })}
                  className="input"
                />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-3 cursor-pointer p-3 bg-navy-800/50 rounded-xl w-full">
                  <input
                    type="checkbox"
                    checked={boatDetails.captain_required}
                    onChange={(e) => setBoatDetails({ ...boatDetails, captain_required: e.target.checked })}
                    className="w-5 h-5 rounded border-navy-600 bg-navy-800 text-gold-400 focus:ring-gold-400"
                  />
                  <span className="text-stone-300">Captain Required</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {asset.section === 'residences' && (
          <div className="card p-6">
            <h2 className="font-display text-lg font-medium text-stone-50 mb-6">
              Property Details
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="input-label">Address</label>
                <input
                  type="text"
                  value={residenceDetails.address}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, address: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">City</label>
                <input
                  type="text"
                  value={residenceDetails.city}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, city: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Country</label>
                <input
                  type="text"
                  value={residenceDetails.country}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, country: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Bedrooms</label>
                <input
                  type="number"
                  value={residenceDetails.bedrooms}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, bedrooms: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Bathrooms</label>
                <input
                  type="number"
                  step="0.5"
                  value={residenceDetails.bathrooms}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, bathrooms: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Max Guests</label>
                <input
                  type="number"
                  value={residenceDetails.max_guests}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, max_guests: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Cleaning Buffer (hours)</label>
                <input
                  type="number"
                  value={residenceDetails.cleaning_buffer_hours}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, cleaning_buffer_hours: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Check-in Time</label>
                <input
                  type="time"
                  value={residenceDetails.check_in_time}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, check_in_time: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="input-label">Check-out Time</label>
                <input
                  type="time"
                  value={residenceDetails.check_out_time}
                  onChange={(e) => setResidenceDetails({ ...residenceDetails, check_out_time: e.target.value })}
                  className="input"
                />
              </div>
            </div>
          </div>
        )}

        {/* Photos */}
        <div className="card p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-2">
            Photos
          </h2>
          <p className="text-stone-400 text-sm mb-6">
            Click on a photo to set it as primary. Max 10 photos.
          </p>

          {/* Existing photos */}
          {visibleExistingPhotos.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
              {visibleExistingPhotos.map((photo) => (
                <div 
                  key={photo.id}
                  onClick={() => setPrimaryPhotoId(photo.id)}
                  className={`
                    relative aspect-square rounded-xl overflow-hidden cursor-pointer
                    ${primaryPhotoId === photo.id ? 'ring-2 ring-gold-400' : ''}
                  `}
                >
                  <img
                    src={photo.url}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                  {primaryPhotoId === photo.id && (
                    <div className="absolute top-2 left-2 px-2 py-1 bg-gold-400 text-navy-950 text-xs font-medium rounded">
                      Primary
                    </div>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      removeExistingPhoto(photo.id)
                    }}
                    className="absolute top-2 right-2 p-1 bg-black/50 rounded-lg text-white hover:bg-red-500/80 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* New photos */}
          {newPhotoPreviews.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
              {newPhotoPreviews.map((preview, index) => (
                <div 
                  key={index}
                  className="relative aspect-square rounded-xl overflow-hidden"
                >
                  <img
                    src={preview}
                    alt={`New photo ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2 px-2 py-1 bg-green-500 text-white text-xs font-medium rounded">
                    New
                  </div>
                  <button
                    onClick={() => removeNewPhoto(index)}
                    className="absolute top-2 right-2 p-1 bg-black/50 rounded-lg text-white hover:bg-red-500/80 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Upload area */}
          {visibleExistingPhotos.length + newPhotos.length < 10 && (
            <label className="block border-2 border-dashed border-navy-700 rounded-xl p-8 text-center cursor-pointer hover:border-gold-400/50 transition-colors">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <Upload className="w-10 h-10 text-stone-500 mx-auto mb-3" />
              <p className="text-stone-300 font-medium">Click to upload photos</p>
              <p className="text-stone-500 text-sm">
                {10 - visibleExistingPhotos.length - newPhotos.length} slots remaining
              </p>
            </label>
          )}
        </div>

        {/* Error */}
        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-between">
          <Link href={`/dashboard/assets/${params.id}`} className="btn-ghost">
            Cancel
          </Link>
          <button
            onClick={handleSubmit}
            disabled={isSaving || !basicInfo.name}
            className="btn-primary"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Check className="w-5 h-5" />
                Save Changes
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
