import EditAssetClient from '../../_components/EditAssetClient'

export default function EditAssetPage() {
  return <EditAssetClient />
}
