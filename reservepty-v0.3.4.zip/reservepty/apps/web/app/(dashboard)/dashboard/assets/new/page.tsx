'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  ArrowRight,
  Loader2,
  Upload,
  X,
  Plane,
  Ship,
  Home,
  Check
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const SECTIONS = [
  { 
    id: 'planes', 
    name: 'Plane', 
    icon: Plane,
    description: 'Fixed-wing aircraft'
  },
  { 
    id: 'helicopters', 
    name: 'Helicopter', 
    icon: Plane,
    description: 'Rotary-wing aircraft'
  },
  { 
    id: 'residences', 
    name: 'Residence / Space', 
    icon: Home,
    description: 'Homes, villas, apartments, meeting rooms'
  },
  { 
    id: 'boats', 
    name: 'Boat / Yacht', 
    icon: Ship,
    description: 'Marine vessels'
  },
]

export default function NewAssetPage() {
  const router = useRouter()
  const [step, setStep] = useState<'section' | 'details' | 'photos'>('section')
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [entitlements, setEntitlements] = useState<string[]>([])
  const [organizationId, setOrganizationId] = useState<string | null>(null)

  // Form state
  const [selectedSection, setSelectedSection] = useState<string | null>(null)
  const [basicInfo, setBasicInfo] = useState({
    name: '',
    description: '',
    is_active: true,
  })
  
  // Section-specific details
  const [aircraftDetails, setAircraftDetails] = useState({
    registration: '',
    manufacturer: '',
    model: '',
    year: '',
    cruise_speed_kts: '',
    turnaround_minutes: '60',
    adjustment_factor: '1.15',
    current_location: '',
  })

  const [boatDetails, setBoatDetails] = useState({
    registration: '',
    manufacturer: '',
    model: '',
    year: '',
    length_ft: '',
    turnaround_minutes: '120',
    current_port: '',
    captain_required: false,
  })

  const [residenceDetails, setResidenceDetails] = useState({
    address: '',
    city: '',
    country: 'Panama',
    bedrooms: '',
    bathrooms: '',
    max_guests: '',
    cleaning_buffer_hours: '4',
    check_in_time: '15:00',
    check_out_time: '11:00',
  })

  // Photos
  const [photos, setPhotos] = useState<File[]>([])
  const [photoPreviews, setPhotoPreviews] = useState<string[]>([])
  const [primaryPhotoIndex, setPrimaryPhotoIndex] = useState(0)

  useEffect(() => {
    loadEntitlements()
  }, [])

  const loadEntitlements = async () => {
    setIsLoading(true)
    const supabase = createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    const { data: membership } = await supabase
      .from('organization_members')
      .select('organization_id')
      .eq('user_id', user.id)
      .single()

    if (!membership) {
      router.push('/onboarding')
      return
    }

    setOrganizationId(membership.organization_id)

    const { data: subData } = await supabase
      .from('subscriptions')
      .select(`
        entitlements (
          section,
          enabled
        )
      `)
      .eq('organization_id', membership.organization_id)
      .single()

    if (subData?.entitlements) {
      const enabled = subData.entitlements
        .filter((e: any) => e.enabled)
        .map((e: any) => e.section)
      setEntitlements(enabled)
    }

    setIsLoading(false)
  }

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    const newPhotos = [...photos, ...files].slice(0, 10) // Max 10 photos
    setPhotos(newPhotos)

    // Generate previews
    newPhotos.forEach((file, index) => {
      if (!photoPreviews[index]) {
        const reader = new FileReader()
        reader.onloadend = () => {
          setPhotoPreviews(prev => {
            const updated = [...prev]
            updated[index] = reader.result as string
            return updated
          })
        }
        reader.readAsDataURL(file)
      }
    })
  }

  const removePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index))
    setPhotoPreviews(photoPreviews.filter((_, i) => i !== index))
    if (primaryPhotoIndex === index) {
      setPrimaryPhotoIndex(0)
    } else if (primaryPhotoIndex > index) {
      setPrimaryPhotoIndex(primaryPhotoIndex - 1)
    }
  }

  const handleSubmit = async () => {
    if (!selectedSection || !organizationId) return
    
    setIsSaving(true)
    setError(null)

    try {
      const supabase = createClient()

      // Create asset
      const { data: asset, error: assetError } = await supabase
        .from('assets')
        .insert({
          organization_id: organizationId,
          name: basicInfo.name,
          description: basicInfo.description || null,
          section: selectedSection,
          is_active: basicInfo.is_active,
        })
        .select()
        .single()

      if (assetError) throw assetError

      // Create section-specific details
      if (selectedSection === 'planes' || selectedSection === 'helicopters') {
        const { error: detailsError } = await supabase
          .from('aircraft_details')
          .insert({
            asset_id: asset.id,
            registration: aircraftDetails.registration || null,
            manufacturer: aircraftDetails.manufacturer || null,
            model: aircraftDetails.model || null,
            year: aircraftDetails.year ? parseInt(aircraftDetails.year) : null,
            cruise_speed_kts: aircraftDetails.cruise_speed_kts ? parseFloat(aircraftDetails.cruise_speed_kts) : null,
            turnaround_minutes: parseInt(aircraftDetails.turnaround_minutes) || 60,
            adjustment_factor: parseFloat(aircraftDetails.adjustment_factor) || 1.15,
            current_location: aircraftDetails.current_location || null,
          })

        if (detailsError) console.error('Aircraft details error:', detailsError)
      }

      if (selectedSection === 'boats') {
        const { error: detailsError } = await supabase
          .from('boat_details')
          .insert({
            asset_id: asset.id,
            registration: boatDetails.registration || null,
            manufacturer: boatDetails.manufacturer || null,
            model: boatDetails.model || null,
            year: boatDetails.year ? parseInt(boatDetails.year) : null,
            length_ft: boatDetails.length_ft ? parseFloat(boatDetails.length_ft) : null,
            turnaround_minutes: parseInt(boatDetails.turnaround_minutes) || 120,
            current_port: boatDetails.current_port || null,
            captain_required: boatDetails.captain_required,
          })

        if (detailsError) console.error('Boat details error:', detailsError)
      }

      if (selectedSection === 'residences') {
        const { error: detailsError } = await supabase
          .from('residence_details')
          .insert({
            asset_id: asset.id,
            address: residenceDetails.address || null,
            city: residenceDetails.city || null,
            country: residenceDetails.country || 'Panama',
            bedrooms: residenceDetails.bedrooms ? parseInt(residenceDetails.bedrooms) : null,
            bathrooms: residenceDetails.bathrooms ? parseFloat(residenceDetails.bathrooms) : null,
            max_guests: residenceDetails.max_guests ? parseInt(residenceDetails.max_guests) : null,
            cleaning_buffer_hours: parseInt(residenceDetails.cleaning_buffer_hours) || 4,
            check_in_time: residenceDetails.check_in_time || '15:00',
            check_out_time: residenceDetails.check_out_time || '11:00',
          })

        if (detailsError) console.error('Residence details error:', detailsError)
      }

      // Upload photos
      for (let i = 0; i < photos.length; i++) {
        const photo = photos[i]
        const fileExt = photo.name.split('.').pop()
        const fileName = `${asset.id}/${Date.now()}-${i}.${fileExt}`

        const { error: uploadError } = await supabase.storage
          .from('asset-photos')
          .upload(fileName, photo)

        if (uploadError) {
          console.error('Photo upload error:', uploadError)
          continue
        }

        const { data: { publicUrl } } = supabase.storage
          .from('asset-photos')
          .getPublicUrl(fileName)

        await supabase
          .from('asset_photos')
          .insert({
            asset_id: asset.id,
            url: publicUrl,
            is_primary: i === primaryPhotoIndex,
          })
      }

      router.push('/dashboard/assets')
    } catch (err: any) {
      console.error('Save error:', err)
      setError(err.message || 'Failed to save asset')
    } finally {
      setIsSaving(false)
    }
  }

  const availableSections = SECTIONS.filter(s => entitlements.includes(s.id))

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-gold-400 animate-spin" />
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          href="/dashboard/assets"
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Assets
        </Link>
        <h1 className="font-display text-2xl font-medium text-stone-50">
          Add New Asset
        </h1>
      </div>

      {/* Progress steps */}
      <div className="flex items-center gap-4 mb-8">
        {['section', 'details', 'photos'].map((s, i) => (
          <div key={s} className="flex items-center">
            <div className={`
              w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
              ${step === s 
                ? 'bg-gold-400 text-navy-950' 
                : ['section', 'details', 'photos'].indexOf(step) > i
                ? 'bg-green-500 text-white'
                : 'bg-navy-800 text-stone-500'
              }
            `}>
              {['section', 'details', 'photos'].indexOf(step) > i ? (
                <Check className="w-4 h-4" />
              ) : (
                i + 1
              )}
            </div>
            {i < 2 && (
              <div className={`w-12 h-0.5 mx-2 ${
                ['section', 'details', 'photos'].indexOf(step) > i
                  ? 'bg-green-500'
                  : 'bg-navy-800'
              }`} />
            )}
          </div>
        ))}
      </div>

      {/* Step 1: Select Section */}
      {step === 'section' && (
        <div className="card p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Select Asset Type
          </h2>
          <div className="space-y-3">
            {availableSections.map((section) => {
              const Icon = section.icon
              const isSelected = selectedSection === section.id
              return (
                <button
                  key={section.id}
                  onClick={() => setSelectedSection(section.id)}
                  className={`
                    w-full p-4 rounded-xl border text-left transition-all
                    ${isSelected 
                      ? 'bg-gold-400/10 border-gold-400/50' 
                      : 'bg-navy-800/50 border-navy-700/50 hover:border-navy-600'
                    }
                  `}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      isSelected ? 'bg-gold-400/20' : 'bg-navy-700/50'
                    }`}>
                      <Icon className={`w-6 h-6 ${isSelected ? 'text-gold-400' : 'text-stone-400'}`} />
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${isSelected ? 'text-stone-50' : 'text-stone-200'}`}>
                        {section.name}
                      </p>
                      <p className="text-sm text-stone-500">{section.description}</p>
                    </div>
                    <div className={`
                      w-6 h-6 rounded-full border-2 flex items-center justify-center
                      ${isSelected ? 'bg-gold-400 border-gold-400' : 'border-stone-600'}
                    `}>
                      {isSelected && <Check className="w-4 h-4 text-navy-950" />}
                    </div>
                  </div>
                </button>
              )
            })}
          </div>

          <div className="flex justify-end mt-6">
            <button
              onClick={() => setStep('details')}
              disabled={!selectedSection}
              className="btn-primary"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Details */}
      {step === 'details' && (
        <div className="card p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-6">
            Asset Details
          </h2>

          <div className="space-y-6">
            {/* Basic Info */}
            <div className="space-y-4">
              <div>
                <label className="input-label">Asset Name *</label>
                <input
                  type="text"
                  value={basicInfo.name}
                  onChange={(e) => setBasicInfo({ ...basicInfo, name: e.target.value })}
                  className="input"
                  placeholder="e.g., Gulfstream G550 or Beach House"
                />
              </div>

              <div>
                <label className="input-label">Description</label>
                <textarea
                  value={basicInfo.description}
                  onChange={(e) => setBasicInfo({ ...basicInfo, description: e.target.value })}
                  className="input min-h-[100px]"
                  placeholder="Brief description of the asset..."
                />
              </div>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={basicInfo.is_active}
                  onChange={(e) => setBasicInfo({ ...basicInfo, is_active: e.target.checked })}
                  className="w-5 h-5 rounded border-navy-600 bg-navy-800 text-gold-400 focus:ring-gold-400"
                />
                <span className="text-stone-300">Asset is active and available for booking</span>
              </label>
            </div>

            {/* Aircraft Details */}
            {(selectedSection === 'planes' || selectedSection === 'helicopters') && (
              <div className="pt-6 border-t border-navy-800">
                <h3 className="text-sm font-medium text-gold-400 uppercase tracking-wider mb-4">
                  Aircraft Details
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="input-label">Registration / Tail #</label>
                    <input
                      type="text"
                      value={aircraftDetails.registration}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, registration: e.target.value })}
                      className="input"
                      placeholder="N12345"
                    />
                  </div>
                  <div>
                    <label className="input-label">Current Location</label>
                    <input
                      type="text"
                      value={aircraftDetails.current_location}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, current_location: e.target.value })}
                      className="input"
                      placeholder="MPTO"
                    />
                  </div>
                  <div>
                    <label className="input-label">Manufacturer</label>
                    <input
                      type="text"
                      value={aircraftDetails.manufacturer}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, manufacturer: e.target.value })}
                      className="input"
                      placeholder="Gulfstream"
                    />
                  </div>
                  <div>
                    <label className="input-label">Model</label>
                    <input
                      type="text"
                      value={aircraftDetails.model}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, model: e.target.value })}
                      className="input"
                      placeholder="G550"
                    />
                  </div>
                  <div>
                    <label className="input-label">Year</label>
                    <input
                      type="number"
                      value={aircraftDetails.year}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, year: e.target.value })}
                      className="input"
                      placeholder="2020"
                    />
                  </div>
                  <div>
                    <label className="input-label">Cruise Speed (kts)</label>
                    <input
                      type="number"
                      value={aircraftDetails.cruise_speed_kts}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, cruise_speed_kts: e.target.value })}
                      className="input"
                      placeholder="450"
                    />
                  </div>
                  <div>
                    <label className="input-label">Turnaround (minutes)</label>
                    <input
                      type="number"
                      value={aircraftDetails.turnaround_minutes}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, turnaround_minutes: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Adjustment Factor</label>
                    <input
                      type="number"
                      step="0.01"
                      value={aircraftDetails.adjustment_factor}
                      onChange={(e) => setAircraftDetails({ ...aircraftDetails, adjustment_factor: e.target.value })}
                      className="input"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Boat Details */}
            {selectedSection === 'boats' && (
              <div className="pt-6 border-t border-navy-800">
                <h3 className="text-sm font-medium text-gold-400 uppercase tracking-wider mb-4">
                  Boat Details
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="input-label">Registration</label>
                    <input
                      type="text"
                      value={boatDetails.registration}
                      onChange={(e) => setBoatDetails({ ...boatDetails, registration: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Current Port</label>
                    <input
                      type="text"
                      value={boatDetails.current_port}
                      onChange={(e) => setBoatDetails({ ...boatDetails, current_port: e.target.value })}
                      className="input"
                      placeholder="Panama City Marina"
                    />
                  </div>
                  <div>
                    <label className="input-label">Manufacturer</label>
                    <input
                      type="text"
                      value={boatDetails.manufacturer}
                      onChange={(e) => setBoatDetails({ ...boatDetails, manufacturer: e.target.value })}
                      className="input"
                      placeholder="Azimut"
                    />
                  </div>
                  <div>
                    <label className="input-label">Model</label>
                    <input
                      type="text"
                      value={boatDetails.model}
                      onChange={(e) => setBoatDetails({ ...boatDetails, model: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Year</label>
                    <input
                      type="number"
                      value={boatDetails.year}
                      onChange={(e) => setBoatDetails({ ...boatDetails, year: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Length (ft)</label>
                    <input
                      type="number"
                      value={boatDetails.length_ft}
                      onChange={(e) => setBoatDetails({ ...boatDetails, length_ft: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Turnaround (minutes)</label>
                    <input
                      type="number"
                      value={boatDetails.turnaround_minutes}
                      onChange={(e) => setBoatDetails({ ...boatDetails, turnaround_minutes: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div className="flex items-end">
                    <label className="flex items-center gap-3 cursor-pointer p-3 bg-navy-800/50 rounded-xl w-full">
                      <input
                        type="checkbox"
                        checked={boatDetails.captain_required}
                        onChange={(e) => setBoatDetails({ ...boatDetails, captain_required: e.target.checked })}
                        className="w-5 h-5 rounded border-navy-600 bg-navy-800 text-gold-400 focus:ring-gold-400"
                      />
                      <span className="text-stone-300">Captain Required</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Residence Details */}
            {selectedSection === 'residences' && (
              <div className="pt-6 border-t border-navy-800">
                <h3 className="text-sm font-medium text-gold-400 uppercase tracking-wider mb-4">
                  Property Details
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="input-label">Address</label>
                    <input
                      type="text"
                      value={residenceDetails.address}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, address: e.target.value })}
                      className="input"
                      placeholder="123 Ocean View Drive"
                    />
                  </div>
                  <div>
                    <label className="input-label">City</label>
                    <input
                      type="text"
                      value={residenceDetails.city}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, city: e.target.value })}
                      className="input"
                      placeholder="Panama City"
                    />
                  </div>
                  <div>
                    <label className="input-label">Country</label>
                    <input
                      type="text"
                      value={residenceDetails.country}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, country: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Bedrooms</label>
                    <input
                      type="number"
                      value={residenceDetails.bedrooms}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, bedrooms: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Bathrooms</label>
                    <input
                      type="number"
                      step="0.5"
                      value={residenceDetails.bathrooms}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, bathrooms: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Max Guests</label>
                    <input
                      type="number"
                      value={residenceDetails.max_guests}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, max_guests: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Cleaning Buffer (hours)</label>
                    <input
                      type="number"
                      value={residenceDetails.cleaning_buffer_hours}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, cleaning_buffer_hours: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Check-in Time</label>
                    <input
                      type="time"
                      value={residenceDetails.check_in_time}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, check_in_time: e.target.value })}
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="input-label">Check-out Time</label>
                    <input
                      type="time"
                      value={residenceDetails.check_out_time}
                      onChange={(e) => setResidenceDetails({ ...residenceDetails, check_out_time: e.target.value })}
                      className="input"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between mt-8">
            <button onClick={() => setStep('section')} className="btn-ghost">
              <ArrowLeft className="w-5 h-5" />
              Back
            </button>
            <button
              onClick={() => setStep('photos')}
              disabled={!basicInfo.name}
              className="btn-primary"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Photos */}
      {step === 'photos' && (
        <div className="card p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-2">
            Add Photos
          </h2>
          <p className="text-stone-400 text-sm mb-6">
            Upload up to 10 photos. Click on a photo to set it as primary.
          </p>

          {/* Upload area */}
          <label className="block border-2 border-dashed border-navy-700 rounded-xl p-8 text-center cursor-pointer hover:border-gold-400/50 transition-colors mb-6">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <Upload className="w-10 h-10 text-stone-500 mx-auto mb-3" />
            <p className="text-stone-300 font-medium">Click to upload photos</p>
            <p className="text-stone-500 text-sm">PNG, JPG up to 10MB each</p>
          </label>

          {/* Photo previews */}
          {photoPreviews.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
              {photoPreviews.map((preview, index) => (
                <div 
                  key={index}
                  onClick={() => setPrimaryPhotoIndex(index)}
                  className={`
                    relative aspect-square rounded-xl overflow-hidden cursor-pointer
                    ${primaryPhotoIndex === index ? 'ring-2 ring-gold-400' : ''}
                  `}
                >
                  <img
                    src={preview}
                    alt={`Photo ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {primaryPhotoIndex === index && (
                    <div className="absolute top-2 left-2 px-2 py-1 bg-gold-400 text-navy-950 text-xs font-medium rounded">
                      Primary
                    </div>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      removePhoto(index)
                    }}
                    className="absolute top-2 right-2 p-1 bg-black/50 rounded-lg text-white hover:bg-black/70 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg mb-6">
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          <div className="flex justify-between">
            <button onClick={() => setStep('details')} className="btn-ghost">
              <ArrowLeft className="w-5 h-5" />
              Back
            </button>
            <button
              onClick={handleSubmit}
              disabled={isSaving}
              className="btn-primary"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  Save Asset
                  <Check className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
