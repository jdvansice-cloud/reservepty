'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  Edit,
  Trash2,
  Plane,
  Ship,
  Home,
  MapPin,
  Calendar,
  Users,
  Clock,
  Gauge,
  Anchor,
  Bed,
  Bath,
  Loader2,
  ChevronLeft,
  ChevronRight
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const SECTION_CONFIG: Record<string, { label: string; icon: any; color: string; bg: string }> = {
  planes: { label: 'Plane', icon: Plane, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  helicopters: { label: 'Helicopter', icon: Plane, color: 'text-purple-400', bg: 'bg-purple-400/10' },
  residences: { label: 'Residence', icon: Home, color: 'text-green-400', bg: 'bg-green-400/10' },
  boats: { label: 'Boat', icon: Ship, color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
}

export default function AssetDetailClient() {
  const params = useParams()
  const router = useRouter()
  const [asset, setAsset] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [deleteModal, setDeleteModal] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0)

  useEffect(() => {
    loadAsset()
  }, [params.id])

  const loadAsset = async () => {
    const supabase = createClient()
    
    const { data, error } = await supabase
      .from('assets')
      .select(`
        *,
        asset_photos (
          id,
          url,
          is_primary
        ),
        aircraft_details (*),
        boat_details (*),
        residence_details (*)
      `)
      .eq('id', params.id)
      .single()

    if (error || !data) {
      router.push('/dashboard/assets')
      return
    }

    // Sort photos to put primary first
    if (data.asset_photos) {
      data.asset_photos.sort((a: any, b: any) => (b.is_primary ? 1 : 0) - (a.is_primary ? 1 : 0))
    }

    setAsset(data)
    setIsLoading(false)
  }

  const handleDelete = async () => {
    setIsDeleting(true)
    const supabase = createClient()

    const { error } = await supabase
      .from('assets')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', params.id)

    if (!error) {
      router.push('/dashboard/assets')
    }
    setIsDeleting(false)
  }

  const nextPhoto = () => {
    if (asset?.asset_photos?.length > 1) {
      setCurrentPhotoIndex((prev) => (prev + 1) % asset.asset_photos.length)
    }
  }

  const prevPhoto = () => {
    if (asset?.asset_photos?.length > 1) {
      setCurrentPhotoIndex((prev) => (prev - 1 + asset.asset_photos.length) % asset.asset_photos.length)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-gold-400 animate-spin" />
      </div>
    )
  }

  if (!asset) return null

  const config = SECTION_CONFIG[asset.section]
  const Icon = config?.icon || Plane
  const details = asset.aircraft_details?.[0] || asset.boat_details?.[0] || asset.residence_details?.[0]
  const photos = asset.asset_photos || []

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <Link
          href="/dashboard/assets"
          className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-200"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Assets
        </Link>
        <div className="flex items-center gap-2">
          <Link
            href={`/dashboard/assets/${params.id}/edit`}
            className="btn-secondary"
          >
            <Edit className="w-4 h-4" />
            Edit
          </Link>
          <button
            onClick={() => setDeleteModal(true)}
            className="px-4 py-2 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors font-medium flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            Delete
          </button>
        </div>
      </div>

      {/* Photo gallery */}
      <div className="relative h-80 md:h-96 bg-navy-800 rounded-2xl overflow-hidden mb-6">
        {photos.length > 0 ? (
          <>
            <img
              src={photos[currentPhotoIndex]?.url}
              alt={asset.name}
              className="w-full h-full object-cover"
            />
            {photos.length > 1 && (
              <>
                <button
                  onClick={prevPhoto}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 rounded-full text-white hover:bg-black/70 transition-colors"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={nextPhoto}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 rounded-full text-white hover:bg-black/70 transition-colors"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {photos.map((_: any, i: number) => (
                    <button
                      key={i}
                      onClick={() => setCurrentPhotoIndex(i)}
                      className={`w-2 h-2 rounded-full transition-colors ${
                        i === currentPhotoIndex ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Icon className={`w-24 h-24 ${config?.color} opacity-20`} />
          </div>
        )}
        
        {/* Section badge */}
        <div className={`absolute top-4 left-4 px-3 py-1.5 rounded-lg text-sm font-medium ${config?.bg} ${config?.color} backdrop-blur-sm`}>
          {config?.label}
        </div>

        {/* Status badge */}
        {!asset.is_active && (
          <div className="absolute top-4 right-4 px-3 py-1.5 rounded-lg text-sm font-medium bg-stone-500/30 text-stone-300 backdrop-blur-sm">
            Inactive
          </div>
        )}
      </div>

      {/* Thumbnail strip */}
      {photos.length > 1 && (
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {photos.map((photo: any, i: number) => (
            <button
              key={photo.id}
              onClick={() => setCurrentPhotoIndex(i)}
              className={`shrink-0 w-20 h-20 rounded-lg overflow-hidden ${
                i === currentPhotoIndex ? 'ring-2 ring-gold-400' : 'opacity-60 hover:opacity-100'
              }`}
            >
              <img src={photo.url} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}

      {/* Title and description */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-medium text-stone-50 mb-2">
          {asset.name}
        </h1>
        {asset.description && (
          <p className="text-stone-400 text-lg">{asset.description}</p>
        )}
      </div>

      {/* Details grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Aircraft details */}
        {(asset.section === 'planes' || asset.section === 'helicopters') && details && (
          <div className="card p-6">
            <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
              Aircraft Information
            </h2>
            <div className="space-y-4">
              {details.registration && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Plane className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Registration</p>
                    <p className="text-stone-200 font-medium">{details.registration}</p>
                  </div>
                </div>
              )}
              {(details.manufacturer || details.model) && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Plane className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Make / Model</p>
                    <p className="text-stone-200 font-medium">
                      {[details.manufacturer, details.model].filter(Boolean).join(' ')}
                      {details.year && ` (${details.year})`}
                    </p>
                  </div>
                </div>
              )}
              {details.current_location && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Current Location</p>
                    <p className="text-stone-200 font-medium">{details.current_location}</p>
                  </div>
                </div>
              )}
              {details.cruise_speed_kts && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Gauge className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Cruise Speed</p>
                    <p className="text-stone-200 font-medium">{details.cruise_speed_kts} kts</p>
                  </div>
                </div>
              )}
              {details.turnaround_minutes && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Turnaround Time</p>
                    <p className="text-stone-200 font-medium">{details.turnaround_minutes} minutes</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Boat details */}
        {asset.section === 'boats' && details && (
          <div className="card p-6">
            <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
              Vessel Information
            </h2>
            <div className="space-y-4">
              {details.registration && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Ship className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Registration</p>
                    <p className="text-stone-200 font-medium">{details.registration}</p>
                  </div>
                </div>
              )}
              {(details.manufacturer || details.model) && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Ship className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Make / Model</p>
                    <p className="text-stone-200 font-medium">
                      {[details.manufacturer, details.model].filter(Boolean).join(' ')}
                      {details.year && ` (${details.year})`}
                    </p>
                  </div>
                </div>
              )}
              {details.length_ft && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Ship className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Length</p>
                    <p className="text-stone-200 font-medium">{details.length_ft} ft</p>
                  </div>
                </div>
              )}
              {details.current_port && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Anchor className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Current Port</p>
                    <p className="text-stone-200 font-medium">{details.current_port}</p>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                  <Users className="w-5 h-5 text-stone-400" />
                </div>
                <div>
                  <p className="text-sm text-stone-500">Captain Required</p>
                  <p className="text-stone-200 font-medium">{details.captain_required ? 'Yes' : 'No'}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Residence details */}
        {asset.section === 'residences' && details && (
          <div className="card p-6">
            <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
              Property Information
            </h2>
            <div className="space-y-4">
              {(details.address || details.city) && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Location</p>
                    <p className="text-stone-200 font-medium">
                      {[details.address, details.city, details.country].filter(Boolean).join(', ')}
                    </p>
                  </div>
                </div>
              )}
              {details.bedrooms && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Bed className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Bedrooms</p>
                    <p className="text-stone-200 font-medium">{details.bedrooms}</p>
                  </div>
                </div>
              )}
              {details.bathrooms && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Bath className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Bathrooms</p>
                    <p className="text-stone-200 font-medium">{details.bathrooms}</p>
                  </div>
                </div>
              )}
              {details.max_guests && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Users className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Max Guests</p>
                    <p className="text-stone-200 font-medium">{details.max_guests}</p>
                  </div>
                </div>
              )}
              {(details.check_in_time || details.check_out_time) && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-stone-400" />
                  </div>
                  <div>
                    <p className="text-sm text-stone-500">Check-in / Check-out</p>
                    <p className="text-stone-200 font-medium">
                      {details.check_in_time} / {details.check_out_time}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Booking stats placeholder */}
        <div className="card p-6">
          <h2 className="font-display text-lg font-medium text-stone-50 mb-4">
            Booking Statistics
          </h2>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-stone-400" />
              </div>
              <div>
                <p className="text-sm text-stone-500">Total Bookings</p>
                <p className="text-stone-200 font-medium">0</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-navy-800 flex items-center justify-center">
                <Clock className="w-5 h-5 text-stone-400" />
              </div>
              <div>
                <p className="text-sm text-stone-500">Upcoming Bookings</p>
                <p className="text-stone-200 font-medium">0</p>
              </div>
            </div>
          </div>
          <div className="mt-6 pt-4 border-t border-navy-800">
            <Link
              href={`/dashboard/calendar?asset=${params.id}`}
              className="btn-secondary w-full justify-center"
            >
              <Calendar className="w-4 h-4" />
              View Calendar
            </Link>
          </div>
        </div>
      </div>

      {/* Delete confirmation modal */}
      {deleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card p-6 max-w-md w-full">
            <h3 className="font-display text-xl font-medium text-stone-50 mb-2">
              Delete Asset
            </h3>
            <p className="text-stone-400 mb-6">
              Are you sure you want to delete "{asset.name}"? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteModal(false)}
                className="btn-ghost flex-1"
                disabled={isDeleting}
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={isDeleting}
                className="flex-1 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors font-medium"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
