'use client'

import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Loader2 } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

function AuthCallbackHandler() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const handleAuthCallback = async () => {
      const supabase = createClient()
      
      // Get the code from URL hash (Supabase uses hash-based auth)
      const hashParams = new URLSearchParams(window.location.hash.substring(1))
      const accessToken = hashParams.get('access_token')
      const refreshToken = hashParams.get('refresh_token')
      const type = hashParams.get('type')
      
      // Also check query params
      const code = searchParams.get('code')
      const queryType = searchParams.get('type')

      try {
        if (accessToken && refreshToken) {
          // Set session from hash params
          const { error: sessionError } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken,
          })

          if (sessionError) {
            setError(sessionError.message)
            return
          }

          // Handle password recovery
          if (type === 'recovery') {
            router.push('/update-password')
            return
          }
        } else if (code) {
          // Exchange code for session
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code)
          
          if (exchangeError) {
            setError(exchangeError.message)
            return
          }

          // Handle password recovery
          if (queryType === 'recovery') {
            router.push('/update-password')
            return
          }
        }

        // Check if user has an organization
        const { data: { user } } = await supabase.auth.getUser()
        
        if (user) {
          // First check if user is a platform admin
          const { data: adminData } = await supabase
            .from('platform_admins')
            .select('id')
            .eq('user_id', user.id)
            .eq('is_active', true)
            .single()
          
          if (adminData) {
            // Platform admin - redirect to admin portal
            router.push('/admin')
            return
          }

          // Regular user - check for organization membership
          const { data: membership } = await supabase
            .from('organization_members')
            .select('organization_id')
            .eq('user_id', user.id)
            .single()
          
          if (!membership) {
            router.push('/onboarding')
            return
          }
          
          router.push('/dashboard')
        } else {
          router.push('/login')
        }
      } catch (err) {
        console.error('Auth callback error:', err)
        setError('Authentication failed. Please try again.')
      }
    }

    handleAuthCallback()
  }, [router, searchParams])

  if (error) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center p-4">
        <div className="card p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6">
            <span className="text-2xl text-red-400">!</span>
          </div>
          <h1 className="font-display text-xl font-medium text-stone-50 mb-2">
            Authentication Error
          </h1>
          <p className="text-stone-400 mb-6">{error}</p>
          <button 
            onClick={() => router.push('/login')}
            className="btn-primary w-full"
          >
            Back to Login
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-navy-950 flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="w-10 h-10 text-gold-400 animate-spin mx-auto mb-4" />
        <p className="text-stone-400">Completing sign in...</p>
      </div>
    </div>
  )
}

export default function AuthCallbackPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-gold-400 animate-spin mx-auto mb-4" />
          <p className="text-stone-400">Loading...</p>
        </div>
      </div>
    }>
      <AuthCallbackHandler />
    </Suspense>
  )
}
