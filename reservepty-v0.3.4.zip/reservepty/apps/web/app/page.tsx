import Link from 'next/link'
import { 
  Plane, 
  Building2, 
  Ship, 
  Calendar, 
  Users, 
  Shield, 
  ChevronRight,
  Check,
  ArrowRight,
  Sparkles
} from 'lucide-react'

export default function LandingPage() {
  return (
    <main className="relative overflow-hidden">
      {/* Navigation */}
      <Navigation />
      
      {/* Hero Section */}
      <HeroSection />
      
      {/* Trusted By / Social Proof */}
      <TrustBar />
      
      {/* Features Section */}
      <FeaturesSection />
      
      {/* How It Works */}
      <HowItWorksSection />
      
      {/* Pricing Section */}
      <PricingSection />
      
      {/* CTA Section */}
      <CTASection />
      
      {/* Footer */}
      <Footer />
    </main>
  )
}

function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-navy-950/80 backdrop-blur-xl border-b border-navy-800/50">
      <div className="container-luxury">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-gold-glow transition-shadow duration-300 group-hover:shadow-lg">
              <Sparkles className="w-5 h-5 text-navy-950" />
            </div>
            <span className="font-display text-2xl font-semibold tracking-tight text-stone-50">
              Reserve<span className="text-gold-400">PTY</span>
            </span>
          </Link>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-stone-400 hover:text-stone-100 transition-colors">
              Features
            </Link>
            <Link href="#pricing" className="text-stone-400 hover:text-stone-100 transition-colors">
              Pricing
            </Link>
            <Link href="#contact" className="text-stone-400 hover:text-stone-100 transition-colors">
              Contact
            </Link>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex items-center gap-4">
            <Link 
              href="/login" 
              className="hidden sm:block text-stone-300 hover:text-stone-100 transition-colors"
            >
              Sign In
            </Link>
            <Link href="/signup" className="btn-primary">
              Get Started
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}

function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center pt-20">
      {/* Background elements */}
      <div className="absolute inset-0 grid-pattern opacity-50" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold-400/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-navy-600/20 rounded-full blur-3xl" />
      
      <div className="container-luxury relative z-10 py-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-navy-800/50 border border-navy-700/50 rounded-full mb-8 animate-fade-in">
            <span className="gold-dot" />
            <span className="text-sm text-stone-400">Trusted by leading family offices</span>
          </div>
          
          {/* Headline */}
          <h1 className="text-display-lg md:text-display-xl font-display font-medium text-balance mb-6 animate-fade-in-up opacity-0 delay-100">
            One Platform for All Your
            <span className="block text-gradient-gold">Luxury Assets</span>
          </h1>
          
          {/* Subheadline */}
          <p className="text-xl md:text-2xl text-stone-400 max-w-2xl mx-auto mb-12 animate-fade-in-up opacity-0 delay-200">
            Planes. Helicopters. Residences. Boats. Manage bookings, track usage, and coordinate with your team—all in one elegant platform.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up opacity-0 delay-300">
            <Link href="/signup" className="btn-primary text-base px-8 py-4">
              Start Free Trial
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="#demo" className="btn-ghost text-base px-8 py-4">
              Watch Demo
            </Link>
          </div>
          
          {/* Asset Icons */}
          <div className="flex items-center justify-center gap-8 mt-16 animate-fade-in opacity-0 delay-500">
            {[
              { icon: Plane, label: 'Aviation' },
              { icon: Building2, label: 'Residences' },
              { icon: Ship, label: 'Boats' },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-2 text-stone-500">
                <div className="w-14 h-14 rounded-2xl bg-navy-800/50 border border-navy-700/50 flex items-center justify-center">
                  <Icon className="w-6 h-6" />
                </div>
                <span className="text-xs">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-float">
        <div className="w-6 h-10 rounded-full border-2 border-stone-600 flex items-start justify-center p-2">
          <div className="w-1.5 h-2.5 rounded-full bg-gold-400 animate-pulse" />
        </div>
      </div>
    </section>
  )
}

function TrustBar() {
  return (
    <section className="py-12 border-y border-navy-800/50 bg-navy-900/30">
      <div className="container-luxury">
        <p className="text-center text-sm text-stone-500 mb-8">
          Trusted by discerning organizations across Central America & the Caribbean
        </p>
        <div className="flex items-center justify-center gap-12 flex-wrap opacity-50">
          {/* Placeholder logos - would be replaced with actual client logos */}
          {['Family Office A', 'Aviation Group', 'Private Holdings', 'Luxury Fleet'].map((name) => (
            <div key={name} className="text-stone-400 font-display text-lg tracking-wide">
              {name}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function FeaturesSection() {
  const features = [
    {
      icon: Calendar,
      title: 'Unified Calendar',
      description: 'See all your assets in one beautiful calendar. Filter by type, location, or member. Never double-book again.',
    },
    {
      icon: Users,
      title: 'Member Tiers & Priorities',
      description: 'Set booking rules by tier. Parents get priority over siblings. Automatic conflict resolution.',
    },
    {
      icon: Plane,
      title: 'Aviation Intelligence',
      description: 'Auto-calculate flight times, enforce turnaround windows, track maintenance schedules.',
    },
    {
      icon: Shield,
      title: 'Enterprise Security',
      description: 'Bank-grade encryption, role-based access, complete audit trails. Your data stays yours.',
    },
  ]

  return (
    <section id="features" className="section relative">
      <div className="absolute inset-0 bg-gradient-to-b from-navy-950 via-navy-900/50 to-navy-950" />
      
      <div className="container-luxury relative z-10">
        <div className="section-header">
          <span className="badge-gold mb-4">Features</span>
          <h2 className="text-display-sm md:text-display-md mb-4">
            Everything You Need,
            <span className="block text-gradient-gold">Nothing You Don't</span>
          </h2>
          <p className="text-lg text-stone-400">
            Purpose-built for families and organizations managing multiple luxury assets.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feature, i) => (
            <div 
              key={feature.title}
              className="card-hover p-8 group"
            >
              <div className="w-12 h-12 rounded-xl bg-gold-400/10 border border-gold-400/20 flex items-center justify-center mb-6 group-hover:bg-gold-400/20 transition-colors">
                <feature.icon className="w-6 h-6 text-gold-400" />
              </div>
              <h3 className="text-xl font-display font-medium mb-3">{feature.title}</h3>
              <p className="text-stone-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function HowItWorksSection() {
  const steps = [
    {
      number: '01',
      title: 'Create Your Organization',
      description: 'Set up your company profile, add your RUC, and upload your logo.',
    },
    {
      number: '02',
      title: 'Add Your Assets',
      description: 'Register planes, helicopters, homes, and boats. Add photos and details.',
    },
    {
      number: '03',
      title: 'Invite Your Team',
      description: 'Add family members or staff. Assign roles and set booking permissions.',
    },
    {
      number: '04',
      title: 'Start Booking',
      description: 'Members book through the unified calendar. Admins approve and manage.',
    },
  ]

  return (
    <section className="section">
      <div className="container-luxury">
        <div className="section-header">
          <span className="badge-gold mb-4">How It Works</span>
          <h2 className="text-display-sm md:text-display-md mb-4">
            Up and Running in Minutes
          </h2>
          <p className="text-lg text-stone-400">
            Simple setup. Powerful capabilities.
          </p>
        </div>
        
        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, i) => (
            <div key={step.number} className="relative">
              {/* Connector line */}
              {i < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 left-[60%] w-full h-px bg-gradient-to-r from-gold-400/30 to-transparent" />
              )}
              
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-navy-800 border border-navy-700 mb-6">
                  <span className="font-display text-2xl text-gold-400">{step.number}</span>
                </div>
                <h3 className="text-lg font-display font-medium mb-2">{step.title}</h3>
                <p className="text-stone-400 text-sm">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function PricingSection() {
  const sections = [
    { name: 'Aviation — Planes', price: 99 },
    { name: 'Aviation — Helicopters', price: 99 },
    { name: 'Residences & Spaces', price: 79 },
    { name: 'Boats & Yachts', price: 79 },
  ]

  const seatTiers = [
    { seats: 5, price: 0 },
    { seats: 10, price: 49 },
    { seats: 25, price: 99 },
    { seats: 50, price: 199 },
    { seats: 100, price: 349 },
  ]

  return (
    <section id="pricing" className="section relative">
      <div className="absolute inset-0 bg-gradient-to-b from-navy-950 via-navy-900/30 to-navy-950" />
      
      <div className="container-luxury relative z-10">
        <div className="section-header">
          <span className="badge-gold mb-4">Pricing</span>
          <h2 className="text-display-sm md:text-display-md mb-4">
            Pay Only for What You Use
          </h2>
          <p className="text-lg text-stone-400">
            Modular pricing. Enable only the sections you need.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Sections Card */}
          <div className="card p-8">
            <h3 className="text-xl font-display font-medium mb-2">Asset Sections</h3>
            <p className="text-stone-400 text-sm mb-6">Enable the modules you need</p>
            
            <div className="space-y-4">
              {sections.map((section) => (
                <div 
                  key={section.name}
                  className="flex items-center justify-between p-4 bg-navy-800/50 rounded-xl border border-navy-700/50"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded border-2 border-gold-400/50" />
                    <span className="text-stone-200">{section.name}</span>
                  </div>
                  <span className="text-gold-400 font-medium">${section.price}<span className="text-stone-500 text-sm">/mo</span></span>
                </div>
              ))}
            </div>
            
            <p className="text-xs text-stone-500 mt-4">
              * Save 20% with yearly billing
            </p>
          </div>
          
          {/* Seats Card */}
          <div className="card p-8">
            <h3 className="text-xl font-display font-medium mb-2">Team Seats</h3>
            <p className="text-stone-400 text-sm mb-6">Scale as your team grows</p>
            
            <div className="space-y-4">
              {seatTiers.map((tier) => (
                <div 
                  key={tier.seats}
                  className="flex items-center justify-between p-4 bg-navy-800/50 rounded-xl border border-navy-700/50"
                >
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-stone-400" />
                    <span className="text-stone-200">Up to {tier.seats} users</span>
                  </div>
                  <span className="text-gold-400 font-medium">
                    {tier.price === 0 ? 'Included' : `+$${tier.price}/mo`}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Example calculation */}
        <div className="max-w-2xl mx-auto mt-12 p-6 bg-navy-800/30 rounded-2xl border border-navy-700/50 text-center">
          <p className="text-stone-400 mb-2">Example: Planes + Residences + 10 users</p>
          <p className="text-3xl font-display text-gold-400">$227<span className="text-lg text-stone-500">/month</span></p>
        </div>
      </div>
    </section>
  )
}

function CTASection() {
  return (
    <section className="section">
      <div className="container-luxury">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy-800 to-navy-900 border border-navy-700/50 p-12 md:p-20">
          {/* Background decoration */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-gold-400/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-navy-600/20 rounded-full blur-3xl" />
          
          <div className="relative z-10 max-w-2xl mx-auto text-center">
            <h2 className="text-display-sm md:text-display-md font-display mb-6">
              Ready to Simplify Your
              <span className="block text-gradient-gold">Asset Management?</span>
            </h2>
            <p className="text-lg text-stone-400 mb-8">
              Join forward-thinking families and organizations who trust ReservePTY to manage their most valuable assets.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup" className="btn-primary text-base px-8 py-4">
                Start 14-Day Free Trial
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link href="/contact" className="btn-outline text-base px-8 py-4">
                Talk to Sales
              </Link>
            </div>
            <p className="text-sm text-stone-500 mt-6">
              No credit card required • Setup in minutes • Cancel anytime
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="py-12 border-t border-navy-800/50">
      <div className="container-luxury">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-navy-950" />
            </div>
            <span className="font-display text-xl font-medium text-stone-300">
              Reserve<span className="text-gold-400">PTY</span>
            </span>
          </div>
          
          {/* Links */}
          <div className="flex items-center gap-6 text-sm text-stone-500">
            <Link href="/privacy" className="hover:text-stone-300 transition-colors">
              Privacy
            </Link>
            <Link href="/terms" className="hover:text-stone-300 transition-colors">
              Terms
            </Link>
            <Link href="/contact" className="hover:text-stone-300 transition-colors">
              Contact
            </Link>
          </div>
          
          {/* Copyright */}
          <p className="text-sm text-stone-600">
            © {new Date().getFullYear()} ReservePTY. Panama.
          </p>
        </div>
      </div>
    </footer>
  )
}
