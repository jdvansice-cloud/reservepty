import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Primary - Deep Navy (Dominant)
        navy: {
          950: '#050a14',
          900: '#0a1628',
          800: '#0f2240',
          700: '#1a365d',
          600: '#234e82',
          500: '#2d6aa8',
          400: '#4a8ac7',
          300: '#7aade0',
          200: '#a8cef0',
          100: '#d4e7f8',
          50: '#eef5fc',
        },
        // Accent - Champagne Gold (#c8b273 base)
        gold: {
          600: '#9a8654',
          500: '#b49b63',
          400: '#c8b273',
          300: '#d4c48f',
          200: '#e2d4ab',
          100: '#f0e6cd',
          50: '#f9f5eb',
        },
        // Neutral - Warm Stone
        stone: {
          950: '#1c1917',
          900: '#292524',
          800: '#44403c',
          700: '#57534e',
          600: '#78716c',
          500: '#a8a29e',
          400: '#d6d3d1',
          300: '#e7e5e4',
          200: '#f5f5f4',
          100: '#fafaf9',
          50: '#fdfcfb',
        },
        // Status Colors
        success: {
          DEFAULT: '#2d5a27',
          light: '#4a8b42',
        },
        warning: {
          DEFAULT: '#b8860b',
          light: '#d4a017',
        },
        error: {
          DEFAULT: '#8b0000',
          light: '#b22222',
        },
      },
      fontFamily: {
        // Display - Didot LT Pro (luxury serif)
        display: ['Didot LT Pro', 'Didot', 'Playfair Display', 'Bodoni Moda', 'Georgia', 'serif'],
        // Body - Clean Sans
        body: ['DM Sans', 'system-ui', 'sans-serif'],
        // Mono - For data/codes
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
        'display-xl': ['4.5rem', { lineHeight: '1', letterSpacing: '-0.02em' }],
        'display-lg': ['3.75rem', { lineHeight: '1', letterSpacing: '-0.02em' }],
        'display-md': ['3rem', { lineHeight: '1.1', letterSpacing: '-0.01em' }],
        'display-sm': ['2.25rem', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '112': '28rem',
        '128': '32rem',
        '144': '36rem',
      },
      borderRadius: {
        '4xl': '2rem',
        '5xl': '2.5rem',
      },
      boxShadow: {
        'luxury': '0 4px 20px -2px rgba(10, 22, 40, 0.25)',
        'luxury-lg': '0 10px 40px -4px rgba(10, 22, 40, 0.3)',
        'luxury-xl': '0 20px 60px -8px rgba(10, 22, 40, 0.35)',
        'gold-glow': '0 0 30px -5px rgba(200, 178, 115, 0.4)',
        'inner-luxury': 'inset 0 2px 20px 0 rgba(10, 22, 40, 0.1)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-luxury': 'linear-gradient(135deg, var(--tw-gradient-stops))',
        'noise': "url('/noise.svg')",
        'grid-luxury': `linear-gradient(rgba(200, 178, 115, 0.03) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(200, 178, 115, 0.03) 1px, transparent 1px)`,
      },
      backgroundSize: {
        'grid': '60px 60px',
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'fade-in-up': 'fadeInUp 0.6s ease-out forwards',
        'fade-in-down': 'fadeInDown 0.6s ease-out forwards',
        'slide-in-right': 'slideInRight 0.5s ease-out forwards',
        'slide-in-left': 'slideInLeft 0.5s ease-out forwards',
        'scale-in': 'scaleIn 0.4s ease-out forwards',
        'shimmer': 'shimmer 2s linear infinite',
        'float': 'float 6s ease-in-out infinite',
        'pulse-gold': 'pulseGold 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeInDown: {
          '0%': { opacity: '0', transform: 'translateY(-20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideInRight: {
          '0%': { opacity: '0', transform: 'translateX(30px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        slideInLeft: {
          '0%': { opacity: '0', transform: 'translateX(-30px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        pulseGold: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(200, 178, 115, 0.4)' },
          '50%': { boxShadow: '0 0 20px 5px rgba(200, 178, 115, 0.2)' },
        },
      },
      transitionTimingFunction: {
        'luxury': 'cubic-bezier(0.4, 0, 0.2, 1)',
        'bounce-soft': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
      },
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
      },
    },
  },
  plugins: [],
}

export default config
