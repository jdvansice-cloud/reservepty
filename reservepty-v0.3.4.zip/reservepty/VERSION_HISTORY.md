# ReservePTY — Version History

This document tracks all development milestones and changes across conversations.

---

## Version 0.3.3 — Admin Portal Fixes (December 24, 2025)

**Status:** ✅ Complete

### Changes
- [x] Fixed admin login redirect issue (was going to onboarding)
- [x] Admin login now uses window.location for clean redirect
- [x] Auth callback checks for platform admin before redirecting to onboarding
- [x] Customer login redirects platform admins to admin portal
- [x] Added "Create Organization" functionality in admin portal
  - Create organization with owner account
  - Select sections and seat tier
  - Mark as complimentary (no payment required)
  - Automatically creates subscription and entitlements

### Admin Flow
1. Go to `/admin/login`
2. Log in with platform admin credentials
3. Access admin dashboard
4. Create organizations via `/admin/organizations/new`

---

## Version 0.3.2 — Security Updates & Vercel Deployment (December 24, 2025)

**Status:** ✅ Complete

### Changes
- [x] **Next.js Security Patch**: Updated from 14.2.21 to 14.2.29 (fixes security vulnerability)
- [x] **Deployment Platform**: Switched from Netlify to Vercel for better Next.js compatibility
- [x] **Build Config**: Removed static export mode for proper SSR support with dynamic routes
- [x] **eslint-config-next**: Updated to match Next.js version

### Deployment
- Platform: Vercel
- Root Directory: `apps/web`
- Framework: Next.js (auto-detected)

---

## Version 0.2.1 — Font Update (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Changed display font from Cormorant Garamond to Didot LT Pro
- [x] Added @font-face declarations for self-hosted Didot LT Pro
- [x] Added Bodoni Moda (Google Fonts) as fallback
- [x] Created /public/fonts/ directory with setup instructions

### Font Setup
Add Didot LT Pro font files to `/apps/web/public/fonts/`:
- DidotLTPro-Roman.woff2 / .woff
- DidotLTPro-Italic.woff2 / .woff  
- DidotLTPro-Bold.woff2 / .woff

---

## Version 0.3.1 — Platform Admin Panel (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Platform admin database schema (migration 00002)
  - `platform_admins` table with roles (super_admin, admin, support)
  - `platform_activity_logs` for audit trail
  - `complimentary_memberships` for free accounts
  - `platform_settings` for global configuration
- [x] Admin login page at `/admin/login`
- [x] Admin dashboard with KPIs:
  - Total organizations, users, subscriptions
  - Monthly/Annual revenue (MRR/ARR)
  - Trial accounts, complimentary accounts
  - Total assets and reservations
  - Section breakdown (planes, helicopters, residences, boats)
  - Recent signups and admin activity
- [x] Organizations management (`/admin/organizations`)
- [x] Users management (`/admin/users`)
- [x] Complimentary memberships (`/admin/complimentary`)
  - Grant free access to organizations
  - Select sections and seat limits
  - Set expiration dates
  - Revoke access
- [x] Revenue dashboard (`/admin/revenue`)
- [x] Activity logs (`/admin/activity`)
- [x] Platform admins management (`/admin/admins`)
  - Create new admins (super_admin only)
  - Deactivate admins
  - Role-based permissions
- [x] Platform settings (`/admin/settings`)
  - Section pricing
  - Seat tiers
  - Trial period
  - Maintenance mode

### Admin Routes
- `/admin/login` — Admin authentication
- `/admin` — Dashboard with KPIs
- `/admin/organizations` — Manage all organizations
- `/admin/users` — Manage all users
- `/admin/complimentary` — Free membership management
- `/admin/complimentary/new` — Grant complimentary access
- `/admin/revenue` — Revenue metrics
- `/admin/activity` — Activity audit logs
- `/admin/admins` — Platform admin management
- `/admin/admins/new` — Create new admin
- `/admin/settings` — Global platform settings

### Role Permissions
| Role | Permissions |
|------|-------------|
| Super Admin | Full access, can manage other admins |
| Admin | Full access except admin management |
| Support | Read-only access to view data |

---

## Version 0.3.0 — Asset Management (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Assets listing page with grid view
- [x] Search and filter by section
- [x] Add new asset wizard (3 steps)
  - Section selection (planes, helicopters, residences, boats)
  - Asset details with section-specific fields
  - Photo upload with primary selection
- [x] Asset detail view page
  - Photo gallery with navigation
  - Section-specific information display
  - Booking statistics placeholder
- [x] Edit asset page
  - Update all asset information
  - Manage photos (add, delete, set primary)
- [x] Delete asset functionality (soft delete)
- [x] Section-specific detail forms
  - Aircraft: registration, manufacturer, model, speed, turnaround
  - Boats: registration, length, port, captain required
  - Residences: address, bedrooms, bathrooms, check-in/out times

### New Routes
- `/dashboard/assets` — Assets listing
- `/dashboard/assets/new` — Create new asset
- `/dashboard/assets/[id]` — Asset detail view
- `/dashboard/assets/[id]/edit` — Edit asset

---

## Version 0.2.0 — Authentication & Onboarding (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Auth layout with split-screen luxury design
- [x] Sign Up page with password strength indicator
- [x] Login page with error handling
- [x] Password reset flow (request + update)
- [x] Email verification flow
- [x] Auth callback page (client-side, static export compatible)
- [x] Organization onboarding wizard
  - Company info form (RUC + DV validation)
  - Logo upload to Supabase Storage
  - Section selection with pricing
  - Trial subscription creation
- [x] Dashboard layout with sidebar navigation
- [x] Dashboard home with stats and recent activity
- [x] Placeholder pages for Calendar, Assets, Members, Settings
- [x] User session management
- [x] Sign out functionality

### Fixes (v0.2.0-fix)
- [x] Converted auth callback from route handler to client-side page for static export compatibility

### New Routes
- `/signup` — Create account
- `/login` — Sign in
- `/reset-password` — Request password reset
- `/update-password` — Set new password
- `/onboarding` — Organization setup wizard
- `/auth/callback` — OAuth/magic link handler
- `/dashboard` — Main dashboard
- `/dashboard/calendar` — Calendar (placeholder)
- `/dashboard/assets` — Assets (placeholder)
- `/dashboard/members` — Members (placeholder)
- `/dashboard/settings` — Settings (placeholder)

---

## Version 0.1.3 — Gold Color Update (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Updated gold accent color from #d4af37 to #c8b273
- [x] Updated all related shadows, glows, and animations

---

## Version 0.1.2 — Netlify Deploy Fix (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Switched to Next.js static export mode (`output: 'export'`)
- [x] Added `netlify.toml` for proper build configuration
- [x] Changed publish directory from `.next` to `out`
- [x] Removed experimental features causing runtime issues

---

## Version 0.1.1 — Build Fix (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Changed `next.config.ts` to `next.config.mjs` (Next.js 14.2 compatibility)
- [x] Updated Next.js from 14.2.3 to 14.2.28 (security patch)
- [x] Updated eslint-config-next to match

---

## Version 0.1.0 — Foundation (December 24, 2024)

**Status:** ✅ Complete

### Changes
- [x] Project structure initialized (monorepo with apps/packages/supabase)
- [x] Development plan created and approved
- [x] Design system established (luxury minimalism theme)
  - Deep navy (#0a1628) primary
  - Champagne gold (#d4af37) accent
  - Cormorant Garamond + DM Sans typography
- [x] Tailwind configuration with custom design tokens
- [x] Global CSS with utility classes and components
- [x] Next.js 14 app structure
- [x] Supabase database schema (v1)
  - Organizations, Subscriptions, Entitlements
  - Users, Profiles, Organization Members
  - Tiers, Tier Rules, Blackout Windows
  - Assets (with typed details for Aircraft, Boats, Residences)
  - Reservations with section-specific metadata
  - Directories (Airports, Ports)
  - Row Level Security policies
- [x] Landing page with luxury design
  - Navigation
  - Hero section with animations
  - Features section
  - How It Works section
  - Pricing section (modular sections + seats)
  - CTA section
  - Footer
- [x] Utility functions (cn, formatCurrency, haversine distance, etc.)
- [x] Supabase client configuration (browser + server)
- [x] Environment configuration template

### Tech Stack Decisions
- Framework: Next.js 14 (App Router)
- Database: Supabase (PostgreSQL + Auth + Storage)
- Styling: Tailwind CSS + Framer Motion
- State: TanStack Query + Zustand
- Payments: Tilopay (Panama/CAM/CAR focus)
- Hosting: Netlify
- Repository: GitHub

### Design Decisions
- Dark theme primary (luxury feel)
- Minimal use of borders, heavy use of shadows
- Subtle animations (fade-in, stagger reveals)
- Grid pattern background for texture
- Glass morphism cards
- Gold accents for CTAs and highlights

---

## Planned: Version 0.4.0 — Calendar & Bookings

**Status:** 🔲 Not Started

### Planned Changes
- [ ] Unified calendar view (month/week/day)
- [ ] Create reservation flow
- [ ] Asset availability checking
- [ ] Booking approval workflow
- [ ] Conflict detection
- [ ] Turnaround time enforcement

---

## Planned: Version 0.5.0 — Members & Tiers

**Status:** 🔲 Not Started

### Planned Changes
- [ ] Member invitation flow
- [ ] Role management (owner, admin, member)
- [ ] Tier configuration
- [ ] Tier rules (booking limits, lead times, blackouts)
- [ ] Priority-based conflict resolution

---

## Planned: Version 0.6.0 — Subscriptions & Billing

**Status:** 🔲 Not Started

### Planned Changes
- [ ] Tilopay integration
- [ ] Section selection UI
- [ ] Seat tier selection
- [ ] Checkout flow
- [ ] Webhook handlers
- [ ] Subscription management
- [ ] Entitlement enforcement middleware
- [ ] Upgrade/downgrade flow

---

## Planned: Version 0.4.0 — Asset Management

**Status:** 🔲 Not Started

### Planned Changes
- [ ] Asset CRUD operations
- [ ] Asset type forms (planes, helicopters, boats, residences)
- [ ] Photo gallery upload
- [ ] Asset detail pages
- [ ] Asset permissions UI
- [ ] Directory management (airports, ports)

---

## Planned: Version 0.5.0 — Booking System

**Status:** 🔲 Not Started

### Planned Changes
- [ ] Unified calendar component
- [ ] Booking creation flows
- [ ] Availability checking
- [ ] Approval workflow
- [ ] Booking notifications
- [ ] Status history tracking

---

## Planned: Version 1.0.0 — MVP Launch

**Status:** 🔲 Not Started

### Criteria
- Self-serve signup with paid subscription
- All 4 sections working
- Unified calendar with filters
- Aviation auto-calculations
- Tier rules enforcement
- Seat limits enforcement
- Production deployment

---

## Notes for Future Sessions

### Quick Reference
- **Project Path:** `/home/claude/reservepty`
- **Tech Stack:** Next.js 14 + Supabase + Tilopay + Vercel
- **Design:** Dark navy + champagne gold, Didot LT Pro headings
- **Payment Gateway:** Tilopay (not Stripe)
- **No PWA/Offline:** User explicitly declined offline capabilities

### Key Files
- `apps/web/tailwind.config.ts` — Design system tokens
- `apps/web/styles/globals.css` — Component classes
- `supabase/migrations/00001_initial_schema.sql` — Database schema
- `apps/web/app/page.tsx` — Landing page

### Database Tables (Core)
- `organizations` — Tenants
- `subscriptions` — Billing state
- `entitlements` — Section access
- `assets` — All asset types
- `reservations` — Bookings
- `tiers` — Member priority levels

---

*Last updated: December 24, 2025*
