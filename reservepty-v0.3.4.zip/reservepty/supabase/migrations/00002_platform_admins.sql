-- Platform Admins Migration
-- Run this in Supabase SQL Editor after the initial schema

-- Platform admins table (super admins for the entire platform)
CREATE TABLE IF NOT EXISTS platform_admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin', 'admin', 'support')),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES platform_admins(id),
  last_login_at TIMESTAMPTZ,
  UNIQUE(user_id)
);

-- Platform activity logs
CREATE TABLE IF NOT EXISTS platform_activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES platform_admins(id),
  action TEXT NOT NULL,
  entity_type TEXT, -- 'organization', 'user', 'subscription', etc.
  entity_id UUID,
  details JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Complimentary memberships (free accounts not tied to payment)
CREATE TABLE IF NOT EXISTS complimentary_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  granted_by UUID REFERENCES platform_admins(id),
  reason TEXT,
  sections TEXT[] DEFAULT '{}', -- Which sections are granted
  max_seats INTEGER DEFAULT 5,
  expires_at TIMESTAMPTZ, -- NULL means never expires
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  notes TEXT
);

-- Platform settings
CREATE TABLE IF NOT EXISTS platform_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by UUID REFERENCES platform_admins(id)
);

-- Insert default settings
INSERT INTO platform_settings (key, value) VALUES
  ('pricing', '{"planes": 99, "helicopters": 99, "residences": 79, "boats": 79}'),
  ('seat_tiers', '[5, 10, 25, 50, 100]'),
  ('trial_days', '14'),
  ('maintenance_mode', 'false')
ON CONFLICT (key) DO NOTHING;

-- RLS Policies for platform tables
ALTER TABLE platform_admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE complimentary_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;

-- Platform admins can read their own record
CREATE POLICY "Platform admins can read own record"
  ON platform_admins FOR SELECT
  USING (user_id = auth.uid());

-- Platform admins can read all records (for admin panel)
CREATE POLICY "Platform admins can read all admins"
  ON platform_admins FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Only super_admins can insert new admins
CREATE POLICY "Super admins can create admins"
  ON platform_admins FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND role = 'super_admin' AND is_active = true
    )
  );

-- Activity logs - admins can read all
CREATE POLICY "Platform admins can read activity logs"
  ON platform_activity_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Activity logs - admins can insert
CREATE POLICY "Platform admins can create activity logs"
  ON platform_activity_logs FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Complimentary memberships - admins can manage
CREATE POLICY "Platform admins can manage complimentary memberships"
  ON complimentary_memberships FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Platform settings - admins can read
CREATE POLICY "Platform admins can read settings"
  ON platform_settings FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Platform settings - only super_admins can update
CREATE POLICY "Super admins can update settings"
  ON platform_settings FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM platform_admins WHERE user_id = auth.uid() AND role = 'super_admin' AND is_active = true
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_platform_admins_user_id ON platform_admins(user_id);
CREATE INDEX IF NOT EXISTS idx_platform_admins_email ON platform_admins(email);
CREATE INDEX IF NOT EXISTS idx_platform_activity_logs_admin ON platform_activity_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_platform_activity_logs_created ON platform_activity_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_complimentary_memberships_org ON complimentary_memberships(organization_id);

-- Function to check if user is platform admin
CREATE OR REPLACE FUNCTION is_platform_admin(user_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM platform_admins 
    WHERE user_id = user_uuid AND is_active = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get platform admin role
CREATE OR REPLACE FUNCTION get_platform_admin_role(user_uuid UUID)
RETURNS TEXT AS $$
DECLARE
  admin_role TEXT;
BEGIN
  SELECT role INTO admin_role FROM platform_admins 
  WHERE user_id = user_uuid AND is_active = true;
  RETURN admin_role;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
