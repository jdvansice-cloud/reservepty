-- ReservePTY Database Schema v0.1.0
-- Initial migration: Core tables for multi-tenant SaaS

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- ENUMS
-- =====================================================

CREATE TYPE subscription_status AS ENUM (
  'trialing',
  'active',
  'past_due',
  'canceled',
  'unpaid'
);

CREATE TYPE billing_interval AS ENUM ('monthly', 'yearly');

CREATE TYPE asset_section AS ENUM (
  'planes',
  'helicopters',
  'residences',
  'boats'
);

CREATE TYPE user_role AS ENUM (
  'owner',
  'admin',
  'manager',
  'member',
  'viewer'
);

CREATE TYPE reservation_status AS ENUM (
  'pending',
  'approved',
  'rejected',
  'canceled',
  'completed'
);

CREATE TYPE permission_level AS ENUM (
  'view',
  'book',
  'manage',
  'admin'
);

-- =====================================================
-- ORGANIZATIONS (Tenants)
-- =====================================================

CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- Business info
  legal_name VARCHAR(255) NOT NULL,
  commercial_name VARCHAR(255),
  ruc VARCHAR(50), -- Panama tax ID
  dv VARCHAR(10),  -- Dígito Verificador
  
  -- Contact
  billing_email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  country VARCHAR(100) DEFAULT 'Panama',
  address TEXT,
  
  -- Branding
  logo_url TEXT,
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- Index for soft deletes
CREATE INDEX idx_organizations_active ON organizations(id) WHERE deleted_at IS NULL;

-- =====================================================
-- SUBSCRIPTIONS & ENTITLEMENTS
-- =====================================================

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  -- Status
  status subscription_status DEFAULT 'trialing',
  billing_interval billing_interval NOT NULL,
  
  -- Tilopay integration
  tilopay_subscription_id VARCHAR(255),
  tilopay_customer_id VARCHAR(255),
  
  -- Dates
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  trial_end TIMESTAMPTZ,
  canceled_at TIMESTAMPTZ,
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_org ON subscriptions(organization_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);

-- Section entitlements (which modules are enabled)
CREATE TABLE entitlements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subscription_id UUID NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  section asset_section NOT NULL,
  enabled BOOLEAN DEFAULT true,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(subscription_id, section)
);

CREATE INDEX idx_entitlements_sub ON entitlements(subscription_id);

-- Seat limits
CREATE TABLE seat_limits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subscription_id UUID NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  
  max_seats INTEGER NOT NULL DEFAULT 5,
  used_seats INTEGER NOT NULL DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(subscription_id)
);

-- =====================================================
-- USERS & MEMBERS
-- =====================================================

-- Profiles extend Supabase auth.users
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  
  full_name VARCHAR(255),
  avatar_url TEXT,
  phone VARCHAR(50),
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Organization membership
CREATE TABLE organization_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  
  role user_role NOT NULL DEFAULT 'member',
  
  -- Invitation tracking
  invited_by UUID REFERENCES profiles(id),
  invited_at TIMESTAMPTZ DEFAULT NOW(),
  joined_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(organization_id, user_id)
);

CREATE INDEX idx_org_members_org ON organization_members(organization_id);
CREATE INDEX idx_org_members_user ON organization_members(user_id);

-- =====================================================
-- TIERS & RULES (Priority System)
-- =====================================================

CREATE TABLE tiers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  name VARCHAR(100) NOT NULL,
  priority INTEGER NOT NULL DEFAULT 1, -- 1 = highest
  color VARCHAR(7), -- Hex color for calendar
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(organization_id, name)
);

CREATE INDEX idx_tiers_org ON tiers(organization_id);

-- User tier assignments
CREATE TABLE user_tiers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  tier_id UUID NOT NULL REFERENCES tiers(id) ON DELETE CASCADE,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(organization_id, user_id)
);

-- Tier booking rules
CREATE TABLE tier_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tier_id UUID NOT NULL REFERENCES tiers(id) ON DELETE CASCADE,
  
  -- Asset type this rule applies to (null = all)
  asset_section asset_section,
  
  -- Limits
  max_days_per_month INTEGER,
  max_consecutive_days INTEGER,
  min_lead_time_hours INTEGER DEFAULT 24,
  max_active_reservations INTEGER,
  
  -- Approval
  requires_approval BOOLEAN DEFAULT false,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_tier_rules_tier ON tier_rules(tier_id);

-- Seasonal blackout windows
CREATE TABLE blackout_windows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tier_id UUID NOT NULL REFERENCES tiers(id) ON DELETE CASCADE,
  
  name VARCHAR(100),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  recurring_yearly BOOLEAN DEFAULT false,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ASSETS
-- =====================================================

CREATE TABLE assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  -- Type
  section asset_section NOT NULL,
  
  -- Basic info
  name VARCHAR(255) NOT NULL,
  description TEXT,
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  
  -- Section-specific data (JSON for flexibility, with typed tables for aviation)
  metadata JSONB DEFAULT '{}',
  
  -- Location tracking (for aircraft)
  current_location_id UUID,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE INDEX idx_assets_org ON assets(organization_id);
CREATE INDEX idx_assets_org_section ON assets(organization_id, section) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_active ON assets(organization_id, is_active) WHERE deleted_at IS NULL;

-- Aviation-specific asset details
CREATE TABLE aircraft_details (
  asset_id UUID PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  
  -- Registration & type
  registration VARCHAR(20),
  aircraft_type VARCHAR(100),
  manufacturer VARCHAR(100),
  model VARCHAR(100),
  year INTEGER,
  
  -- Performance
  cruise_speed_kts DECIMAL(6, 2),
  turnaround_minutes INTEGER DEFAULT 60,
  adjustment_factor DECIMAL(4, 2) DEFAULT 1.15,
  
  -- Capacity
  passenger_capacity INTEGER,
  
  -- Tracking
  total_flight_hours DECIMAL(10, 2) DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Boat-specific asset details
CREATE TABLE boat_details (
  asset_id UUID PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  
  -- Registration
  registration VARCHAR(50),
  boat_type VARCHAR(100),
  manufacturer VARCHAR(100),
  model VARCHAR(100),
  year INTEGER,
  
  -- Specs
  length_ft DECIMAL(6, 2),
  beam_ft DECIMAL(6, 2),
  draft_ft DECIMAL(6, 2),
  
  -- Performance
  turnaround_minutes INTEGER DEFAULT 120,
  
  -- Capacity
  passenger_capacity INTEGER,
  crew_required INTEGER DEFAULT 1,
  
  -- Engine
  total_engine_hours DECIMAL(10, 2) DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Residence-specific asset details
CREATE TABLE residence_details (
  asset_id UUID PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  
  -- Property info
  property_type VARCHAR(50), -- villa, apartment, room, etc.
  address TEXT,
  
  -- Specs
  bedrooms INTEGER,
  bathrooms DECIMAL(3, 1),
  max_guests INTEGER,
  square_footage INTEGER,
  
  -- Timings
  check_in_time TIME DEFAULT '15:00',
  check_out_time TIME DEFAULT '11:00',
  cleaning_buffer_hours INTEGER DEFAULT 4,
  
  -- Rules
  house_rules TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Asset photos
CREATE TABLE asset_photos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  
  url TEXT NOT NULL,
  alt_text VARCHAR(255),
  sort_order INTEGER DEFAULT 0,
  is_primary BOOLEAN DEFAULT false,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_asset_photos ON asset_photos(asset_id);

-- Asset permissions (sharing)
CREATE TABLE asset_permissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  
  -- Grant to user OR tier
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  tier_id UUID REFERENCES tiers(id) ON DELETE CASCADE,
  
  permission permission_level NOT NULL DEFAULT 'view',
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Must have either user_id or tier_id
  CONSTRAINT asset_perm_target CHECK (
    (user_id IS NOT NULL AND tier_id IS NULL) OR
    (user_id IS NULL AND tier_id IS NOT NULL)
  )
);

CREATE INDEX idx_asset_perms_asset ON asset_permissions(asset_id);
CREATE INDEX idx_asset_perms_user ON asset_permissions(user_id);
CREATE INDEX idx_asset_perms_tier ON asset_permissions(tier_id);

-- =====================================================
-- DIRECTORIES (Airports, Ports, etc.)
-- =====================================================

CREATE TABLE airports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  code VARCHAR(10) NOT NULL, -- ICAO or custom
  name VARCHAR(255) NOT NULL,
  
  -- Location
  latitude DECIMAL(10, 7),
  longitude DECIMAL(10, 7),
  country VARCHAR(100),
  city VARCHAR(100),
  
  -- Type
  is_helipad BOOLEAN DEFAULT false,
  
  notes TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(organization_id, code)
);

CREATE INDEX idx_airports_org ON airports(organization_id);

CREATE TABLE ports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  code VARCHAR(20),
  name VARCHAR(255) NOT NULL,
  
  -- Location
  latitude DECIMAL(10, 7),
  longitude DECIMAL(10, 7),
  country VARCHAR(100),
  city VARCHAR(100),
  
  notes TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(organization_id, code)
);

CREATE INDEX idx_ports_org ON ports(organization_id);

-- =====================================================
-- RESERVATIONS
-- =====================================================

CREATE TABLE reservations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id),
  
  -- Status
  status reservation_status DEFAULT 'pending',
  
  -- Timing
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  
  -- Booking info
  title VARCHAR(255),
  notes TEXT,
  guest_count INTEGER,
  
  -- Approval workflow
  approved_by UUID REFERENCES profiles(id),
  approved_at TIMESTAMPTZ,
  rejection_reason TEXT,
  
  -- Audit
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE INDEX idx_reservations_org ON reservations(organization_id);
CREATE INDEX idx_reservations_asset ON reservations(asset_id);
CREATE INDEX idx_reservations_user ON reservations(user_id);
CREATE INDEX idx_reservations_calendar ON reservations(organization_id, start_time, end_time) 
  WHERE deleted_at IS NULL;
CREATE INDEX idx_reservations_status ON reservations(organization_id, status) 
  WHERE deleted_at IS NULL;

-- Aviation reservation metadata
CREATE TABLE reservation_aviation_meta (
  reservation_id UUID PRIMARY KEY REFERENCES reservations(id) ON DELETE CASCADE,
  
  departure_airport_id UUID REFERENCES airports(id),
  arrival_airport_id UUID REFERENCES airports(id),
  
  -- Calculated values
  distance_nm DECIMAL(10, 2),
  estimated_flight_time_minutes INTEGER,
  turnaround_minutes INTEGER,
  
  passengers INTEGER,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Boat reservation metadata
CREATE TABLE reservation_boat_meta (
  reservation_id UUID PRIMARY KEY REFERENCES reservations(id) ON DELETE CASCADE,
  
  departure_port_id UUID REFERENCES ports(id),
  return_port_id UUID REFERENCES ports(id),
  
  passengers INTEGER,
  requires_captain BOOLEAN DEFAULT true,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Residence reservation metadata
CREATE TABLE reservation_residence_meta (
  reservation_id UUID PRIMARY KEY REFERENCES reservations(id) ON DELETE CASCADE,
  
  check_in_time TIME,
  check_out_time TIME,
  
  adults INTEGER DEFAULT 1,
  children INTEGER DEFAULT 0,
  
  special_requests TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reservation status history (audit trail)
CREATE TABLE reservation_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reservation_id UUID NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
  
  from_status reservation_status,
  to_status reservation_status NOT NULL,
  
  changed_by UUID REFERENCES profiles(id),
  reason TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_res_history ON reservation_status_history(reservation_id);

-- =====================================================
-- MAINTENANCE & USAGE LOGS
-- =====================================================

CREATE TABLE maintenance_tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  
  title VARCHAR(255) NOT NULL,
  description TEXT,
  
  -- Scheduling
  due_date DATE,
  due_hours DECIMAL(10, 2), -- For flight/engine hour-based maintenance
  
  -- Status
  is_completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMPTZ,
  completed_by UUID REFERENCES profiles(id),
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_maintenance_asset ON maintenance_tasks(asset_id);

CREATE TABLE usage_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  reservation_id UUID REFERENCES reservations(id),
  
  -- Usage data
  log_date DATE NOT NULL,
  hours DECIMAL(10, 2),
  
  -- For aircraft/boats
  start_location_id UUID,
  end_location_id UUID,
  
  notes TEXT,
  logged_by UUID REFERENCES profiles(id),
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_usage_logs_asset ON usage_logs(asset_id);
CREATE INDEX idx_usage_logs_date ON usage_logs(asset_id, log_date);

-- =====================================================
-- ROW LEVEL SECURITY (RLS)
-- =====================================================

-- Enable RLS on all tables
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE entitlements ENABLE ROW LEVEL SECURITY;
ALTER TABLE seat_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE tier_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE blackout_windows ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE aircraft_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE boat_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE residence_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE asset_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE asset_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE airports ENABLE ROW LEVEL SECURITY;
ALTER TABLE ports ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservation_aviation_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservation_boat_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservation_residence_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservation_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_logs ENABLE ROW LEVEL SECURITY;

-- Helper function to get user's organization IDs
CREATE OR REPLACE FUNCTION get_user_org_ids()
RETURNS SETOF UUID AS $$
  SELECT organization_id 
  FROM organization_members 
  WHERE user_id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Profiles: users can read/update their own profile
CREATE POLICY "Users can view own profile" 
  ON profiles FOR SELECT 
  USING (id = auth.uid());

CREATE POLICY "Users can update own profile" 
  ON profiles FOR UPDATE 
  USING (id = auth.uid());

-- Organizations: members can view their orgs
CREATE POLICY "Members can view their organizations" 
  ON organizations FOR SELECT 
  USING (id IN (SELECT get_user_org_ids()));

-- Organization members: members can view other members in their org
CREATE POLICY "Members can view org members" 
  ON organization_members FOR SELECT 
  USING (organization_id IN (SELECT get_user_org_ids()));

-- Assets: org members can view assets
CREATE POLICY "Members can view org assets" 
  ON assets FOR SELECT 
  USING (organization_id IN (SELECT get_user_org_ids()));

-- Reservations: org members can view reservations
CREATE POLICY "Members can view org reservations" 
  ON reservations FOR SELECT 
  USING (organization_id IN (SELECT get_user_org_ids()));

-- Members can create reservations in their org
CREATE POLICY "Members can create reservations" 
  ON reservations FOR INSERT 
  WITH CHECK (organization_id IN (SELECT get_user_org_ids()));

-- =====================================================
-- FUNCTIONS
-- =====================================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to tables with updated_at
CREATE TRIGGER update_organizations_updated_at
  BEFORE UPDATE ON organizations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_organization_members_updated_at
  BEFORE UPDATE ON organization_members
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_assets_updated_at
  BEFORE UPDATE ON assets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_reservations_updated_at
  BEFORE UPDATE ON reservations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Function to check section entitlement
CREATE OR REPLACE FUNCTION check_section_entitlement(
  p_organization_id UUID,
  p_section asset_section
)
RETURNS BOOLEAN AS $$
DECLARE
  v_enabled BOOLEAN;
BEGIN
  SELECT e.enabled INTO v_enabled
  FROM entitlements e
  JOIN subscriptions s ON e.subscription_id = s.id
  WHERE s.organization_id = p_organization_id
    AND s.status = 'active'
    AND e.section = p_section;
  
  RETURN COALESCE(v_enabled, false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check seat availability
CREATE OR REPLACE FUNCTION check_seat_availability(
  p_organization_id UUID
)
RETURNS BOOLEAN AS $$
DECLARE
  v_max_seats INTEGER;
  v_used_seats INTEGER;
BEGIN
  SELECT sl.max_seats, sl.used_seats INTO v_max_seats, v_used_seats
  FROM seat_limits sl
  JOIN subscriptions s ON sl.subscription_id = s.id
  WHERE s.organization_id = p_organization_id
    AND s.status = 'active';
  
  RETURN COALESCE(v_used_seats < v_max_seats, false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to calculate distance between airports
CREATE OR REPLACE FUNCTION calculate_distance_nm(
  p_dep_lat DECIMAL,
  p_dep_lon DECIMAL,
  p_arr_lat DECIMAL,
  p_arr_lon DECIMAL
)
RETURNS DECIMAL AS $$
DECLARE
  v_R CONSTANT DECIMAL := 3440.065; -- Earth radius in nautical miles
  v_dLat DECIMAL;
  v_dLon DECIMAL;
  v_a DECIMAL;
  v_c DECIMAL;
BEGIN
  v_dLat := RADIANS(p_arr_lat - p_dep_lat);
  v_dLon := RADIANS(p_arr_lon - p_dep_lon);
  
  v_a := SIN(v_dLat/2) * SIN(v_dLat/2) +
         COS(RADIANS(p_dep_lat)) * COS(RADIANS(p_arr_lat)) *
         SIN(v_dLon/2) * SIN(v_dLon/2);
  
  v_c := 2 * ATAN2(SQRT(v_a), SQRT(1-v_a));
  
  RETURN v_R * v_c;
END;
$$ LANGUAGE plpgsql IMMUTABLE;
